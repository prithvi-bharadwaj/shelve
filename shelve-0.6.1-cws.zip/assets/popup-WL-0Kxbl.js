import{c as O,r as b,j as r,o as Le,v as Ee,B as we,p as Te,C as Pe,s as De,t as Ue}from"./rotatingPlaceholders-C0rivA-Z.js";const Ve=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h2",key:"tvwodi"}],["path",{d:"M20 8v11a2 2 0 0 1-2 2h-2",key:"1gkqxj"}],["path",{d:"m9 15 3-3 3 3",key:"1pd0qc"}],["path",{d:"M12 12v9",key:"192myk"}]],Ge=O("archive-restore",Ve);const Ie=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],Be=O("archive",Ie);const Je=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],Ke=O("arrow-right",Je);const Qe=[["path",{d:"M10 18H5a3 3 0 0 1-3-3v-1",key:"ru65g8"}],["path",{d:"M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"e30een"}],["path",{d:"M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"2ahx8o"}],["path",{d:"m7 21 3-3-3-3",key:"127cv2"}],["rect",{x:"14",y:"14",width:"8",height:"8",rx:"2",key:"1b0bso"}],["rect",{x:"2",y:"2",width:"8",height:"8",rx:"2",key:"1x09vl"}]],Ze=O("combine",Qe);const ea=[["line",{x1:"12",x2:"18",y1:"12",y2:"18",key:"1rg63v"}],["line",{x1:"12",x2:"18",y1:"18",y2:"12",key:"ebkxgr"}],["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],aa=O("copy-x",ea);const ra=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],ta=O("key-round",ra);const oa=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],le=O("loader-circle",oa);const sa=[["path",{d:"M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",key:"12jkf8"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M19 16v6",key:"tddt3s"}],["path",{d:"M16 19h6",key:"xwg31i"}]],ia=O("mail-plus",sa);const na=[["path",{d:"M12 17v5",key:"bb1du9"}],["path",{d:"M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",key:"1nkz8b"}]],la=O("pin",na);const ca=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],da=O("puzzle",ca);const pa=[["path",{d:"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",key:"117uat"}],["path",{d:"M6 12h16",key:"s4cdu5"}]],ba=O("send-horizontal",pa);const ua=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ga=O("settings",ua);const ma=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],fa=O("shield-check",ma);const xa=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],ha=O("sparkles",xa);const $a=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],ya=O("undo-2",$a);const va=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],za=O("x",va);const wa=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],ka=O("zap",wa),ja={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},Na={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},Q={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}}},Oe={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function Ca(t){return Oe[t].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Wa(t){return Oe[t].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ha(t){return Q[t].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Xa(t){const e=Q[t],a=t==="mono"?.225:.45;return e.border.map(o=>{const s=o.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${o.size.split(" ").map(n=>{const c=parseInt(n);return`${Math.round(c*.9)}px`}).join(" ")} at ${o.pos}, ${s}, transparent)`}).join(`,
    `)}function Ya(t,e){const a=Q[t];return e?a.spike:a.spikeLt}const Sa={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function Ma(t,e,a){return Sa[t][e?"dark":"light"].map(o=>{const s=o.offsetX===0?"":o.offsetX>0?` + ${o.offsetX}px`:` - ${Math.abs(o.offsetX)}px`,n=o.offsetY===0?"":o.offsetY>0?` + ${o.offsetY}px`:` - ${Math.abs(o.offsetY)}px`;return`radial-gradient(ellipse calc(${o.sizeW}px * var(--beam-w-${a})) calc(${o.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${s}) calc(100%${n}), ${o.color}, transparent)`}).join(`,
       `)}const Oa={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function Fa(t,e){return Oa[t].map(a=>{const o=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,s=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${o}) calc(100%${s}), ${a.color}, transparent)`}).join(`,
    `)}const Ra={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}}};function me(t,e){const a=t.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const o=t.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return o?`rgba(${o[1]}, ${o[2]}, ${o[3]}, ${e})`:t}function K(t,e){const a=t.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const o=t.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return o?`rgba(${o[1]}, ${o[2]}, ${o[3]}, ${e.toFixed(2)})`:t}function _a(t,e,a){const o=Ya(t,e),s=Ra[t][e?"dark":"light"],n=t==="mono",c=n?.14:1,d=n?K(o.primary,.14):o.primary,m=n?K(o.primary,.09):o.primary,f=n?K(o.secondary,.12):o.secondary,p=n?me(o.secondary,.06):me(o.secondary,.49),l=s.spikes.map(X=>n?{color1:K(X.color1,c),color2:K(X.color2,c*.7)}:X),u=n?"12px":"0.8px",i=n?"14px":"2px",z=n?"12px":"1.2px",k=n?"10px":"0.6px",w=n?"42px":"92px",C=n?"38px":"72px",g=n?"40px":"85px",y=n?"32px":"60px",x=n?"12px":"1px",v=n?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",$=n?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",N=n?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",W=n?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",M=n?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",H=n?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${u} * var(--beam-spike-${a})) calc(${w} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${d}, ${m} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${f}, ${p} 50%, transparent 95%),
       radial-gradient(ellipse calc(${i} * (2 - var(--beam-spike-${a}))) calc(${C} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${l[0].color1}, ${l[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${l[1].color1}, ${l[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${z} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${l[2].color1}, ${l[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${l[3].color1}, ${l[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${k} * (2 - var(--beam-spike-${a}))) calc(${y} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${l[4].color1}, ${l[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${v} 0%, ${$} 20%, ${N} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${W} 0%, ${M} 25%, ${H} 55%, transparent 80%)`;{const X=n?K(o.primary,.11):me(o.primary,.85),L=n?K(o.secondary,.09):me(o.secondary,.7);return`radial-gradient(ellipse calc(${u} * var(--beam-spike-${a})) calc(${w} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${d}, ${X} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${f}, ${L} 50%, transparent 95%),
       radial-gradient(ellipse calc(${i} * (2 - var(--beam-spike-${a}))) calc(${C} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${l[0].color1}, ${l[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${l[1].color1}, ${l[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${z} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${l[2].color1}, ${l[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${l[3].color1}, ${l[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${x} * (2 - var(--beam-spike-${a}))) calc(${y} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${l[4].color1}, ${l[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const Fe=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],Aa=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],qa=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],We=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],La=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Ea(t,e,a){const o=t.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${o?`${o[1]}, ${o[2]}, ${o[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function Ne(t,e,a,o,s,n,c,d){return`radial-gradient(ellipse calc(${e}px * var(--bw${o}-${d}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${o}-${d}) * var(--bgh-${d}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${n} + var(--bx${o}-${d})) calc(${c} + var(--by${o}-${d})), ${Ea(t,s,d)}, transparent)`}function Ta(t,e){return Q[t].border.map((a,o)=>{const{region:s,quad:n}=Fe[o],[c,d]=a.pos.split(" "),[m,f]=a.size.split(" ").map(parseFloat);return Ne(a.color,m,f,s,n,c,d,e)}).join(`,
    `)}function Pa(t,e,a){const o=Q[t].border.map((d,m)=>{const{region:f,quad:p}=Fe[m],[l,u]=d.pos.split(" "),[i,z]=Aa[m];return Ne(d.color,i,z,f,p,l,u,e)}),s=a?"255, 255, 255":"0, 0, 0",n=a?.18:.08,c=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([d,m,f])=>`radial-gradient(ellipse 60px 60px at ${d} ${m}, rgba(${s}, calc(${n} * var(--bop-${f}-${e}))), transparent 70%)`);return[...o,...c].join(`,
    `)}function He(t,e,a){const o=Q[e].border;return t.map(s=>{const n=o[s.ci],[c,d]=n.pos.split(" ");return Ne(n.color,s.w,s.h,s.region,s.quad,s.x??c,s.y??d,a)}).join(`,
    `)}function Re(t,e,a){const o=Q[e].border,s=+a.toFixed(3);return t.map(n=>{const c=o[n.ci],[d,m]=c.pos.split(" "),f=n.x??d,p=n.y??m,l=c.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),u=l?`${l[1]}, ${l[2]}, ${l[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${n.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${n.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${f} ${p}, rgba(${u}, ${s}), transparent)`}).join(`,
    `)}function ce(t){return`
[data-beam="${t}"][data-paused],
[data-beam="${t}"][data-paused]::after,
[data-beam="${t}"][data-paused]::before,
[data-beam="${t}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function _e(t){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],o=e.map(n=>`@property --${n}-${t} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),s=a.map(n=>`@property --${n}-${t} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${o}

${s}

@property --beam-opacity-${t} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${t} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function Ce(t,e,a){const o=e==="dark",s=a/2.3;return t==="pulse-inner"?{sp:.28,dr:o?33:40,op:o?.48:.45,gh:o?.34:.22,bs:(o?1.9:2.6)*s,ss:(o?2.6:4.6)*s,ghs:(o?2.4:5.5)*s,huePeriod:16}:{sp:o?.28:.36,dr:o?14:19,op:o?.46:0,gh:o?.16:.58,bs:(o?2.3:3.7)*s,ss:(o?6.4:4.6)*s,ghs:(o?2.4:3.8)*s,huePeriod:14}}function Da(t,e){const{sp:a,dr:o,op:s,gh:n,bs:c,ss:d,ghs:m}=e;return[{prop:`--bw1-${t}`,a:1-a,b:1+a*1.1,period:d*.9,delay:0,unit:""},{prop:`--bh1-${t}`,a:1+a*.9,b:1-a*.85,period:d*1.26,delay:0,unit:""},{prop:`--bx1-${t}`,a:-o,b:o*.9,period:c*1.6,delay:0,unit:"px"},{prop:`--by1-${t}`,a:o*.55,b:-o*.7,period:c*1.6,delay:0,unit:"px"},{prop:`--bw2-${t}`,a:1+a,b:1-a*.85,period:d*1.1,delay:0,unit:""},{prop:`--bh2-${t}`,a:1-a*.8,b:1+a*1.05,period:d*.81,delay:0,unit:""},{prop:`--bx2-${t}`,a:o*.8,b:-o*.9,period:c*1.88,delay:0,unit:"px"},{prop:`--by2-${t}`,a:-o,b:o*.65,period:c*1.88,delay:0,unit:"px"},{prop:`--bw3-${t}`,a:1-a*.6,b:1+a*1.15,period:d*.98,delay:0,unit:""},{prop:`--bh3-${t}`,a:1+a*.75,b:1-a,period:d*1.4,delay:0,unit:""},{prop:`--bx3-${t}`,a:-o*.6,b:o,period:c*1.45,delay:0,unit:"px"},{prop:`--by3-${t}`,a:-o*.85,b:o*.45,period:c*1.45,delay:0,unit:"px"},{prop:`--bgh-${t}`,a:1-n,b:1+n,period:m,delay:0,unit:""},{prop:`--bop-tl-${t}`,a:1-s,b:1,period:c,delay:0,unit:""},{prop:`--bop-tr-${t}`,a:1-s,b:1,period:c*1.32,delay:c*.28,unit:""},{prop:`--bop-bl-${t}`,a:1-s,b:1,period:c*.84,delay:c*.55,unit:""},{prop:`--bop-br-${t}`,a:1-s,b:1,period:c*1.58,delay:c*.83,unit:""}]}function Ua(t,e,a,o,s,n){if(t!=="pulse-inner"&&t!=="pulse-outside")return null;const c=Ce(t,e,a);return{oscillators:Da(n,c),hue:s?null:{prop:`--beam-hue-${n}`,range:360,period:c.huePeriod,continuous:!0}}}function he(t,e,a){return`  animation: ${e}-${t} ${a}s ease forwards;`}function Va(t){const{size:e}=t;return e==="line"?Ka(t):e==="sm"?Ga(t):e==="pulse-inner"?Ba(t):e==="pulse-outside"?Ja(t):Ia(t)}function Ga(t){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:n,innerOpacity:c,bloomOpacity:d,innerShadow:m,colorVariant:f,staticColors:p,brightness:l,saturation:u,hueRange:i,theme:z}=t,k=Math.max(0,a-o),w=f==="mono"?.5:1,C=n*w,g=c*w,y=d*w,x=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
}`,$=z==="dark",N=$?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,W=Ca(f),M=Wa(f),H=$?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,X=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${W};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${x}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${M};
  box-shadow: inset 0 0 5px 1px ${m};
  -webkit-mask-image: ${X};
  -webkit-mask-composite: source-over;
  mask-image: ${X};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${x}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  clip-path: inset(0 round ${a}px);
  background: ${H};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  filter: blur(8px) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${ce(e)}
`}function Ia(t){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:n,innerOpacity:c,bloomOpacity:d,innerShadow:m,colorVariant:f,staticColors:p,brightness:l,saturation:u,hueRange:i,theme:z}=t,k=Math.max(0,a-o),w=f==="mono"?.5:1,C=n*w,g=c*w,y=d*w,x=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
}`,$=z==="dark",N=$?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,W=Ha(f),M=Xa(f),H=$?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${W};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${x}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${M};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${x}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  clip-path: inset(0 round ${a}px);
  background: ${H};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  filter: blur(8px) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${v}
${ce(e)}
`}function Ba(t){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:n,innerOpacity:c,bloomOpacity:d,colorVariant:m,staticColors:f,brightness:p,saturation:l,hueRange:u,theme:i}=t,z=i==="dark",k=m==="mono"?.5:1,w=(n*k).toFixed(2),C=(c*k).toFixed(2),g=(d*k).toFixed(2),{op:y}=Ce("pulse-inner",i,s),x=8,v=p.toFixed(2),$=l.toFixed(2),N=f?`filter: brightness(${v}) saturate(${$});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${$});`,W=f?`filter: blur(${x}px) brightness(${v}) saturate(${$});`:`filter: blur(${x}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${v}) saturate(${$});`,M=Ta(m,e),H=Pa(m,e,z),X=Re(qa,m,1-y*.5);return`
${_e(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${he(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${he(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${M};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${w} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${H};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${C} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${X};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${W}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ce(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Ja(t){const{id:e,borderRadius:a,duration:o,strokeOpacity:s,innerOpacity:n,bloomOpacity:c,colorVariant:d,staticColors:m,brightness:f,saturation:p,hueRange:l,theme:u,hairlineOpacity:i=0}=t,z=u==="dark",k=d==="mono"?.5:1,w=(s*k).toFixed(2),C=(n*k).toFixed(2),g=(c*k).toFixed(2),y=z?"70, 70, 70":"0, 0, 0",x=i.toFixed(2),v=`linear-gradient(rgba(${y}, ${x}), rgba(${y}, ${x}))`,{op:$}=Ce("pulse-outside",u,o),N=.95,W=.9,M=z?3:6,H=z?22.5:15,X=f.toFixed(2),L=p.toFixed(2),Z=m?`filter: brightness(${X}) saturate(${L});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${X}) saturate(${L});`,A=`brightness(var(--beam-glow-brightness, ${X})) saturate(var(--beam-glow-saturate, ${L}))`,P=m?`filter: blur(var(--beam-core-blur, ${M}px)) ${A};`:`filter: blur(var(--beam-core-blur, ${M}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${A};`,D=m?`filter: blur(var(--beam-bloom-blur, ${H}px)) ${A};`:`filter: blur(var(--beam-bloom-blur, ${H}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${A};`,R=He(We,d,e),Y=He(We,d,e),U=Re(La,d,1-$*.5),T=i>0?`${R},
    ${v}`:R;return`
${_e(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${he(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${he(e,"beam-fade-out",.5)}
}
${i>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${v};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${T};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${w} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${Z}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${Y};
  transform: scale(${N}, ${W});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${C} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${P}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${U};
  transform: scale(${N}, ${W});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${D}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ce(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Ka(t){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:n,innerOpacity:c,bloomOpacity:d,innerShadow:m,colorVariant:f,staticColors:p,brightness:l,saturation:u,hueRange:i,theme:z}=t,k=Math.max(0,a-o),w=z==="dark",C=n,g=c,y=d,x=p?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,v=p?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,$=p?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i+10}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  50% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${i+10}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
  100% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${i+10}deg)) brightness(${l.toFixed(2)}) saturate(${u.toFixed(2)}); }
}`,N=w?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,W=Ma(f,w,e),M=Fa(f,e),H=_a(f,w,e),X=f==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${N}, ${W};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${x}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${M};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${x}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${k}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${H};
  ${X}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${v}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${$}
${ce(e)}
`}const $e=new Set;let oe=null,ke=0;const Qa=1e3/30-2,Za=Math.PI*2;function Xe(t){return(1-Math.cos(Za*t))/2}function Ae(t){if(oe=requestAnimationFrame(Ae),t-ke<Qa)return;ke=t;const e=t/1e3;$e.forEach(({el:a,config:o})=>{for(const s of o.oscillators){const n=(e-s.delay)/s.period,c=s.a+(s.b-s.a)*Xe(n);a.style.setProperty(s.prop,s.unit==="px"?`${c.toFixed(2)}px`:c.toFixed(4))}if(o.hue){const{prop:s,range:n,period:c,continuous:d}=o.hue,m=d?e/c%1*n:-n+2*n*Xe(e/c);a.style.setProperty(s,`${m.toFixed(2)}deg`)}})}function er(){oe==null&&(ke=0,oe=requestAnimationFrame(Ae))}function ar(){$e.size===0&&oe!=null&&(cancelAnimationFrame(oe),oe=null)}function rr(t,e){const a={el:t,config:e};return $e.add(a),er(),()=>{$e.delete(a),ar()}}function tr(){const[t,e]=b.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return b.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),o=s=>{e(s.matches?"dark":"light")};return a.addEventListener("change",o),()=>a.removeEventListener("change",o)},[]),t}function or(t,e){return t==="auto"?e:t}const je=b.forwardRef(function({children:t,size:e="md",colorVariant:a="colorful",theme:o="dark",staticColors:s=!1,duration:n,active:c=!0,borderRadius:d,brightness:m,saturation:f,hueRange:p=30,strength:l=1,className:u,style:i,onActivate:z,onDeactivate:k,onAnimationEnd:w,...C},g){const y=b.useId().replace(/:/g,"-"),x=tr(),v=b.useRef(null),[$,N]=b.useState(c),[W,M]=b.useState(!1),[H,X]=b.useState(!0),[L,Z]=b.useState(null),[A,P]=b.useState({x:1,y:1});b.useEffect(()=>{if(d!=null)return;const S=v.current;if(!S)return;const F=()=>{const I=S.firstElementChild;if(!I)return;const te=getComputedStyle(I),B=parseFloat(te.borderTopLeftRadius);!isNaN(B)&&B>0&&Z(B)};F();const G=new MutationObserver(F);return G.observe(S,{childList:!0,subtree:!1}),()=>G.disconnect()},[d,t]),b.useEffect(()=>{c&&!$&&!W?N(!0):!c&&$&&!W&&M(!0)},[c,$,W]),b.useEffect(()=>{const S=v.current;if(!S||typeof IntersectionObserver>"u")return;const F=new IntersectionObserver(G=>{for(const I of G)X(I.isIntersecting)},{rootMargin:"256px"});return F.observe(S),()=>F.disconnect()},[]),b.useEffect(()=>{if(e!=="pulse-outside"){P({x:1,y:1});return}const S=v.current;if(!S)return;const F=350,G=140,I=.35,te=4,B=E=>Math.max(I,Math.min(te,E)),be=()=>{const E=S.firstElementChild;if(!E)return;const _=E.getBoundingClientRect();if(!_.width||!_.height)return;const J=+B(_.width/F).toFixed(3),h=+B(_.height/G).toFixed(3);P(j=>j.x===J&&j.y===h?j:{x:J,y:h})};if(be(),typeof ResizeObserver>"u")return;const ue=S.firstElementChild;if(!ue)return;const ne=new ResizeObserver(be);return ne.observe(ue),()=>ne.disconnect()},[e,t]);const D=b.useCallback(S=>{const F=S.animationName;F.includes("fade-out")?(N(!1),M(!1),k?.()):F.includes("fade-in")&&z?.(),w?.(S)},[z,k,w]),R=or(o,x),Y=Na[e][R],U=ja[e],T=e==="pulse-inner"||e==="pulse-outside",se=d??L??U.borderRadius,ee=n??(e==="line"?3.1:T?2.3:1.96),de=f??Y.saturation,ae=m??Y.brightness??1.3,V=e==="line"?Math.min(p,13):p,re=a==="mono"?!0:s,ye=b.useMemo(()=>Va({id:y,borderRadius:se,borderWidth:U.borderWidth,duration:ee,strokeOpacity:Y.strokeOpacity,innerOpacity:Y.innerOpacity,bloomOpacity:Y.bloomOpacity,innerShadow:Y.innerShadow,size:e,colorVariant:a,staticColors:re,brightness:ae,saturation:de,hueRange:V,theme:R,hairlineOpacity:Y.hairlineOpacity}),[y,se,U.borderWidth,ee,Y.strokeOpacity,Y.innerOpacity,Y.bloomOpacity,Y.innerShadow,Y.hairlineOpacity,e,a,re,ae,de,V,R]),ie=b.useMemo(()=>T?Ua(e,R,ee,V,re,y):null,[T,e,R,ee,V,re,y]);b.useEffect(()=>{var S;if(!ie||!($||W)||!H)return;const F=v.current;if(F&&!(typeof window<"u"&&(S=window.matchMedia)!=null&&S.call(window,"(prefers-reduced-motion: reduce)").matches))return rr(F,ie)},[ie,$,W,H]);const ve=b.useCallback(S=>{v.current=S,typeof g=="function"?g(S):g&&(g.current=S)},[g]),pe={...i??{},"--beam-strength":Math.max(0,Math.min(1,l)),...e==="pulse-outside"?{"--pulse-glow-sx":A.x,"--pulse-glow-sy":A.y}:{}};return r.jsxs(r.Fragment,{children:[r.jsx("style",{children:ye}),r.jsxs("div",{...C,ref:ve,"data-beam":y,"data-active":$&&!W?"":void 0,"data-fading":W?"":void 0,"data-paused":$&&!W&&!H?"":void 0,className:u,style:pe,onAnimationEnd:D,children:[t,r.jsx("div",{"data-beam-bloom":!0})]})]})});function sr({className:t,...e}){return r.jsxs("svg",{viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",className:t,...e,children:[r.jsx("path",{d:"M7 4H4.75A1.75 1.75 0 0 0 3 5.75v8.5A1.75 1.75 0 0 0 4.75 16H7"}),r.jsx("path",{d:"M8.5 6.5h5M8.5 10h7M8.5 13.5h3.5"}),r.jsx("path",{d:"m13.5 4 2-1m0 14 2-1"})]})}function ir({closedTabs:t,onExpire:e}){return r.jsxs("div",{className:"closed-toast relative mt-2 overflow-hidden rounded-md border border-border bg-muted/20",children:[r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"max-h-36 space-y-1.5 overflow-y-auto p-2 pb-2.5",children:t.map((a,o)=>r.jsxs("li",{className:"flex min-w-0 items-center gap-2",children:[r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:a.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:a.url})]}),a.keptTabId!==void 0&&r.jsx("button",{type:"button",onClick:()=>chrome.runtime.sendMessage({type:"focusTab",tabId:a.keptTabId}),className:"shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"View existing"})]},`${a.url}-${o}`))}),r.jsx("div",{"data-testid":"closed-toast-timer",className:"closed-toast-timer absolute inset-x-0 bottom-0 h-0.5 origin-left bg-primary/60",onAnimationEnd:e})]})}function nr({windowId:t,disabled:e,acknowledged:a,onAcknowledge:o,onRunningChange:s,onMutation:n,onQuotaExhausted:c}){const[d,m]=b.useState(""),[f,p]=b.useState(!1),[l,u]=b.useState(!1),[i,z]=b.useState(null),k=Le(Ee),w=b.useRef(!1),C=b.useRef(s);C.current=s,b.useEffect(()=>()=>{w.current&&C.current(!1)},[]);const g=async()=>{const x=d.trim();if(!(!x||w.current||e)){if(!a&&!l){u(!0),z(null);return}l&&(u(!1),await o()),w.current=!0,p(!0),s(!0),z(null);try{let v=await chrome.permissions.contains({origins:["<all_urls>"]});if(!v)try{v=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{v=!1}const $=await chrome.runtime.sendMessage({type:"command",query:x,windowId:t,hasContentPermission:v});if($?.quota&&$.error){c?.($.error),z(null);return}z($??{error:"Something went wrong."}),["create_group","add_to_group","update_group","ungroup","remove_duplicates","merge_groups"].includes($?.action||"")&&!$.error&&(m(""),await n?.().catch(()=>{}))}catch{z({error:"Command was interrupted. Try again."})}finally{w.current=!1,p(!1),s(!1)}}},y=async x=>{await chrome.runtime.sendMessage({type:"focusTab",tabId:x})};return r.jsxs("section",{className:"mt-4","aria-label":"Command bar",children:[r.jsx(je,{size:"line",colorVariant:"ocean",theme:"dark",strength:.35,active:f,className:"w-full focus-within:ring-2 focus-within:ring-ring/30","data-testid":"command-beam",children:r.jsxs("div",{className:"flex items-center gap-2 rounded-lg border border-border bg-muted/20 px-2.5 focus-within:border-ring",children:[r.jsx("input",{value:d,onChange:x=>m(x.target.value),onKeyDown:x=>{x.key==="Enter"&&g()},disabled:e||f,placeholder:k,"aria-label":"Command",className:"h-9 min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground disabled:opacity-50"}),f?r.jsx(le,{className:"size-3.5 shrink-0 animate-spin text-muted-foreground"}):r.jsx("button",{type:"button",onClick:g,disabled:e||!d.trim(),title:"Send","aria-label":"Send",className:"flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&:not(:disabled)]:text-primary",children:r.jsx(ba,{className:"size-3.5"})})]})}),l&&r.jsx("p",{className:"mt-2 text-xs leading-snug text-muted-foreground","aria-live":"polite",children:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Press Enter again to continue."}),i&&r.jsxs("div",{className:`mt-2 flex items-start gap-2 text-xs ${i.error?"text-destructive":"text-muted-foreground"}`,"aria-live":"polite",children:[r.jsx("p",{className:"min-w-0 flex-1 leading-snug",children:i.error?i.error:i.action==="open_tab"?`Jumped to “${i.tabTitle}”`:i.action==="create_group"?`Created “${i.groupName}” with ${i.tabCount} tab${i.tabCount===1?"":"s"}`:i.action==="add_to_group"?`Moved ${i.tabCount} tab${i.tabCount===1?"":"s"} into “${i.groupName}”`:i.action==="update_group"?i.previousName&&i.previousName!==i.groupName?`Renamed “${i.previousName}” to “${i.groupName}”`:`Updated “${i.groupName}”`:i.action==="ungroup"?`Ungrouped ${i.tabCount} tab${i.tabCount===1?"":"s"} from ${i.groupCount} group${i.groupCount===1?"":"s"}`:i.action==="remove_duplicates"?i.closedCount?`Closed ${i.closedCount} duplicate tab${i.closedCount===1?"":"s"}`:"No duplicate tabs found":i.action==="merge_groups"?`Merged ${i.groupCount} groups into “${i.groupName}” · ${i.tabCount} tabs`:i.reply}),i.action==="answer"&&typeof i.tabId=="number"&&r.jsxs("button",{onClick:()=>y(i.tabId),className:"flex shrink-0 items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px] text-foreground transition-colors hover:bg-muted",children:["Go to tab ",r.jsx(Ke,{className:"size-3"})]})]}),i?.action==="remove_duplicates"&&i.closedTabs&&i.closedTabs.length>0&&r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"mt-2 max-h-32 space-y-1.5 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 text-xs",children:i.closedTabs.map((x,v)=>r.jsxs("li",{className:"min-w-0",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:x.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:x.url})]},`${x.url}-${v}`))})]})}const Ye={collecting:{label:"Reading titles",progress:18},classifying:{label:"Finding themes",progress:48},reading:{label:"Reading ambiguous pages",progress:68},applying:{label:"Creating tab groups",progress:88}};function lr({job:t}){const e=Ye[t?.stage||"collecting"]??Ye.collecting,a=t?.tabCount||0;return r.jsxs("section",{className:"mt-6","aria-live":"polite","aria-label":`${e.label}. Organizing tabs.`,children:[r.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:a?`Organizing ${a} tabs`:"Organizing tabs"}),r.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.label}),r.jsxs("div",{className:"tab-rail mt-6","aria-hidden":"true",children:[r.jsx("div",{className:"tab-rail-line"}),[0,1,2,3].map(o=>r.jsx("span",{className:"tab-rail-item",style:{animationDelay:`${o*-.58}s`},children:r.jsx("span",{className:"tab-rail-notch"})},o)),r.jsx("span",{className:"tab-rail-arrow",children:"→"}),r.jsxs("span",{className:"tab-rail-groups",children:[r.jsx("span",{}),r.jsx("span",{})]})]}),r.jsxs("div",{className:"mt-5 flex items-center justify-between gap-3 text-xs",children:[r.jsx("span",{className:"text-muted-foreground",children:e.label}),r.jsxs("span",{className:"tabular-nums text-foreground",children:[e.progress,"%"]})]}),r.jsx("div",{className:"mt-2 h-0.5 overflow-hidden rounded-full bg-muted",children:r.jsx("div",{className:"organize-progress h-full origin-left bg-primary transition-transform duration-500 [transition-timing-function:var(--ease-out-strong)]",style:{transform:`scaleX(${e.progress/100})`}})}),r.jsxs("div",{className:"mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground",children:[r.jsx(fa,{className:"size-4 text-primary"}),r.jsx("span",{children:"Safe to close — progress continues"})]})]})}function cr({onDismiss:t}){return r.jsx("section",{className:"mt-4 rounded-lg border border-primary/35 bg-primary/10 p-3","aria-live":"polite",children:r.jsxs("div",{className:"flex items-start gap-2.5",children:[r.jsx(la,{className:"mt-0.5 size-4 shrink-0 text-primary"}),r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"text-sm font-medium leading-snug",children:"Pin Shelve to your toolbar"}),r.jsxs("p",{className:"mt-1 text-xs leading-snug text-muted-foreground",children:["Click the ",r.jsx(da,{className:"inline size-3.5 align-[-2px]","aria-label":"puzzle-piece"})," icon next to the address bar, then hit the pin beside Shelve so it’s always one click away."]}),r.jsx("div",{className:"mt-2",children:r.jsx(we,{onClick:t,variant:"ghost",size:"sm",children:"Got it"})})]})]})})}function fe({label:t,title:e,icon:a,onClick:o,disabled:s}){return r.jsxs("button",{title:e??t,"aria-label":e??t,onClick:o,disabled:s,className:"flex h-11 flex-col items-center justify-center gap-0.5 rounded-lg border border-border bg-transparent text-[10px] text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:bg-muted hover:text-foreground active:scale-[0.97] focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:[a,r.jsx("span",{className:"px-1 text-center leading-tight",children:t})]})}function dr({groups:t,selected:e,applying:a,onSelectedChange:o,onApply:s,onDiscard:n}){return r.jsxs("section",{className:"mt-5",children:[r.jsxs("div",{className:"mb-3",children:[r.jsx("h1",{className:"text-base font-semibold tracking-tight",children:"Review groups"}),r.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"Choose which suggestions to create."})]}),r.jsx("div",{className:"flex max-h-72 flex-col gap-1 overflow-y-auto",children:t.map((c,d)=>r.jsxs("label",{className:"review-item flex cursor-pointer items-start gap-2.5 rounded-md p-2 hover:bg-accent",style:{animationDelay:`${d*40}ms`},children:[r.jsx(Te,{className:"mt-0.5",checked:e.has(d),disabled:a,onCheckedChange:m=>{const f=new Set(e);m?f.add(d):f.delete(d),o(f)}}),r.jsxs("span",{className:"min-w-0",children:[r.jsxs("span",{className:"block text-sm font-medium leading-tight",children:[c.name,r.jsx("span",{className:"ml-1.5 font-normal text-muted-foreground",children:c.tabIds.length})]}),r.jsx("span",{className:"block truncate text-xs text-muted-foreground",children:c.tabTitles.join(" · ")})]})]},`${c.existingGroupId??"new"}-${d}`))}),r.jsxs("div",{className:"mt-3 flex gap-2",children:[r.jsx(we,{onClick:n,disabled:a,variant:"outline",className:"flex-1",size:"sm",children:"Discard"}),r.jsxs(we,{onClick:s,disabled:!e.size||a,className:"flex-1",size:"sm",children:[a?r.jsx(le,{className:"size-4 animate-spin"}):null,a?"Applying…":"Apply selected"]})]})]})}const xe={grey:"bg-zinc-400",blue:"bg-blue-500",red:"bg-red-500",yellow:"bg-yellow-400",green:"bg-green-500",pink:"bg-pink-500",purple:"bg-purple-500",cyan:"bg-cyan-500",orange:"bg-orange-500"};function Se(t){const e=t.loadedCount??t.tabCount;return e>=7?{label:"high",className:"text-orange-400"}:e>=3?{label:"med",className:"text-yellow-500"}:{label:"low",className:"text-muted-foreground"}}function pr(t){const e=Math.max(0,Math.round((Date.now()-t)/6e4));if(e<1)return"just now";if(e<60)return`${e}m ago`;const a=Math.round(e/60);return a<24?`${a}h ago`:`${Math.round(a/24)}d ago`}function br({groups:t,stashes:e,busyId:a,disabled:o,onStash:s,onResume:n,onDelete:c}){const[d,m]=b.useState(!1),[f,p]=b.useState(null);return!t.length&&!e.length?null:r.jsxs(r.Fragment,{children:[e.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Shelved projects",children:[r.jsx("h2",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:"Shelved"}),r.jsx("div",{className:"mt-1.5 flex flex-col gap-1",children:e.map(l=>{const u=l.resumeStatus==="resuming",i=o||u;return r.jsxs("div",{className:"rounded-md border border-border/70 px-2 py-1.5",children:[r.jsxs("div",{className:"flex items-center gap-2",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${xe[l.color]??xe.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs font-medium",children:l.name}),f===l.id?r.jsxs(r.Fragment,{children:[r.jsx("span",{className:"text-[11px] text-destructive",children:"Delete this shelved project?"}),r.jsx("button",{type:"button",onClick:()=>p(null),className:"rounded px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Cancel"}),r.jsx("button",{type:"button",disabled:i,onClick:async()=>{await c(l.id),p(null)},className:"rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] font-medium text-destructive outline-none transition-colors hover:bg-destructive/20 focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:"Delete"})]}):r.jsxs(r.Fragment,{children:[r.jsxs("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:[l.tabCount," · ",pr(l.createdAt)]}),r.jsx(ze,{title:"Resume",disabled:i,onClick:()=>n(l.id),children:a===l.id||u?r.jsx(le,{className:"size-3.5 animate-spin"}):r.jsx(Ge,{className:"size-3.5"})}),r.jsx(ze,{title:"Delete shelved project",disabled:i,onClick:()=>p(l.id),children:r.jsx(za,{className:"size-3.5"})})]})]}),u?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Resuming…"}):l.briefStatus==="pending"?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Writing where-you-left-off brief…"}):l.brief?r.jsx("p",{title:l.brief,className:"mt-1 line-clamp-2 pl-4 text-[11px] leading-snug text-muted-foreground",children:l.brief}):null]},l.id)})})]}),t.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Tab groups in this window",children:[r.jsxs("button",{type:"button",onClick:()=>m(l=>!l),"aria-expanded":d,"aria-controls":"groups-list",className:"flex h-7 w-full items-center justify-between rounded-md px-1.5 outline-none transition-colors hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:["Groups · ",t.length]}),r.jsx(Pe,{className:`size-3.5 text-muted-foreground transition-transform duration-200 [transition-timing-function:var(--ease-out-strong)] ${d?"rotate-180":""}`})]}),d&&r.jsx("div",{id:"groups-list",className:"mt-1 flex flex-col",children:t.map(l=>r.jsxs("div",{className:"flex h-8 items-center gap-2 rounded-md px-1.5 hover:bg-muted/50",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${xe[l.color]??xe.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs",children:l.title}),r.jsx("span",{title:`Approximate memory use: ${l.loadedCount??l.tabCount} of ${l.tabCount} tabs loaded`,className:`text-[10px] font-medium uppercase tracking-wide ${Se(l).className}`,children:Se(l).label}),r.jsx("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:l.tabCount}),r.jsx(ze,{title:`Shelve “${l.title}”`,disabled:o,onClick:()=>s(l.id),children:a===l.id?r.jsx(le,{className:"size-3.5 animate-spin"}):r.jsx(Be,{className:"size-3.5"})})]},l.id))})]})]})}function ze({title:t,disabled:e,onClick:a,children:o}){return r.jsx("button",{title:t,"aria-label":t,disabled:e,onClick:a,className:"flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:o})}const ur=[100,250,500,1e3,2500,5e3,1e4,25e3];function gr({refreshToken:t}){const[e,a]=b.useState(null);b.useEffect(()=>{let c=!1;return chrome.runtime.sendMessage({type:"getStats"}).then(d=>{!c&&d&&!d.error&&d.totals&&a(d)}).catch(()=>{}),()=>{c=!0}},[t]);const o=e?.totals?.tabsGrouped??0;if(!e||o<1)return null;const s=ur.find(c=>c>o),n=[`${o.toLocaleString()} tabs sorted`,(e.totals.stashes??0)>0?`${(e.totals.stashes??0).toLocaleString()} shelved`:null,e.streak>1?`${e.streak}-day streak`:null,e.weekTabs>0?`${e.weekTabs.toLocaleString()} this week`:null].filter(Boolean).join(" · ");return r.jsx("p",{"aria-label":"Your stats",title:s?`${(s-o).toLocaleString()} tabs to ${s.toLocaleString()}`:void 0,className:"mt-2 text-[11px] leading-snug text-muted-foreground tabular-nums",children:n})}function mr({dailyLimit:t,onDismiss:e}){const[a,o]=b.useState(null);return b.useEffect(()=>{let s=!1;return chrome.runtime.sendMessage({type:"getUpgradeInfo"}).then(n=>{s||o({paymentsEnabled:n?.paymentsEnabled===!0,checkoutUrl:n?.checkoutUrl||""})}).catch(()=>{s||o({paymentsEnabled:!1,checkoutUrl:""})}),()=>{s=!0}},[]),r.jsxs("section",{className:"mt-4 flex flex-col gap-3","aria-labelledby":"upgrade-heading",children:[r.jsxs("div",{children:[r.jsxs("h2",{id:"upgrade-heading",className:"text-sm font-semibold tracking-tight",children:["You're out of free actions",t?" for today":""]}),r.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:t?"They reset tomorrow — or keep going right now:":"Keep going with one of these:"})]}),r.jsxs("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex w-full flex-col items-start gap-1 rounded-lg border border-primary/50 bg-muted/40 p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary hover:bg-muted active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[r.jsx(ta,{className:"size-4 text-primary"}),"Add your own API key — free"]}),r.jsx("span",{className:"text-xs text-muted-foreground",children:"Unlimited actions with your OpenAI, Anthropic, Gemini, or Ollama key. Shelve itself stays free."})]}),a?.paymentsEnabled&&a.checkoutUrl&&r.jsxs("a",{href:a.checkoutUrl,target:"_blank",rel:"noreferrer",className:"flex w-full flex-col items-start gap-1 rounded-lg border border-border p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted/50 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[r.jsx(ka,{className:"size-4"}),"Shelve Hosted — $5/mo"]}),r.jsx("span",{className:"text-xs text-muted-foreground",children:"No key to manage; more actions on the hosted model."})]}),r.jsx("button",{onClick:e,className:"self-center rounded-md px-2 py-1 text-xs text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Not now"})]})}function fr({windowId:t,running:e,setRunning:a,setStatus:o,setGroups:s,setSelected:n,setReviewMinSize:c,setOrganizeClosedTabs:d,refreshUndo:m,refreshPanels:f,onQuotaExhausted:p}){const[l,u]=b.useState(null),i=b.useRef(!1),z=b.useRef(null),k=b.useCallback(async g=>{!t||!g||(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:t,jobId:g}),u(null))},[t]),w=b.useCallback(async(g,y)=>{if(y&&z.current===y)return;y&&(z.current=y),a(null),await m();const x=Array.isArray(g?.closedTabs)?g.closedTabs:[];if(!g||g.error){d([]),o({text:g?.error??"Something went wrong.",error:!0,closedTabs:x}),g?.quota&&p?.(g.error??""),await k(y);return}if(g.review&&g.groups){d(x),s(g.groups),n(new Set(g.groups.map((v,$)=>$))),c(g.minSize||1),o(null);return}d([]),o({text:`${g.groupCount} group${g.groupCount===1?"":"s"} · ${g.tabCount} tabs sorted`,closedTabs:x}),await k(y),await f()},[k,m,f,p,s,d,c,a,n,o]),C=e==="organize"||l?.status==="running";return b.useEffect(()=>{if(!t)return;let g=!1,y;const x=async()=>{let v=!1;try{const $=await chrome.runtime.sendMessage({type:"organizeStatus",windowId:t});if(g)return;const N=$?.job;N?.status==="running"?(u(N),a("organize"),o(null),v=!0):N&&!i.current&&z.current!==N.id&&(u(N),await w(N.result||{error:N.error},N.id))}catch{}!g&&v&&(y=window.setTimeout(x,450))};return x(),()=>{g=!0,y&&window.clearTimeout(y)}},[w,t,C,a,o]),{organizeJob:l,setOrganizeJob:u,consumeJob:k,handleOrganizeResult:w,ownsOrganizeRequest:i,handledJobId:z,organizeActive:C}}function xr({windowId:t,setRunning:e,setStatus:a,refreshUndo:o,refreshPanels:s,refreshWindowCount:n}){return{ungroup:async()=>{e("ungroup"),a(null);const p=await chrome.runtime.sendMessage({type:"ungroupAll",windowId:t});e(null),await Promise.all([o(),s()]),a(p?.error?{text:p.error,error:!0}:{text:`${p.tabCount} tab${p.tabCount===1?"":"s"} ungrouped`})},cleanDuplicates:async()=>{e("duplicates"),a(null);const p=await chrome.runtime.sendMessage({type:"cleanDuplicates",windowId:t});e(null),await Promise.all([o(),s()]),a(p?.error?{text:p.error,error:!0}:{text:p.closedCount?`Closed ${p.closedCount} duplicate tab${p.closedCount===1?"":"s"}`:"No duplicate tabs found",closedTabs:Array.isArray(p.closedTabs)?p.closedTabs:[]})},merge:async()=>{e("merge"),a(null);const p=await chrome.runtime.sendMessage({type:"mergeWindows",windowId:t});if(e(null),p?.error){a({text:p.error,error:!0});return}await Promise.all([n(),s()]),a({text:`Merged ${p.windows} window${p.windows===1?"":"s"} · ${p.tabs} tabs`})},undo:async()=>{e("undo"),a(null);const p=await chrome.runtime.sendMessage({type:"undo",windowId:t});if(e(null),await Promise.all([o(),s()]),p?.error){a({text:p.error,error:!0});return}a({text:p?.skippedCount?`Restored the available layout — ${p.skippedCount} tab${p.skippedCount===1?"":"s"} closed since couldn't be brought back`:"Previous tab layout restored"})}}}function hr({windowId:t,acknowledged:e,acknowledgeNotice:a,setStatus:o,refreshPanels:s}){const[n,c]=b.useState(null),[d,m]=b.useState(null);return{stashBusy:n,stashGroup:async u=>{if(!e){if(d!==u){m(u),o({text:"Stash briefs send tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Click again to continue."});return}m(null),await a()}c(u),o(null);let i;try{i=await chrome.runtime.sendMessage({type:"stashGroup",windowId:t,groupId:u})}finally{c(null)}await s(),o(i?.error?{text:i.error,error:!0}:{text:`Stashed “${i.stash?.name}” · ${i.stash?.tabCount} tabs`})},resumeStash:async u=>{c(u),o(null);let i;try{i=await chrome.runtime.sendMessage({type:"resumeStash",stashId:u,windowId:t})}finally{c(null)}await s(),o(i?.error?{text:i.error,error:!0}:{text:`Restored ${i.tabCount} tab${i.tabCount===1?"":"s"}`})},deleteStash:async u=>{const i=await chrome.runtime.sendMessage({type:"deleteStash",stashId:u});await s(),o(i?.error?{text:i.error,error:!0}:{text:"Stash deleted"})}}}const $r=typeof window<"u"&&new URLSearchParams(window.location.search).has("overlay"),Me=typeof window<"u"&&window.self!==window.top;function yr(){const[t,e]=b.useState(null),[a,o]=b.useState(null),[s,n]=b.useState([]),[c,d]=b.useState(new Set),[m,f]=b.useState(1),[p,l]=b.useState(),[u,i]=b.useState(1),[z,k]=b.useState(!1),[w,C]=b.useState(!1),[g,y]=b.useState(null),[x,v]=b.useState(!1),[$,N]=b.useState([]),[W,M]=b.useState([]),[H,X]=b.useState([]),[L,Z]=b.useState(Me?null:!0),[A,P]=b.useState(null);b.useEffect(()=>{if(!Me)return;let h=!1;return chrome.runtime.sendMessage({type:"overlayHandshake"}).then(j=>{h||Z(j?.allowed===!0)}).catch(()=>{h||Z(!1)}),()=>{h=!0}},[]);const D=b.useCallback(async(h=p)=>{if(!h)return;const j=await chrome.runtime.sendMessage({type:"hasUndo",windowId:h});k(!!j?.hasUndo)},[p]),R=b.useCallback(async()=>{const h=await chrome.runtime.sendMessage({type:"windowCount"});h?.count&&i(h.count)},[]);b.useEffect(()=>{const h=()=>{R().catch(()=>{})};return chrome.windows.onCreated?.addListener(h),chrome.windows.onRemoved.addListener(h),()=>{chrome.windows.onCreated?.removeListener(h),chrome.windows.onRemoved.removeListener(h)}},[R]);const Y=b.useCallback(async()=>{if(!p)return;const[h,j]=await Promise.all([chrome.runtime.sendMessage({type:"listGroups",windowId:p}),chrome.runtime.sendMessage({type:"listStashes",windowId:p})]);h?.groups&&N(h.groups),j?.stashes&&M(j.stashes)},[p]);b.useEffect(()=>{Y();const h=(j,q)=>{q==="local"&&j.stashes&&Y()};return chrome.storage.onChanged.addListener(h),()=>chrome.storage.onChanged.removeListener(h)},[Y]);const U=b.useCallback(h=>{P({dailyLimit:/reset tomorrow/i.test(h)}),o(j=>j?.closedTabs?.length?{text:"",closedTabs:j.closedTabs}:null)},[]),{organizeJob:T,setOrganizeJob:se,consumeJob:ee,handleOrganizeResult:de,ownsOrganizeRequest:ae,handledJobId:V,organizeActive:re}=fr({windowId:p,running:t,setRunning:e,setStatus:o,setGroups:n,setSelected:d,setReviewMinSize:f,setOrganizeClosedTabs:X,refreshUndo:D,refreshPanels:Y,onQuotaExhausted:U});b.useEffect(()=>{(async()=>{const h=await chrome.windows.getCurrent(),[j,q,ge]=await Promise.all([chrome.runtime.sendMessage({type:"hasUndo",windowId:h.id}),chrome.runtime.sendMessage({type:"windowCount"}),chrome.storage.local.get({dataNoticeAck:!1,pinPromptDismissed:!1})]);try{const qe=await chrome.action.getUserSettings();C(!qe.isOnToolbar&&!ge.pinPromptDismissed)}catch{}l(h.id),q?.count&&i(q.count),k(!!j?.hasUndo),y(!!ge.dataNoticeAck)})()},[]);const ye=async()=>{const h=!g;h&&(y(!0),await chrome.storage.local.set({dataNoticeAck:!0})),e("organize"),o(h?{text:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider."}:null),P(null),X([]),V.current=null,ae.current=!0;let j=await chrome.permissions.contains({origins:["<all_urls>"]});if(!j)try{j=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{j=!1}try{const q=await chrome.runtime.sendMessage({type:"organize",hasContentPermission:j,windowId:p});if(ae.current=!1,q?.running&&q.job){se(q.job);return}await de(q,q?.jobId)}catch{ae.current=!1,e(null),o({text:"Organizing was interrupted. Try again.",error:!0})}},ie=async()=>{const h=T?.id??V.current??void 0;try{if(p&&h&&!(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:p,jobId:h}))?.cleared){o({text:"Couldn't discard the suggestions — try again.",error:!0});return}n([]),d(new Set),se(null),o({text:H.length?`Suggestions discarded · ${H.length} duplicate tab${H.length===1?"":"s"} closed`:"Suggestions discarded.",closedTabs:H}),X([])}catch{o({text:"Couldn't discard the suggestions — try again.",error:!0})}},ve=async()=>{const h=s.filter((q,ge)=>c.has(ge));if(!h.length)return;e("apply");const j=await chrome.runtime.sendMessage({type:"applyPlan",groups:h,minSize:m,windowId:p});e(null),n([]),await Promise.all([D(),Y()]),await ee(T?.id??V.current??void 0),o(j?.error?{text:j.error,error:!0,closedTabs:H}:{text:`${j.groupCount} group${j.groupCount===1?"":"s"} created`,closedTabs:H}),X([])},pe=b.useCallback(async()=>{y(!0),await chrome.storage.local.set({dataNoticeAck:!0})},[]),{ungroup:S,cleanDuplicates:F,merge:G,undo:I}=xr({windowId:p,setRunning:e,setStatus:o,refreshUndo:D,refreshPanels:Y,refreshWindowCount:R}),{stashBusy:te,stashGroup:B,resumeStash:be,deleteStash:ue}=hr({windowId:p,acknowledged:g,acknowledgeNotice:pe,setStatus:o,refreshPanels:Y}),ne=s.length>0,E=re,_=!!t||ne||te!==null||x||g===null||p===void 0,J=(h,j)=>t===h?r.jsx(le,{className:"size-4 animate-spin"}):j;return L===null?null:L===!1?r.jsx("main",{className:"popup-shell w-[340px] p-4",children:r.jsx("p",{className:"text-xs text-muted-foreground",children:"Open Shelve from the toolbar icon to use it here."})}):r.jsx(je,{size:"md",colorVariant:"ocean",theme:"dark",strength:.45,borderRadius:$r?16:0,active:E||x,className:"popup-frame","data-testid":"window-beam",children:r.jsxs("main",{className:"popup-shell w-[340px] p-4",children:[r.jsxs("header",{className:"flex items-center justify-between",children:[r.jsxs("div",{className:"flex items-center gap-3",children:[r.jsx("img",{src:"icons/logo.svg",alt:"",className:"size-14"}),r.jsxs("span",{className:"flex items-baseline gap-1.5",children:[r.jsx("span",{className:"text-base font-semibold tracking-tight",children:"Shelve"}),r.jsxs("span",{className:"text-[9px] font-normal tracking-wide text-muted-foreground/50",children:["beta ",chrome.runtime.getManifest?.().version??"","b"]})]})]}),r.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex size-8 items-center justify-center rounded-md border border-transparent text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted hover:text-foreground active:scale-[0.96] focus-visible:ring-2 focus-visible:ring-ring",title:"Settings","aria-label":"Settings",children:r.jsx(ga,{className:"size-4"})})]}),A&&!E?r.jsx(mr,{dailyLimit:A.dailyLimit,onDismiss:()=>P(null)}):E?r.jsx(lr,{job:T}):ne||t==="apply"?r.jsx(dr,{groups:s,selected:c,applying:t==="apply",onSelectedChange:d,onApply:ve,onDiscard:ie}):r.jsxs(r.Fragment,{children:[w&&r.jsx(cr,{onDismiss:()=>{C(!1),chrome.storage.local.set({pinPromptDismissed:!0})}}),r.jsx(nr,{windowId:p,disabled:_&&!x,acknowledged:g===!0,onAcknowledge:pe,onRunningChange:v,onMutation:async()=>{await Promise.all([D(),Y()])},onQuotaExhausted:U}),r.jsx(je,{size:"md",colorVariant:"ocean",theme:"dark",strength:.4,active:g===!1||t==="organize"&&!E,className:"mt-3 w-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring","data-testid":"organize-beam",children:r.jsxs("button",{onClick:ye,disabled:_,className:"flex h-20 w-full flex-col items-center justify-center gap-2 rounded-lg border border-border bg-transparent text-sm font-medium text-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40","aria-label":"Organize tabs",children:[r.jsx(ha,{className:"size-5 text-primary"}),r.jsx("span",{children:"Organize tabs"})]})}),r.jsxs("div",{className:"mt-3 grid grid-cols-4 gap-1.5",children:[r.jsx(fe,{label:"Ungroup",onClick:S,disabled:_,icon:J("ungroup",r.jsx(sr,{className:"size-[18px]"}))}),r.jsx(fe,{label:"Duplicates",title:"Close duplicates",onClick:F,disabled:_,icon:J("duplicates",r.jsx(aa,{className:"size-4"}))}),r.jsx(fe,{label:"Merge",title:"Merge windows",onClick:G,disabled:_||u<=1,icon:J("merge",r.jsx(Ze,{className:"size-4"}))}),r.jsx(fe,{label:"Undo",onClick:I,disabled:_||!z,icon:J("undo",r.jsx(ya,{className:"size-4"}))})]}),r.jsx(br,{groups:$,stashes:W,busyId:te,disabled:_,onStash:B,onResume:be,onDelete:ue})]}),!E&&!A&&r.jsxs(r.Fragment,{children:[r.jsxs("div",{className:"mt-4 min-h-4 text-xs","aria-live":"polite",children:[r.jsx("p",{className:a?.error?"text-destructive":"text-muted-foreground",children:a?.text??""}),a?.closedTabs&&a.closedTabs.length>0&&r.jsx(ir,{closedTabs:a.closedTabs,onExpire:()=>o(null)})]}),r.jsx(gr,{refreshToken:a}),r.jsxs("a",{href:"mailto:prithvi@skive.in?subject=Shelve%20feature%20request&body=Hi%20Prithvi%2C%0A%0AI%27d%20like%20to%20request%3A%0A%0A",className:"mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted/50 hover:text-foreground active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsx(ia,{className:"size-3.5"}),"Request a feature"]})]})]})})}if(new URLSearchParams(window.location.search).has("overlay")){document.documentElement.dataset.overlay="";const t=()=>window.parent.postMessage({__shelveOverlay:!0,height:document.body.scrollHeight},"*");new ResizeObserver(t).observe(document.body),window.addEventListener("keydown",e=>{e.key==="Escape"&&window.parent.postMessage({__shelveOverlay:!0,close:!0},"*")})}De.createRoot(document.getElementById("root")).render(r.jsx(Ue.StrictMode,{children:r.jsx(yr,{})}));
