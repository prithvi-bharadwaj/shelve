import{c as F,r as b,j as t,o as Te,v as Ue,B as Ne,p as De,C as Ve,s as Ie,t as Ge}from"./rotatingPlaceholders-Bwe8Vd9V.js";const Be=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h2",key:"tvwodi"}],["path",{d:"M20 8v11a2 2 0 0 1-2 2h-2",key:"1gkqxj"}],["path",{d:"m9 15 3-3 3 3",key:"1pd0qc"}],["path",{d:"M12 12v9",key:"192myk"}]],Je=F("archive-restore",Be);const Ke=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],Qe=F("archive",Ke);const Ze=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],ea=F("arrow-right",Ze);const aa=[["path",{d:"M10 18H5a3 3 0 0 1-3-3v-1",key:"ru65g8"}],["path",{d:"M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"e30een"}],["path",{d:"M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"2ahx8o"}],["path",{d:"m7 21 3-3-3-3",key:"127cv2"}],["rect",{x:"14",y:"14",width:"8",height:"8",rx:"2",key:"1b0bso"}],["rect",{x:"2",y:"2",width:"8",height:"8",rx:"2",key:"1x09vl"}]],ta=F("combine",aa);const ra=[["line",{x1:"12",x2:"18",y1:"12",y2:"18",key:"1rg63v"}],["line",{x1:"12",x2:"18",y1:"18",y2:"12",key:"ebkxgr"}],["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],oa=F("copy-x",ra);const sa=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],ia=F("key-round",sa);const na=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],be=F("loader-circle",na);const la=[["path",{d:"M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",key:"12jkf8"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M19 16v6",key:"tddt3s"}],["path",{d:"M16 19h6",key:"xwg31i"}]],ca=F("mail-plus",la);const da=[["path",{d:"M12 17v5",key:"bb1du9"}],["path",{d:"M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",key:"1nkz8b"}]],pa=F("pin",da);const ba=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],ua=F("puzzle",ba);const ga=[["path",{d:"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",key:"117uat"}],["path",{d:"M6 12h16",key:"s4cdu5"}]],ma=F("send-horizontal",ga);const fa=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],xa=F("settings",fa);const ha=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],$a=F("shield-check",ha);const ya=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],va=F("sparkles",ya);const za=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],wa=F("undo-2",za);const ka=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],ja=F("x",ka);const Na=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],Ca=F("zap",Na),Wa={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},Ha={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},Q={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}}},_e={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function Xa(o){return _e[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Sa(o){return _e[o].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ya(o){return Q[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ma(o){const e=Q[o],a=o==="mono"?.225:.45;return e.border.map(r=>{const s=r.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${r.size.split(" ").map(n=>{const d=parseInt(n);return`${Math.round(d*.9)}px`}).join(" ")} at ${r.pos}, ${s}, transparent)`}).join(`,
    `)}function Oa(o,e){const a=Q[o];return e?a.spike:a.spikeLt}const Fa={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function Ra(o,e,a){return Fa[o][e?"dark":"light"].map(r=>{const s=r.offsetX===0?"":r.offsetX>0?` + ${r.offsetX}px`:` - ${Math.abs(r.offsetX)}px`,n=r.offsetY===0?"":r.offsetY>0?` + ${r.offsetY}px`:` - ${Math.abs(r.offsetY)}px`;return`radial-gradient(ellipse calc(${r.sizeW}px * var(--beam-w-${a})) calc(${r.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${s}) calc(100%${n}), ${r.color}, transparent)`}).join(`,
       `)}const _a={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function Aa(o,e){return _a[o].map(a=>{const r=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,s=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${r}) calc(100%${s}), ${a.color}, transparent)`}).join(`,
    `)}const qa={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}}};function he(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const r=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return r?`rgba(${r[1]}, ${r[2]}, ${r[3]}, ${e})`:o}function K(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const r=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return r?`rgba(${r[1]}, ${r[2]}, ${r[3]}, ${e.toFixed(2)})`:o}function La(o,e,a){const r=Oa(o,e),s=qa[o][e?"dark":"light"],n=o==="mono",d=n?.14:1,c=n?K(r.primary,.14):r.primary,f=n?K(r.primary,.09):r.primary,m=n?K(r.secondary,.12):r.secondary,u=n?he(r.secondary,.06):he(r.secondary,.49),i=s.spikes.map(H=>n?{color1:K(H.color1,d),color2:K(H.color2,d*.7)}:H),x=n?"12px":"0.8px",l=n?"14px":"2px",w=n?"12px":"1.2px",j=n?"10px":"0.6px",k=n?"42px":"92px",C=n?"38px":"72px",g=n?"40px":"85px",v=n?"32px":"60px",h=n?"12px":"1px",z=n?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",y=n?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",N=n?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",W=n?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",O=n?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",S=n?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${x} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${f} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${m}, ${u} 50%, transparent 95%),
       radial-gradient(ellipse calc(${l} * (2 - var(--beam-spike-${a}))) calc(${C} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${i[0].color1}, ${i[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${i[1].color1}, ${i[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${w} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${i[2].color1}, ${i[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${i[3].color1}, ${i[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${j} * (2 - var(--beam-spike-${a}))) calc(${v} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${i[4].color1}, ${i[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${z} 0%, ${y} 20%, ${N} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${W} 0%, ${O} 25%, ${S} 55%, transparent 80%)`;{const H=n?K(r.primary,.11):he(r.primary,.85),P=n?K(r.secondary,.09):he(r.secondary,.7);return`radial-gradient(ellipse calc(${x} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${H} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${m}, ${P} 50%, transparent 95%),
       radial-gradient(ellipse calc(${l} * (2 - var(--beam-spike-${a}))) calc(${C} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${i[0].color1}, ${i[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${i[1].color1}, ${i[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${w} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${i[2].color1}, ${i[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${i[3].color1}, ${i[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${h} * (2 - var(--beam-spike-${a}))) calc(${v} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${i[4].color1}, ${i[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const Ae=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],Ea=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],Pa=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],Se=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],Ta=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Ua(o,e,a){const r=o.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${r?`${r[1]}, ${r[2]}, ${r[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function He(o,e,a,r,s,n,d,c){return`radial-gradient(ellipse calc(${e}px * var(--bw${r}-${c}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${r}-${c}) * var(--bgh-${c}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${n} + var(--bx${r}-${c})) calc(${d} + var(--by${r}-${c})), ${Ua(o,s,c)}, transparent)`}function Da(o,e){return Q[o].border.map((a,r)=>{const{region:s,quad:n}=Ae[r],[d,c]=a.pos.split(" "),[f,m]=a.size.split(" ").map(parseFloat);return He(a.color,f,m,s,n,d,c,e)}).join(`,
    `)}function Va(o,e,a){const r=Q[o].border.map((c,f)=>{const{region:m,quad:u}=Ae[f],[i,x]=c.pos.split(" "),[l,w]=Ea[f];return He(c.color,l,w,m,u,i,x,e)}),s=a?"255, 255, 255":"0, 0, 0",n=a?.18:.08,d=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([c,f,m])=>`radial-gradient(ellipse 60px 60px at ${c} ${f}, rgba(${s}, calc(${n} * var(--bop-${m}-${e}))), transparent 70%)`);return[...r,...d].join(`,
    `)}function Ye(o,e,a){const r=Q[e].border;return o.map(s=>{const n=r[s.ci],[d,c]=n.pos.split(" ");return He(n.color,s.w,s.h,s.region,s.quad,s.x??d,s.y??c,a)}).join(`,
    `)}function qe(o,e,a){const r=Q[e].border,s=+a.toFixed(3);return o.map(n=>{const d=r[n.ci],[c,f]=d.pos.split(" "),m=n.x??c,u=n.y??f,i=d.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),x=i?`${i[1]}, ${i[2]}, ${i[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${n.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${n.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${m} ${u}, rgba(${x}, ${s}), transparent)`}).join(`,
    `)}function ue(o){return`
[data-beam="${o}"][data-paused],
[data-beam="${o}"][data-paused]::after,
[data-beam="${o}"][data-paused]::before,
[data-beam="${o}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function Le(o){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],r=e.map(n=>`@property --${n}-${o} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),s=a.map(n=>`@property --${n}-${o} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${r}

${s}

@property --beam-opacity-${o} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${o} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function Xe(o,e,a){const r=e==="dark",s=a/2.3;return o==="pulse-inner"?{sp:.28,dr:r?33:40,op:r?.48:.45,gh:r?.34:.22,bs:(r?1.9:2.6)*s,ss:(r?2.6:4.6)*s,ghs:(r?2.4:5.5)*s,huePeriod:16}:{sp:r?.28:.36,dr:r?14:19,op:r?.46:0,gh:r?.16:.58,bs:(r?2.3:3.7)*s,ss:(r?6.4:4.6)*s,ghs:(r?2.4:3.8)*s,huePeriod:14}}function Ia(o,e){const{sp:a,dr:r,op:s,gh:n,bs:d,ss:c,ghs:f}=e;return[{prop:`--bw1-${o}`,a:1-a,b:1+a*1.1,period:c*.9,delay:0,unit:""},{prop:`--bh1-${o}`,a:1+a*.9,b:1-a*.85,period:c*1.26,delay:0,unit:""},{prop:`--bx1-${o}`,a:-r,b:r*.9,period:d*1.6,delay:0,unit:"px"},{prop:`--by1-${o}`,a:r*.55,b:-r*.7,period:d*1.6,delay:0,unit:"px"},{prop:`--bw2-${o}`,a:1+a,b:1-a*.85,period:c*1.1,delay:0,unit:""},{prop:`--bh2-${o}`,a:1-a*.8,b:1+a*1.05,period:c*.81,delay:0,unit:""},{prop:`--bx2-${o}`,a:r*.8,b:-r*.9,period:d*1.88,delay:0,unit:"px"},{prop:`--by2-${o}`,a:-r,b:r*.65,period:d*1.88,delay:0,unit:"px"},{prop:`--bw3-${o}`,a:1-a*.6,b:1+a*1.15,period:c*.98,delay:0,unit:""},{prop:`--bh3-${o}`,a:1+a*.75,b:1-a,period:c*1.4,delay:0,unit:""},{prop:`--bx3-${o}`,a:-r*.6,b:r,period:d*1.45,delay:0,unit:"px"},{prop:`--by3-${o}`,a:-r*.85,b:r*.45,period:d*1.45,delay:0,unit:"px"},{prop:`--bgh-${o}`,a:1-n,b:1+n,period:f,delay:0,unit:""},{prop:`--bop-tl-${o}`,a:1-s,b:1,period:d,delay:0,unit:""},{prop:`--bop-tr-${o}`,a:1-s,b:1,period:d*1.32,delay:d*.28,unit:""},{prop:`--bop-bl-${o}`,a:1-s,b:1,period:d*.84,delay:d*.55,unit:""},{prop:`--bop-br-${o}`,a:1-s,b:1,period:d*1.58,delay:d*.83,unit:""}]}function Ga(o,e,a,r,s,n){if(o!=="pulse-inner"&&o!=="pulse-outside")return null;const d=Xe(o,e,a);return{oscillators:Ia(n,d),hue:s?null:{prop:`--beam-hue-${n}`,range:360,period:d.huePeriod,continuous:!0}}}function ve(o,e,a){return`  animation: ${e}-${o} ${a}s ease forwards;`}function Ba(o){const{size:e}=o;return e==="line"?et(o):e==="sm"?Ja(o):e==="pulse-inner"?Qa(o):e==="pulse-outside"?Za(o):Ka(o)}function Ja(o){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:n,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:i,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-r),k=m==="mono"?.5:1,C=n*k,g=d*k,v=c*k,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,y=w==="dark",N=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,W=Xa(m),O=Sa(m),S=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,H=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${W};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${O};
  box-shadow: inset 0 0 5px 1px ${f};
  -webkit-mask-image: ${H};
  -webkit-mask-composite: source-over;
  mask-image: ${H};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  filter: blur(8px) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${z}
${ue(e)}
`}function Ka(o){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:n,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:i,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-r),k=m==="mono"?.5:1,C=n*k,g=d*k,v=c*k,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,y=w==="dark",N=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,W=Ya(m),O=Ma(m),S=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${W};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${O};
  box-shadow: inset 0 0 9px 1px ${f};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  filter: blur(8px) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${z}
${ue(e)}
`}function Qa(o){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:n,innerOpacity:d,bloomOpacity:c,colorVariant:f,staticColors:m,brightness:u,saturation:i,hueRange:x,theme:l}=o,w=l==="dark",j=f==="mono"?.5:1,k=(n*j).toFixed(2),C=(d*j).toFixed(2),g=(c*j).toFixed(2),{op:v}=Xe("pulse-inner",l,s),h=8,z=u.toFixed(2),y=i.toFixed(2),N=m?`filter: brightness(${z}) saturate(${y});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${z}) saturate(${y});`,W=m?`filter: blur(${h}px) brightness(${z}) saturate(${y});`:`filter: blur(${h}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${z}) saturate(${y});`,O=Da(f,e),S=Va(f,e,w),H=qe(Pa,f,1-v*.5);return`
${Le(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ve(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ve(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${O};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${C} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${H};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${r}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${W}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ue(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function Za(o){const{id:e,borderRadius:a,duration:r,strokeOpacity:s,innerOpacity:n,bloomOpacity:d,colorVariant:c,staticColors:f,brightness:m,saturation:u,hueRange:i,theme:x,hairlineOpacity:l=0}=o,w=x==="dark",j=c==="mono"?.5:1,k=(s*j).toFixed(2),C=(n*j).toFixed(2),g=(d*j).toFixed(2),v=w?"70, 70, 70":"0, 0, 0",h=l.toFixed(2),z=`linear-gradient(rgba(${v}, ${h}), rgba(${v}, ${h}))`,{op:y}=Xe("pulse-outside",x,r),N=.95,W=.9,O=w?3:6,S=w?22.5:15,H=m.toFixed(2),P=u.toFixed(2),Z=f?`filter: brightness(${H}) saturate(${P});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${H}) saturate(${P});`,_=`brightness(var(--beam-glow-brightness, ${H})) saturate(var(--beam-glow-saturate, ${P}))`,T=f?`filter: blur(var(--beam-core-blur, ${O}px)) ${_};`:`filter: blur(var(--beam-core-blur, ${O}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${_};`,ee=f?`filter: blur(var(--beam-bloom-blur, ${S}px)) ${_};`:`filter: blur(var(--beam-bloom-blur, ${S}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${_};`,q=Ye(Se,c,e),Y=Ye(Se,c,e),U=qe(Ta,c,1-y*.5),A=l>0?`${q},
    ${z}`:q;return`
${Le(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ve(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ve(e,"beam-fade-out",.5)}
}
${l>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${z};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${A};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${Z}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${Y};
  transform: scale(${N}, ${W});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${C} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${T}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${U};
  transform: scale(${N}, ${W});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${ee}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ue(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function et(o){const{id:e,borderRadius:a,borderWidth:r,duration:s,strokeOpacity:n,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:i,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-r),k=w==="dark",C=n,g=d,v=c,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,y=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l+10}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l+10}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l+10}deg)) brightness(${i.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,N=k?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,W=Ra(m,k,e),O=Aa(m,e),S=La(m,k,e),H=m==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${r}px;
  clip-path: inset(0 round ${a}px);
  background: ${N}, ${W};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${C.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${O};
  box-shadow: inset 0 0 9px 1px ${f};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${S};
  ${H}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${z}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${y}
${ue(e)}
`}const ze=new Set;let ie=null,Ce=0;const at=1e3/30-2,tt=Math.PI*2;function Me(o){return(1-Math.cos(tt*o))/2}function Ee(o){if(ie=requestAnimationFrame(Ee),o-Ce<at)return;Ce=o;const e=o/1e3;ze.forEach(({el:a,config:r})=>{for(const s of r.oscillators){const n=(e-s.delay)/s.period,d=s.a+(s.b-s.a)*Me(n);a.style.setProperty(s.prop,s.unit==="px"?`${d.toFixed(2)}px`:d.toFixed(4))}if(r.hue){const{prop:s,range:n,period:d,continuous:c}=r.hue,f=c?e/d%1*n:-n+2*n*Me(e/d);a.style.setProperty(s,`${f.toFixed(2)}deg`)}})}function rt(){ie==null&&(Ce=0,ie=requestAnimationFrame(Ee))}function ot(){ze.size===0&&ie!=null&&(cancelAnimationFrame(ie),ie=null)}function st(o,e){const a={el:o,config:e};return ze.add(a),rt(),()=>{ze.delete(a),ot()}}function it(){const[o,e]=b.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return b.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),r=s=>{e(s.matches?"dark":"light")};return a.addEventListener("change",r),()=>a.removeEventListener("change",r)},[]),o}function nt(o,e){return o==="auto"?e:o}const We=b.forwardRef(function({children:o,size:e="md",colorVariant:a="colorful",theme:r="dark",staticColors:s=!1,duration:n,active:d=!0,borderRadius:c,brightness:f,saturation:m,hueRange:u=30,strength:i=1,className:x,style:l,onActivate:w,onDeactivate:j,onAnimationEnd:k,...C},g){const v=b.useId().replace(/:/g,"-"),h=it(),z=b.useRef(null),[y,N]=b.useState(d),[W,O]=b.useState(!1),[S,H]=b.useState(!0),[P,Z]=b.useState(null),[_,T]=b.useState({x:1,y:1});b.useEffect(()=>{if(c!=null)return;const X=z.current;if(!X)return;const R=()=>{const V=X.firstElementChild;if(!V)return;const ce=getComputedStyle(V),I=parseFloat(ce.borderTopLeftRadius);!isNaN(I)&&I>0&&Z(I)};R();const D=new MutationObserver(R);return D.observe(X,{childList:!0,subtree:!1}),()=>D.disconnect()},[c,o]),b.useEffect(()=>{d&&!y&&!W?N(!0):!d&&y&&!W&&O(!0)},[d,y,W]),b.useEffect(()=>{const X=z.current;if(!X||typeof IntersectionObserver>"u")return;const R=new IntersectionObserver(D=>{for(const V of D)H(V.isIntersecting)},{rootMargin:"256px"});return R.observe(X),()=>R.disconnect()},[]),b.useEffect(()=>{if(e!=="pulse-outside"){T({x:1,y:1});return}const X=z.current;if(!X)return;const R=350,D=140,V=.35,ce=4,I=oe=>Math.max(V,Math.min(ce,oe)),ge=()=>{const oe=X.firstElementChild;if(!oe)return;const se=oe.getBoundingClientRect();if(!se.width||!se.height)return;const pe=+I(se.width/R).toFixed(3),G=+I(se.height/D).toFixed(3);T(L=>L.x===pe&&L.y===G?L:{x:pe,y:G})};if(ge(),typeof ResizeObserver>"u")return;const de=X.firstElementChild;if(!de)return;const me=new ResizeObserver(ge);return me.observe(de),()=>me.disconnect()},[e,o]);const ee=b.useCallback(X=>{const R=X.animationName;R.includes("fade-out")?(N(!1),O(!1),j?.()):R.includes("fade-in")&&w?.(),k?.(X)},[w,j,k]),q=nt(r,h),Y=Ha[e][q],U=Wa[e],A=e==="pulse-inner"||e==="pulse-outside",ae=c??P??U.borderRadius,M=n??(e==="line"?3.1:A?2.3:1.96),ne=m??Y.saturation,te=f??Y.brightness??1.3,B=e==="line"?Math.min(u,13):u,re=a==="mono"?!0:s,we=b.useMemo(()=>Ba({id:v,borderRadius:ae,borderWidth:U.borderWidth,duration:M,strokeOpacity:Y.strokeOpacity,innerOpacity:Y.innerOpacity,bloomOpacity:Y.bloomOpacity,innerShadow:Y.innerShadow,size:e,colorVariant:a,staticColors:re,brightness:te,saturation:ne,hueRange:B,theme:q,hairlineOpacity:Y.hairlineOpacity}),[v,ae,U.borderWidth,M,Y.strokeOpacity,Y.innerOpacity,Y.bloomOpacity,Y.innerShadow,Y.hairlineOpacity,e,a,re,te,ne,B,q]),J=b.useMemo(()=>A?Ga(e,q,M,B,re,v):null,[A,e,q,M,B,re,v]);b.useEffect(()=>{var X;if(!J||!(y||W)||!S)return;const R=z.current;if(R&&!(typeof window<"u"&&(X=window.matchMedia)!=null&&X.call(window,"(prefers-reduced-motion: reduce)").matches))return st(R,J)},[J,y,W,S]);const le=b.useCallback(X=>{z.current=X,typeof g=="function"?g(X):g&&(g.current=X)},[g]),ke={...l??{},"--beam-strength":Math.max(0,Math.min(1,i)),...e==="pulse-outside"?{"--pulse-glow-sx":_.x,"--pulse-glow-sy":_.y}:{}};return t.jsxs(t.Fragment,{children:[t.jsx("style",{children:we}),t.jsxs("div",{...C,ref:le,"data-beam":v,"data-active":y&&!W?"":void 0,"data-fading":W?"":void 0,"data-paused":y&&!W&&!S?"":void 0,className:x,style:ke,onAnimationEnd:ee,children:[o,t.jsx("div",{"data-beam-bloom":!0})]})]})});function lt({className:o,...e}){return t.jsxs("svg",{viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",className:o,...e,children:[t.jsx("path",{d:"M7 4H4.75A1.75 1.75 0 0 0 3 5.75v8.5A1.75 1.75 0 0 0 4.75 16H7"}),t.jsx("path",{d:"M8.5 6.5h5M8.5 10h7M8.5 13.5h3.5"}),t.jsx("path",{d:"m13.5 4 2-1m0 14 2-1"})]})}function ct({closedTabs:o,onExpire:e}){return t.jsxs("div",{className:"closed-toast relative mt-2 overflow-hidden rounded-md border border-border bg-muted/20",children:[t.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"max-h-36 space-y-1.5 overflow-y-auto p-2 pb-2.5",children:o.map((a,r)=>t.jsxs("li",{className:"flex min-w-0 items-center gap-2",children:[t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:a.title||"Untitled tab"}),t.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:a.url})]}),a.keptTabId!==void 0&&t.jsx("button",{type:"button",onClick:()=>chrome.runtime.sendMessage({type:"focusTab",tabId:a.keptTabId}),className:"shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"View existing"})]},`${a.url}-${r}`))}),t.jsx("div",{"data-testid":"closed-toast-timer",className:"closed-toast-timer absolute inset-x-0 bottom-0 h-0.5 origin-left bg-primary/60",onAnimationEnd:e})]})}function dt({windowId:o,disabled:e,acknowledged:a,onAcknowledge:r,onRunningChange:s,onMutation:n,onQuotaExhausted:d}){const[c,f]=b.useState(""),[m,u]=b.useState(!1),[i,x]=b.useState(!1),[l,w]=b.useState(null),j=Te(Ue),k=b.useRef(!1),C=b.useRef(s);C.current=s,b.useEffect(()=>()=>{k.current&&C.current(!1)},[]);const g=async()=>{const h=c.trim();if(!(!h||k.current||e)){if(!a&&!i){x(!0),w(null);return}i&&(x(!1),await r()),k.current=!0,u(!0),s(!0),w(null);try{let z=await chrome.permissions.contains({origins:["<all_urls>"]});if(!z)try{z=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{z=!1}const y=await chrome.runtime.sendMessage({type:"command",query:h,windowId:o,hasContentPermission:z});if(y?.quota&&y.error){d?.(y.error),w(null);return}w(y??{error:"Something went wrong."}),["create_group","add_to_group","update_group","ungroup","remove_duplicates","merge_groups"].includes(y?.action||"")&&!y.error&&(f(""),await n?.().catch(()=>{}))}catch{w({error:"Command was interrupted. Try again."})}finally{k.current=!1,u(!1),s(!1)}}},v=async h=>{await chrome.runtime.sendMessage({type:"focusTab",tabId:h})};return t.jsxs("section",{className:"mt-4","aria-label":"Command bar",children:[t.jsx(We,{size:"line",colorVariant:"ocean",theme:"dark",strength:.35,active:m,className:"w-full focus-within:ring-2 focus-within:ring-ring/30","data-testid":"command-beam",children:t.jsxs("div",{className:"flex items-center gap-2 rounded-lg border border-border bg-muted/20 px-2.5 focus-within:border-ring",children:[t.jsx("input",{value:c,onChange:h=>f(h.target.value),onKeyDown:h=>{h.key==="Enter"&&g()},disabled:e||m,placeholder:j,"aria-label":"Command",className:"h-9 min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground disabled:opacity-50"}),m?t.jsx(be,{className:"size-3.5 shrink-0 animate-spin text-muted-foreground"}):t.jsx("button",{type:"button",onClick:g,disabled:e||!c.trim(),title:"Send","aria-label":"Send",className:"flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&:not(:disabled)]:text-primary",children:t.jsx(ma,{className:"size-3.5"})})]})}),i&&t.jsx("p",{className:"mt-2 text-xs leading-snug text-muted-foreground","aria-live":"polite",children:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Press Enter again to continue."}),l&&t.jsxs("div",{className:`mt-2 flex items-start gap-2 text-xs ${l.error?"text-destructive":"text-muted-foreground"}`,"aria-live":"polite",children:[t.jsx("p",{className:"min-w-0 flex-1 leading-snug",children:l.error?l.error:l.action==="open_tab"?`Jumped to “${l.tabTitle}”`:l.action==="create_group"?`Created “${l.groupName}” with ${l.tabCount} tab${l.tabCount===1?"":"s"}`:l.action==="add_to_group"?`Moved ${l.tabCount} tab${l.tabCount===1?"":"s"} into “${l.groupName}”`:l.action==="update_group"?l.previousName&&l.previousName!==l.groupName?`Renamed “${l.previousName}” to “${l.groupName}”`:`Updated “${l.groupName}”`:l.action==="ungroup"?`Ungrouped ${l.tabCount} tab${l.tabCount===1?"":"s"} from ${l.groupCount} group${l.groupCount===1?"":"s"}`:l.action==="remove_duplicates"?l.closedCount?`Closed ${l.closedCount} duplicate tab${l.closedCount===1?"":"s"}`:"No duplicate tabs found":l.action==="merge_groups"?`Merged ${l.groupCount} groups into “${l.groupName}” · ${l.tabCount} tabs`:l.reply}),l.action==="answer"&&typeof l.tabId=="number"&&t.jsxs("button",{onClick:()=>v(l.tabId),className:"flex shrink-0 items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px] text-foreground transition-colors hover:bg-muted",children:["Go to tab ",t.jsx(ea,{className:"size-3"})]})]}),l?.action==="remove_duplicates"&&l.closedTabs&&l.closedTabs.length>0&&t.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"mt-2 max-h-32 space-y-1.5 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 text-xs",children:l.closedTabs.map((h,z)=>t.jsxs("li",{className:"min-w-0",children:[t.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:h.title||"Untitled tab"}),t.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:h.url})]},`${h.url}-${z}`))})]})}const Oe={collecting:{label:"Reading titles",progress:18},classifying:{label:"Finding themes",progress:48},reading:{label:"Reading ambiguous pages",progress:68},applying:{label:"Creating tab groups",progress:88}};function pt({job:o}){const e=Oe[o?.stage||"collecting"]??Oe.collecting,a=o?.tabCount||0;return t.jsxs("section",{className:"mt-6","aria-live":"polite","aria-label":`${e.label}. Organizing tabs.`,children:[t.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:a?`Organizing ${a} tabs`:"Organizing tabs"}),t.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.label}),t.jsxs("div",{className:"tab-rail mt-6","aria-hidden":"true",children:[t.jsx("div",{className:"tab-rail-line"}),[0,1,2,3].map(r=>t.jsx("span",{className:"tab-rail-item",style:{animationDelay:`${r*-.58}s`},children:t.jsx("span",{className:"tab-rail-notch"})},r)),t.jsx("span",{className:"tab-rail-arrow",children:"→"}),t.jsxs("span",{className:"tab-rail-groups",children:[t.jsx("span",{}),t.jsx("span",{})]})]}),t.jsxs("div",{className:"mt-5 flex items-center justify-between gap-3 text-xs",children:[t.jsx("span",{className:"text-muted-foreground",children:e.label}),t.jsxs("span",{className:"tabular-nums text-foreground",children:[e.progress,"%"]})]}),t.jsx("div",{className:"mt-2 h-0.5 overflow-hidden rounded-full bg-muted",children:t.jsx("div",{className:"organize-progress h-full origin-left bg-primary transition-transform duration-500 [transition-timing-function:var(--ease-out-strong)]",style:{transform:`scaleX(${e.progress/100})`}})}),t.jsxs("div",{className:"mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground",children:[t.jsx($a,{className:"size-4 text-primary"}),t.jsx("span",{children:"Safe to close — progress continues"})]})]})}function bt({onDismiss:o}){return t.jsx("section",{className:"mt-4 rounded-lg border border-primary/35 bg-primary/10 p-3","aria-live":"polite",children:t.jsxs("div",{className:"flex items-start gap-2.5",children:[t.jsx(pa,{className:"mt-0.5 size-4 shrink-0 text-primary"}),t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsx("p",{className:"text-sm font-medium leading-snug",children:"Pin Shelve to your toolbar"}),t.jsxs("p",{className:"mt-1 text-xs leading-snug text-muted-foreground",children:["Click the ",t.jsx(ua,{className:"inline size-3.5 align-[-2px]","aria-label":"puzzle-piece"})," icon next to the address bar, then hit the pin beside Shelve so it’s always one click away."]}),t.jsx("div",{className:"mt-2",children:t.jsx(Ne,{onClick:o,variant:"ghost",size:"sm",children:"Got it"})})]})]})})}function $e({label:o,title:e,icon:a,onClick:r,disabled:s}){return t.jsxs("button",{title:e??o,"aria-label":e??o,onClick:r,disabled:s,className:"flex h-11 flex-col items-center justify-center gap-0.5 rounded-lg border border-border bg-transparent text-[10px] text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:bg-muted hover:text-foreground active:scale-[0.97] focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:[a,t.jsx("span",{className:"px-1 text-center leading-tight",children:o})]})}function ut({groups:o,selected:e,applying:a,onSelectedChange:r,onApply:s,onDiscard:n}){return t.jsxs("section",{className:"mt-5",children:[t.jsxs("div",{className:"mb-3",children:[t.jsx("h1",{className:"text-base font-semibold tracking-tight",children:"Review groups"}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"Choose which suggestions to create."})]}),t.jsx("div",{className:"flex max-h-72 flex-col gap-1 overflow-y-auto",children:o.map((d,c)=>t.jsxs("label",{className:"review-item flex cursor-pointer items-start gap-2.5 rounded-md p-2 hover:bg-accent",style:{animationDelay:`${c*40}ms`},children:[t.jsx(De,{className:"mt-0.5",checked:e.has(c),disabled:a,onCheckedChange:f=>{const m=new Set(e);f?m.add(c):m.delete(c),r(m)}}),t.jsxs("span",{className:"min-w-0",children:[t.jsxs("span",{className:"block text-sm font-medium leading-tight",children:[d.name,t.jsx("span",{className:"ml-1.5 font-normal text-muted-foreground",children:d.tabIds.length})]}),t.jsx("span",{className:"block truncate text-xs text-muted-foreground",children:d.tabTitles.join(" · ")})]})]},`${d.existingGroupId??"new"}-${c}`))}),t.jsxs("div",{className:"mt-3 flex gap-2",children:[t.jsx(Ne,{onClick:n,disabled:a,variant:"outline",className:"flex-1",size:"sm",children:"Discard"}),t.jsxs(Ne,{onClick:s,disabled:!e.size||a,className:"flex-1",size:"sm",children:[a?t.jsx(be,{className:"size-4 animate-spin"}):null,a?"Applying…":"Apply selected"]})]})]})}const ye={grey:"bg-zinc-400",blue:"bg-blue-500",red:"bg-red-500",yellow:"bg-yellow-400",green:"bg-green-500",pink:"bg-pink-500",purple:"bg-purple-500",cyan:"bg-cyan-500",orange:"bg-orange-500"};function Fe(o){const e=o.loadedCount??o.tabCount;return e>=7?{label:"high",className:"text-orange-400"}:e>=3?{label:"med",className:"text-yellow-500"}:{label:"low",className:"text-muted-foreground"}}function gt(o){const e=Math.max(0,Math.round((Date.now()-o)/6e4));if(e<1)return"just now";if(e<60)return`${e}m ago`;const a=Math.round(e/60);return a<24?`${a}h ago`:`${Math.round(a/24)}d ago`}function mt({groups:o,stashes:e,busyId:a,disabled:r,onStash:s,onResume:n,onDelete:d}){const[c,f]=b.useState(!1),[m,u]=b.useState(null);return!o.length&&!e.length?null:t.jsxs(t.Fragment,{children:[e.length>0&&t.jsxs("section",{className:"mt-4","aria-label":"Shelved projects",children:[t.jsx("h2",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:"Shelved"}),t.jsx("div",{className:"mt-1.5 flex flex-col gap-1",children:e.map(i=>{const x=i.resumeStatus==="resuming",l=r||x;return t.jsxs("div",{className:"rounded-md border border-border/70 px-2 py-1.5",children:[t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx("span",{className:`size-2 shrink-0 rounded-full ${ye[i.color]??ye.grey}`}),t.jsx("span",{className:"min-w-0 flex-1 truncate text-xs font-medium",children:i.name}),m===i.id?t.jsxs(t.Fragment,{children:[t.jsx("span",{className:"text-[11px] text-destructive",children:"Delete this shelved project?"}),t.jsx("button",{type:"button",onClick:()=>u(null),className:"rounded px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Cancel"}),t.jsx("button",{type:"button",disabled:l,onClick:async()=>{await d(i.id),u(null)},className:"rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] font-medium text-destructive outline-none transition-colors hover:bg-destructive/20 focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:"Delete"})]}):t.jsxs(t.Fragment,{children:[t.jsxs("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:[i.tabCount," · ",gt(i.createdAt)]}),t.jsx(je,{title:"Resume",disabled:l,onClick:()=>n(i.id),children:a===i.id||x?t.jsx(be,{className:"size-3.5 animate-spin"}):t.jsx(Je,{className:"size-3.5"})}),t.jsx(je,{title:"Delete shelved project",disabled:l,onClick:()=>u(i.id),children:t.jsx(ja,{className:"size-3.5"})})]})]}),x?t.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Resuming…"}):i.briefStatus==="pending"?t.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Writing where-you-left-off brief…"}):i.brief?t.jsx("p",{title:i.brief,className:"mt-1 line-clamp-2 pl-4 text-[11px] leading-snug text-muted-foreground",children:i.brief}):null]},i.id)})})]}),o.length>0&&t.jsxs("section",{className:"mt-4","aria-label":"Tab groups in this window",children:[t.jsxs("button",{type:"button",onClick:()=>f(i=>!i),"aria-expanded":c,"aria-controls":"groups-list",className:"flex h-7 w-full items-center justify-between rounded-md px-1.5 outline-none transition-colors hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:["Groups · ",o.length]}),t.jsx(Ve,{className:`size-3.5 text-muted-foreground transition-transform duration-200 [transition-timing-function:var(--ease-out-strong)] ${c?"rotate-180":""}`})]}),c&&t.jsx("div",{id:"groups-list",className:"mt-1 flex flex-col",children:o.map(i=>t.jsxs("div",{className:"flex h-8 items-center gap-2 rounded-md px-1.5 hover:bg-muted/50",children:[t.jsx("span",{className:`size-2 shrink-0 rounded-full ${ye[i.color]??ye.grey}`}),t.jsx("span",{className:"min-w-0 flex-1 truncate text-xs",children:i.title}),t.jsx("span",{title:`Approximate memory use: ${i.loadedCount??i.tabCount} of ${i.tabCount} tabs loaded`,className:`text-[10px] font-medium uppercase tracking-wide ${Fe(i).className}`,children:Fe(i).label}),t.jsx("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:i.tabCount}),t.jsx(je,{title:`Shelve “${i.title}”`,disabled:r,onClick:()=>s(i.id),children:a===i.id?t.jsx(be,{className:"size-3.5 animate-spin"}):t.jsx(Qe,{className:"size-3.5"})})]},i.id))})]})]})}function je({title:o,disabled:e,onClick:a,children:r}){return t.jsx("button",{title:o,"aria-label":o,disabled:e,onClick:a,className:"flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:r})}const ft=[100,250,500,1e3,2500,5e3,1e4,25e3];function xt({refreshToken:o}){const[e,a]=b.useState(null);b.useEffect(()=>{let d=!1;return chrome.runtime.sendMessage({type:"getStats"}).then(c=>{!d&&c&&!c.error&&c.totals&&a(c)}).catch(()=>{}),()=>{d=!0}},[o]);const r=e?.totals?.tabsGrouped??0;if(!e||r<1)return null;const s=ft.find(d=>d>r),n=[`${r.toLocaleString()} tabs sorted`,(e.totals.stashes??0)>0?`${(e.totals.stashes??0).toLocaleString()} shelved`:null,e.streak>1?`${e.streak}-day streak`:null,e.weekTabs>0?`${e.weekTabs.toLocaleString()} this week`:null].filter(Boolean).join(" · ");return t.jsx("p",{"aria-label":"Your stats",title:s?`${(s-r).toLocaleString()} tabs to ${s.toLocaleString()}`:void 0,className:"mt-2 text-[11px] leading-snug text-muted-foreground tabular-nums",children:n})}function ht({dailyLimit:o,onDismiss:e}){const[a,r]=b.useState(null);return b.useEffect(()=>{let s=!1;return chrome.runtime.sendMessage({type:"getUpgradeInfo"}).then(n=>{s||r({paymentsEnabled:n?.paymentsEnabled===!0,checkoutUrl:n?.checkoutUrl||""})}).catch(()=>{s||r({paymentsEnabled:!1,checkoutUrl:""})}),()=>{s=!0}},[]),t.jsxs("section",{className:"mt-4 flex flex-col gap-3","aria-labelledby":"upgrade-heading",children:[t.jsxs("div",{children:[t.jsxs("h2",{id:"upgrade-heading",className:"text-sm font-semibold tracking-tight",children:["You're out of free actions",o?" for today":""]}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:o?"They reset tomorrow — or keep going right now:":"Keep going with one of these:"})]}),t.jsxs("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex w-full flex-col items-start gap-1 rounded-lg border border-primary/50 bg-muted/40 p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary hover:bg-muted active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[t.jsx(ia,{className:"size-4 text-primary"}),"Add your own API key — free"]}),t.jsx("span",{className:"text-xs text-muted-foreground",children:"Unlimited actions with your OpenAI, Anthropic, Gemini, or Ollama key. Shelve itself stays free."})]}),a?.paymentsEnabled&&a.checkoutUrl&&t.jsxs("a",{href:a.checkoutUrl,target:"_blank",rel:"noreferrer",className:"flex w-full flex-col items-start gap-1 rounded-lg border border-border p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted/50 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[t.jsx(Ca,{className:"size-4"}),"Shelve Hosted — $5/mo"]}),t.jsx("span",{className:"text-xs text-muted-foreground",children:"No key to manage; more actions on the hosted model."})]}),t.jsx("button",{onClick:e,className:"self-center rounded-md px-2 py-1 text-xs text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Not now"})]})}function $t({windowId:o,running:e,setRunning:a,setStatus:r,setGroups:s,setSelected:n,setReviewMinSize:d,setOrganizeClosedTabs:c,refreshUndo:f,refreshPanels:m,onQuotaExhausted:u}){const[i,x]=b.useState(null),l=b.useRef(!1),w=b.useRef(null),j=b.useCallback(async g=>{!o||!g||(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:o,jobId:g}),x(null))},[o]),k=b.useCallback(async(g,v)=>{if(v&&w.current===v)return;v&&(w.current=v),a(null),await f();const h=Array.isArray(g?.closedTabs)?g.closedTabs:[];if(!g||g.error){c([]),r({text:g?.error??"Something went wrong.",error:!0,closedTabs:h}),g?.quota&&u?.(g.error??""),await j(v);return}if(g.review&&g.groups){c(h),s(g.groups),n(new Set(g.groups.map((z,y)=>y))),d(g.minSize||1),r(null);return}c([]),r({text:`${g.groupCount} group${g.groupCount===1?"":"s"} · ${g.tabCount} tabs sorted`,closedTabs:h}),await j(v),await m()},[j,f,m,u,s,c,d,a,n,r]),C=e==="organize"||i?.status==="running";return b.useEffect(()=>{if(!o)return;let g=!1,v;const h=async()=>{let z=!1;try{const y=await chrome.runtime.sendMessage({type:"organizeStatus",windowId:o});if(g)return;const N=y?.job;N?.status==="running"?(x(N),a("organize"),r(null),z=!0):N&&!l.current&&w.current!==N.id&&(x(N),await k(N.result||{error:N.error},N.id))}catch{}!g&&z&&(v=window.setTimeout(h,450))};return h(),()=>{g=!0,v&&window.clearTimeout(v)}},[k,o,C,a,r]),{organizeJob:i,setOrganizeJob:x,consumeJob:j,handleOrganizeResult:k,ownsOrganizeRequest:l,handledJobId:w,organizeActive:C}}const yt=typeof window<"u"&&new URLSearchParams(window.location.search).has("overlay"),Re=typeof window<"u"&&window.self!==window.top;function vt(){const[o,e]=b.useState(null),[a,r]=b.useState(null),[s,n]=b.useState([]),[d,c]=b.useState(new Set),[f,m]=b.useState(1),[u,i]=b.useState(),[x,l]=b.useState(1),[w,j]=b.useState(!1),[k,C]=b.useState(!1),[g,v]=b.useState(null),[h,z]=b.useState(!1),[y,N]=b.useState([]),[W,O]=b.useState([]),[S,H]=b.useState(null),[P,Z]=b.useState(null),[_,T]=b.useState([]),[ee,q]=b.useState(Re?null:!0),[Y,U]=b.useState(null);b.useEffect(()=>{if(!Re)return;let p=!1;return chrome.runtime.sendMessage({type:"overlayHandshake"}).then($=>{p||q($?.allowed===!0)}).catch(()=>{p||q(!1)}),()=>{p=!0}},[]);const A=b.useCallback(async(p=u)=>{if(!p)return;const $=await chrome.runtime.sendMessage({type:"hasUndo",windowId:p});j(!!$?.hasUndo)},[u]),ae=b.useCallback(async()=>{const p=await chrome.runtime.sendMessage({type:"windowCount"});p?.count&&l(p.count)},[]);b.useEffect(()=>{const p=()=>{ae().catch(()=>{})};return chrome.windows.onCreated?.addListener(p),chrome.windows.onRemoved.addListener(p),()=>{chrome.windows.onCreated?.removeListener(p),chrome.windows.onRemoved.removeListener(p)}},[ae]);const M=b.useCallback(async()=>{if(!u)return;const[p,$]=await Promise.all([chrome.runtime.sendMessage({type:"listGroups",windowId:u}),chrome.runtime.sendMessage({type:"listStashes",windowId:u})]);p?.groups&&N(p.groups),$?.stashes&&O($.stashes)},[u]);b.useEffect(()=>{M();const p=($,E)=>{E==="local"&&$.stashes&&M()};return chrome.storage.onChanged.addListener(p),()=>chrome.storage.onChanged.removeListener(p)},[M]);const ne=b.useCallback(p=>{U({dailyLimit:/reset tomorrow/i.test(p)}),r($=>$?.closedTabs?.length?{text:"",closedTabs:$.closedTabs}:null)},[]),{organizeJob:te,setOrganizeJob:B,consumeJob:re,handleOrganizeResult:we,ownsOrganizeRequest:J,handledJobId:le,organizeActive:ke}=$t({windowId:u,running:o,setRunning:e,setStatus:r,setGroups:n,setSelected:c,setReviewMinSize:m,setOrganizeClosedTabs:T,refreshUndo:A,refreshPanels:M,onQuotaExhausted:ne});b.useEffect(()=>{(async()=>{const p=await chrome.windows.getCurrent(),[$,E,xe]=await Promise.all([chrome.runtime.sendMessage({type:"hasUndo",windowId:p.id}),chrome.runtime.sendMessage({type:"windowCount"}),chrome.storage.local.get({dataNoticeAck:!1,pinPromptDismissed:!1})]);try{const Pe=await chrome.action.getUserSettings();C(!Pe.isOnToolbar&&!xe.pinPromptDismissed)}catch{}i(p.id),E?.count&&l(E.count),j(!!$?.hasUndo),v(!!xe.dataNoticeAck)})()},[]);const X=async()=>{const p=!g;p&&(v(!0),await chrome.storage.local.set({dataNoticeAck:!0})),e("organize"),r(p?{text:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider."}:null),U(null),T([]),le.current=null,J.current=!0;let $=await chrome.permissions.contains({origins:["<all_urls>"]});if(!$)try{$=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{$=!1}try{const E=await chrome.runtime.sendMessage({type:"organize",hasContentPermission:$,windowId:u});if(J.current=!1,E?.running&&E.job){B(E.job);return}await we(E,E?.jobId)}catch{J.current=!1,e(null),r({text:"Organizing was interrupted. Try again.",error:!0})}},R=async()=>{const p=te?.id??le.current??void 0;try{if(u&&p&&!(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:u,jobId:p}))?.cleared){r({text:"Couldn't discard the suggestions — try again.",error:!0});return}n([]),c(new Set),B(null),r({text:_.length?`Suggestions discarded · ${_.length} duplicate tab${_.length===1?"":"s"} closed`:"Suggestions discarded.",closedTabs:_}),T([])}catch{r({text:"Couldn't discard the suggestions — try again.",error:!0})}},D=async()=>{const p=s.filter((E,xe)=>d.has(xe));if(!p.length)return;e("apply");const $=await chrome.runtime.sendMessage({type:"applyPlan",groups:p,minSize:f,windowId:u});e(null),n([]),await Promise.all([A(),M()]),await re(te?.id??le.current??void 0),r($?.error?{text:$.error,error:!0,closedTabs:_}:{text:`${$.groupCount} group${$.groupCount===1?"":"s"} created`,closedTabs:_}),T([])},V=async()=>{e("ungroup"),r(null);const p=await chrome.runtime.sendMessage({type:"ungroupAll",windowId:u});e(null),await Promise.all([A(),M()]),r(p?.error?{text:p.error,error:!0}:{text:`${p.tabCount} tab${p.tabCount===1?"":"s"} ungrouped`})},ce=async()=>{e("duplicates"),r(null);const p=await chrome.runtime.sendMessage({type:"cleanDuplicates",windowId:u});e(null),await Promise.all([A(),M()]),r(p?.error?{text:p.error,error:!0}:{text:p.closedCount?`Closed ${p.closedCount} duplicate tab${p.closedCount===1?"":"s"}`:"No duplicate tabs found",closedTabs:Array.isArray(p.closedTabs)?p.closedTabs:[]})},I=async()=>{e("merge"),r(null);const p=await chrome.runtime.sendMessage({type:"mergeWindows",windowId:u});if(e(null),p?.error){r({text:p.error,error:!0});return}await Promise.all([ae(),M()]),r({text:`Merged ${p.windows} window${p.windows===1?"":"s"} · ${p.tabs} tabs`})},ge=async()=>{e("undo"),r(null);const p=await chrome.runtime.sendMessage({type:"undo",windowId:u});if(e(null),await Promise.all([A(),M()]),p?.error){r({text:p.error,error:!0});return}r({text:p?.skippedCount?`Restored the available layout — ${p.skippedCount} tab${p.skippedCount===1?"":"s"} closed since couldn't be brought back`:"Previous tab layout restored"})},de=b.useCallback(async()=>{v(!0),await chrome.storage.local.set({dataNoticeAck:!0})},[]),me=async p=>{if(!g){if(P!==p){Z(p),r({text:"Stash briefs send tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Click again to continue."});return}Z(null),await de()}H(p),r(null);let $;try{$=await chrome.runtime.sendMessage({type:"stashGroup",windowId:u,groupId:p})}finally{H(null)}await M(),r($?.error?{text:$.error,error:!0}:{text:`Stashed “${$.stash?.name}” · ${$.stash?.tabCount} tabs`})},oe=async p=>{H(p),r(null);let $;try{$=await chrome.runtime.sendMessage({type:"resumeStash",stashId:p,windowId:u})}finally{H(null)}await M(),r($?.error?{text:$.error,error:!0}:{text:`Restored ${$.tabCount} tab${$.tabCount===1?"":"s"}`})},se=async p=>{const $=await chrome.runtime.sendMessage({type:"deleteStash",stashId:p});await M(),r($?.error?{text:$.error,error:!0}:{text:"Stash deleted"})},pe=s.length>0,G=ke,L=!!o||pe||S!==null||h||g===null||u===void 0,fe=(p,$)=>o===p?t.jsx(be,{className:"size-4 animate-spin"}):$;return ee===null?null:ee===!1?t.jsx("main",{className:"popup-shell w-[340px] p-4",children:t.jsx("p",{className:"text-xs text-muted-foreground",children:"Open Shelve from the toolbar icon to use it here."})}):t.jsx(We,{size:"md",colorVariant:"ocean",theme:"dark",strength:.45,borderRadius:yt?16:0,active:G||h,className:"popup-frame","data-testid":"window-beam",children:t.jsxs("main",{className:"popup-shell w-[340px] p-4",children:[t.jsxs("header",{className:"flex items-center justify-between",children:[t.jsxs("div",{className:"flex items-center gap-2.5",children:[t.jsx("img",{src:"icons/logo.svg",alt:"",className:"size-9"}),t.jsx("span",{className:"text-base font-semibold tracking-tight",children:"Shelve"})]}),t.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex size-8 items-center justify-center rounded-md border border-transparent text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted hover:text-foreground active:scale-[0.96] focus-visible:ring-2 focus-visible:ring-ring",title:"Settings","aria-label":"Settings",children:t.jsx(xa,{className:"size-4"})})]}),Y&&!G?t.jsx(ht,{dailyLimit:Y.dailyLimit,onDismiss:()=>U(null)}):G?t.jsx(pt,{job:te}):pe||o==="apply"?t.jsx(ut,{groups:s,selected:d,applying:o==="apply",onSelectedChange:c,onApply:D,onDiscard:R}):t.jsxs(t.Fragment,{children:[k&&t.jsx(bt,{onDismiss:()=>{C(!1),chrome.storage.local.set({pinPromptDismissed:!0})}}),t.jsx(dt,{windowId:u,disabled:L&&!h,acknowledged:g===!0,onAcknowledge:de,onRunningChange:z,onMutation:async()=>{await Promise.all([A(),M()])},onQuotaExhausted:ne}),t.jsx(We,{size:"md",colorVariant:"ocean",theme:"dark",strength:.4,active:g===!1||o==="organize"&&!G,className:"mt-3 w-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring","data-testid":"organize-beam",children:t.jsxs("button",{onClick:X,disabled:L,className:"flex h-20 w-full flex-col items-center justify-center gap-2 rounded-lg border border-border bg-transparent text-sm font-medium text-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40","aria-label":"Organize tabs",children:[t.jsx(va,{className:"size-5 text-primary"}),t.jsx("span",{children:"Organize tabs"})]})}),t.jsxs("div",{className:"mt-3 grid grid-cols-4 gap-1.5",children:[t.jsx($e,{label:"Ungroup",onClick:V,disabled:L,icon:fe("ungroup",t.jsx(lt,{className:"size-[18px]"}))}),t.jsx($e,{label:"Duplicates",title:"Close duplicates",onClick:ce,disabled:L,icon:fe("duplicates",t.jsx(oa,{className:"size-4"}))}),t.jsx($e,{label:"Merge",title:"Merge windows",onClick:I,disabled:L||x<=1,icon:fe("merge",t.jsx(ta,{className:"size-4"}))}),t.jsx($e,{label:"Undo",onClick:ge,disabled:L||!w,icon:fe("undo",t.jsx(wa,{className:"size-4"}))})]}),t.jsx(mt,{groups:y,stashes:W,busyId:S,disabled:L,onStash:me,onResume:oe,onDelete:se})]}),!G&&!Y&&t.jsxs(t.Fragment,{children:[t.jsxs("div",{className:"mt-4 min-h-4 text-xs","aria-live":"polite",children:[t.jsx("p",{className:a?.error?"text-destructive":"text-muted-foreground",children:a?.text??""}),a?.closedTabs&&a.closedTabs.length>0&&t.jsx(ct,{closedTabs:a.closedTabs,onExpire:()=>r(null)})]}),t.jsx(xt,{refreshToken:a}),t.jsxs("a",{href:"mailto:prithvi@skive.in?subject=Shelve%20feature%20request&body=Hi%20Prithvi%2C%0A%0AI%27d%20like%20to%20request%3A%0A%0A",className:"mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted/50 hover:text-foreground active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsx(ca,{className:"size-3.5"}),"Request a feature"]})]}),t.jsxs("p",{className:"mt-2 text-center text-[10px] tracking-wide text-muted-foreground/60",children:["beta ",chrome.runtime.getManifest?.().version??"","b"]})]})})}if(new URLSearchParams(window.location.search).has("overlay")){document.documentElement.dataset.overlay="";const o=()=>window.parent.postMessage({__shelveOverlay:!0,height:document.body.scrollHeight},"*");new ResizeObserver(o).observe(document.body),window.addEventListener("keydown",e=>{e.key==="Escape"&&window.parent.postMessage({__shelveOverlay:!0,close:!0},"*")})}Ie.createRoot(document.getElementById("root")).render(t.jsx(Ge.StrictMode,{children:t.jsx(vt,{})}));
