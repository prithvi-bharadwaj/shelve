import{c as O,r as b,j as r,o as Ve,v as Ie,B as He,p as Ge,C as Be,s as Je,t as Ke}from"./rotatingPlaceholders-CtysnXcJ.js";const Qe=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h2",key:"tvwodi"}],["path",{d:"M20 8v11a2 2 0 0 1-2 2h-2",key:"1gkqxj"}],["path",{d:"m9 15 3-3 3 3",key:"1pd0qc"}],["path",{d:"M12 12v9",key:"192myk"}]],Ze=O("archive-restore",Qe);const ea=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],aa=O("archive",ea);const ra=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],ta=O("arrow-right",ra);const oa=[["path",{d:"M10 18H5a3 3 0 0 1-3-3v-1",key:"ru65g8"}],["path",{d:"M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"e30een"}],["path",{d:"M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"2ahx8o"}],["path",{d:"m7 21 3-3-3-3",key:"127cv2"}],["rect",{x:"14",y:"14",width:"8",height:"8",rx:"2",key:"1b0bso"}],["rect",{x:"2",y:"2",width:"8",height:"8",rx:"2",key:"1x09vl"}]],sa=O("combine",oa);const ia=[["line",{x1:"12",x2:"18",y1:"12",y2:"18",key:"1rg63v"}],["line",{x1:"12",x2:"18",y1:"18",y2:"12",key:"ebkxgr"}],["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],na=O("copy-x",ia);const la=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],ca=O("key-round",la);const da=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],de=O("loader-circle",da);const pa=[["path",{d:"M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",key:"12jkf8"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M19 16v6",key:"tddt3s"}],["path",{d:"M16 19h6",key:"xwg31i"}]],ba=O("mail-plus",pa);const ua=[["path",{d:"M12 17v5",key:"bb1du9"}],["path",{d:"M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",key:"1nkz8b"}]],ga=O("pin",ua);const ma=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],fa=O("puzzle",ma);const xa=[["path",{d:"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",key:"117uat"}],["path",{d:"M6 12h16",key:"s4cdu5"}]],ha=O("send-horizontal",xa);const $a=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],ya=O("settings",$a);const va=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],za=O("shield-check",va);const wa=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],ka=O("sparkles",wa);const ja=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],Na=O("undo-2",ja);const Ca=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Wa=O("x",Ca);const Ha=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],Xa=O("zap",Ha),Sa={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},Ya={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},ee={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}}},Ee={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function Ma(o){return Ee[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Oa(o){return Ee[o].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Fa(o){return ee[o].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ra(o){const e=ee[o],a=o==="mono"?.225:.45;return e.border.map(t=>{const s=t.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${t.size.split(" ").map(i=>{const d=parseInt(i);return`${Math.round(d*.9)}px`}).join(" ")} at ${t.pos}, ${s}, transparent)`}).join(`,
    `)}function _a(o,e){const a=ee[o];return e?a.spike:a.spikeLt}const Aa={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function qa(o,e,a){return Aa[o][e?"dark":"light"].map(t=>{const s=t.offsetX===0?"":t.offsetX>0?` + ${t.offsetX}px`:` - ${Math.abs(t.offsetX)}px`,i=t.offsetY===0?"":t.offsetY>0?` + ${t.offsetY}px`:` - ${Math.abs(t.offsetY)}px`;return`radial-gradient(ellipse calc(${t.sizeW}px * var(--beam-w-${a})) calc(${t.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${s}) calc(100%${i}), ${t.color}, transparent)`}).join(`,
       `)}const Ea={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function La(o,e){return Ea[o].map(a=>{const t=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,s=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${t}) calc(100%${s}), ${a.color}, transparent)`}).join(`,
    `)}const Pa={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}}};function ve(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const t=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return t?`rgba(${t[1]}, ${t[2]}, ${t[3]}, ${e})`:o}function Z(o,e){const a=o.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const t=o.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return t?`rgba(${t[1]}, ${t[2]}, ${t[3]}, ${e.toFixed(2)})`:o}function Ta(o,e,a){const t=_a(o,e),s=Pa[o][e?"dark":"light"],i=o==="mono",d=i?.14:1,c=i?Z(t.primary,.14):t.primary,f=i?Z(t.primary,.09):t.primary,m=i?Z(t.secondary,.12):t.secondary,u=i?ve(t.secondary,.06):ve(t.secondary,.49),n=s.spikes.map(X=>i?{color1:Z(X.color1,d),color2:Z(X.color2,d*.7)}:X),x=i?"12px":"0.8px",l=i?"14px":"2px",w=i?"12px":"1.2px",j=i?"10px":"0.6px",k=i?"42px":"92px",W=i?"38px":"72px",g=i?"40px":"85px",v=i?"32px":"60px",h=i?"12px":"1px",z=i?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",y=i?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",N=i?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",H=i?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",Y=i?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",S=i?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${x} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${f} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${m}, ${u} 50%, transparent 95%),
       radial-gradient(ellipse calc(${l} * (2 - var(--beam-spike-${a}))) calc(${W} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${n[0].color1}, ${n[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${n[1].color1}, ${n[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${w} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${n[2].color1}, ${n[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${n[3].color1}, ${n[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${j} * (2 - var(--beam-spike-${a}))) calc(${v} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${n[4].color1}, ${n[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${z} 0%, ${y} 20%, ${N} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${H} 0%, ${Y} 25%, ${S} 55%, transparent 80%)`;{const X=i?Z(t.primary,.11):ve(t.primary,.85),q=i?Z(t.secondary,.09):ve(t.secondary,.7);return`radial-gradient(ellipse calc(${x} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${X} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${m}, ${q} 50%, transparent 95%),
       radial-gradient(ellipse calc(${l} * (2 - var(--beam-spike-${a}))) calc(${W} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${n[0].color1}, ${n[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${n[1].color1}, ${n[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${w} * (2 - var(--beam-spike2-${a}))) calc(${g} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${n[2].color1}, ${n[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${n[3].color1}, ${n[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${h} * (2 - var(--beam-spike-${a}))) calc(${v} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${n[4].color1}, ${n[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const Le=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],Ua=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],Da=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],Oe=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],Va=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Ia(o,e,a){const t=o.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${t?`${t[1]}, ${t[2]}, ${t[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function Ye(o,e,a,t,s,i,d,c){return`radial-gradient(ellipse calc(${e}px * var(--bw${t}-${c}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${t}-${c}) * var(--bgh-${c}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${i} + var(--bx${t}-${c})) calc(${d} + var(--by${t}-${c})), ${Ia(o,s,c)}, transparent)`}function Ga(o,e){return ee[o].border.map((a,t)=>{const{region:s,quad:i}=Le[t],[d,c]=a.pos.split(" "),[f,m]=a.size.split(" ").map(parseFloat);return Ye(a.color,f,m,s,i,d,c,e)}).join(`,
    `)}function Ba(o,e,a){const t=ee[o].border.map((c,f)=>{const{region:m,quad:u}=Le[f],[n,x]=c.pos.split(" "),[l,w]=Ua[f];return Ye(c.color,l,w,m,u,n,x,e)}),s=a?"255, 255, 255":"0, 0, 0",i=a?.18:.08,d=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([c,f,m])=>`radial-gradient(ellipse 60px 60px at ${c} ${f}, rgba(${s}, calc(${i} * var(--bop-${m}-${e}))), transparent 70%)`);return[...t,...d].join(`,
    `)}function Fe(o,e,a){const t=ee[e].border;return o.map(s=>{const i=t[s.ci],[d,c]=i.pos.split(" ");return Ye(i.color,s.w,s.h,s.region,s.quad,s.x??d,s.y??c,a)}).join(`,
    `)}function Pe(o,e,a){const t=ee[e].border,s=+a.toFixed(3);return o.map(i=>{const d=t[i.ci],[c,f]=d.pos.split(" "),m=i.x??c,u=i.y??f,n=d.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),x=n?`${n[1]}, ${n[2]}, ${n[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${i.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${i.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${m} ${u}, rgba(${x}, ${s}), transparent)`}).join(`,
    `)}function pe(o){return`
[data-beam="${o}"][data-paused],
[data-beam="${o}"][data-paused]::after,
[data-beam="${o}"][data-paused]::before,
[data-beam="${o}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function Te(o){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],t=e.map(i=>`@property --${i}-${o} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),s=a.map(i=>`@property --${i}-${o} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${t}

${s}

@property --beam-opacity-${o} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${o} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function Me(o,e,a){const t=e==="dark",s=a/2.3;return o==="pulse-inner"?{sp:.28,dr:t?33:40,op:t?.48:.45,gh:t?.34:.22,bs:(t?1.9:2.6)*s,ss:(t?2.6:4.6)*s,ghs:(t?2.4:5.5)*s,huePeriod:16}:{sp:t?.28:.36,dr:t?14:19,op:t?.46:0,gh:t?.16:.58,bs:(t?2.3:3.7)*s,ss:(t?6.4:4.6)*s,ghs:(t?2.4:3.8)*s,huePeriod:14}}function Ja(o,e){const{sp:a,dr:t,op:s,gh:i,bs:d,ss:c,ghs:f}=e;return[{prop:`--bw1-${o}`,a:1-a,b:1+a*1.1,period:c*.9,delay:0,unit:""},{prop:`--bh1-${o}`,a:1+a*.9,b:1-a*.85,period:c*1.26,delay:0,unit:""},{prop:`--bx1-${o}`,a:-t,b:t*.9,period:d*1.6,delay:0,unit:"px"},{prop:`--by1-${o}`,a:t*.55,b:-t*.7,period:d*1.6,delay:0,unit:"px"},{prop:`--bw2-${o}`,a:1+a,b:1-a*.85,period:c*1.1,delay:0,unit:""},{prop:`--bh2-${o}`,a:1-a*.8,b:1+a*1.05,period:c*.81,delay:0,unit:""},{prop:`--bx2-${o}`,a:t*.8,b:-t*.9,period:d*1.88,delay:0,unit:"px"},{prop:`--by2-${o}`,a:-t,b:t*.65,period:d*1.88,delay:0,unit:"px"},{prop:`--bw3-${o}`,a:1-a*.6,b:1+a*1.15,period:c*.98,delay:0,unit:""},{prop:`--bh3-${o}`,a:1+a*.75,b:1-a,period:c*1.4,delay:0,unit:""},{prop:`--bx3-${o}`,a:-t*.6,b:t,period:d*1.45,delay:0,unit:"px"},{prop:`--by3-${o}`,a:-t*.85,b:t*.45,period:d*1.45,delay:0,unit:"px"},{prop:`--bgh-${o}`,a:1-i,b:1+i,period:f,delay:0,unit:""},{prop:`--bop-tl-${o}`,a:1-s,b:1,period:d,delay:0,unit:""},{prop:`--bop-tr-${o}`,a:1-s,b:1,period:d*1.32,delay:d*.28,unit:""},{prop:`--bop-bl-${o}`,a:1-s,b:1,period:d*.84,delay:d*.55,unit:""},{prop:`--bop-br-${o}`,a:1-s,b:1,period:d*1.58,delay:d*.83,unit:""}]}function Ka(o,e,a,t,s,i){if(o!=="pulse-inner"&&o!=="pulse-outside")return null;const d=Me(o,e,a);return{oscillators:Ja(i,d),hue:s?null:{prop:`--beam-hue-${i}`,range:360,period:d.huePeriod,continuous:!0}}}function ke(o,e,a){return`  animation: ${e}-${o} ${a}s ease forwards;`}function Qa(o){const{size:e}=o;return e==="line"?tr(o):e==="sm"?Za(o):e==="pulse-inner"?ar(o):e==="pulse-outside"?rr(o):er(o)}function Za(o){const{id:e,borderRadius:a,borderWidth:t,duration:s,strokeOpacity:i,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:n,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-t),k=m==="mono"?.5:1,W=i*k,g=d*k,v=c*k,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,y=w==="dark",N=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,H=Ma(m),Y=Oa(m),S=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,X=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${H};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${W.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${Y};
  box-shadow: inset 0 0 5px 1px ${f};
  -webkit-mask-image: ${X};
  -webkit-mask-composite: source-over;
  mask-image: ${X};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  filter: blur(8px) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${z}
${pe(e)}
`}function er(o){const{id:e,borderRadius:a,borderWidth:t,duration:s,strokeOpacity:i,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:n,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-t),k=m==="mono"?.5:1,W=i*k,g=d*k,v=c*k,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,y=w==="dark",N=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,H=Fa(m),Y=Ra(m),S=y?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${N},${H};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${W.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${Y};
  box-shadow: inset 0 0 9px 1px ${f};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  filter: blur(8px) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${z}
${pe(e)}
`}function ar(o){const{id:e,borderRadius:a,borderWidth:t,duration:s,strokeOpacity:i,innerOpacity:d,bloomOpacity:c,colorVariant:f,staticColors:m,brightness:u,saturation:n,hueRange:x,theme:l}=o,w=l==="dark",j=f==="mono"?.5:1,k=(i*j).toFixed(2),W=(d*j).toFixed(2),g=(c*j).toFixed(2),{op:v}=Me("pulse-inner",l,s),h=8,z=u.toFixed(2),y=n.toFixed(2),N=m?`filter: brightness(${z}) saturate(${y});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${z}) saturate(${y});`,H=m?`filter: blur(${h}px) brightness(${z}) saturate(${y});`:`filter: blur(${h}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${z}) saturate(${y});`,Y=Ga(f,e),S=Ba(f,e,w),X=Pe(Da,f,1-v*.5);return`
${Te(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ke(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ke(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${Y};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${W} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${X};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${t}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${H}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${pe(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function rr(o){const{id:e,borderRadius:a,duration:t,strokeOpacity:s,innerOpacity:i,bloomOpacity:d,colorVariant:c,staticColors:f,brightness:m,saturation:u,hueRange:n,theme:x,hairlineOpacity:l=0}=o,w=x==="dark",j=c==="mono"?.5:1,k=(s*j).toFixed(2),W=(i*j).toFixed(2),g=(d*j).toFixed(2),v=w?"70, 70, 70":"0, 0, 0",h=l.toFixed(2),z=`linear-gradient(rgba(${v}, ${h}), rgba(${v}, ${h}))`,{op:y}=Me("pulse-outside",x,t),N=.95,H=.9,Y=w?3:6,S=w?22.5:15,X=m.toFixed(2),q=u.toFixed(2),T=f?`filter: brightness(${X}) saturate(${q});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${X}) saturate(${q});`,L=`brightness(var(--beam-glow-brightness, ${X})) saturate(var(--beam-glow-saturate, ${q}))`,B=f?`filter: blur(var(--beam-core-blur, ${Y}px)) ${L};`:`filter: blur(var(--beam-core-blur, ${Y}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${L};`,E=f?`filter: blur(var(--beam-bloom-blur, ${S}px)) ${L};`:`filter: blur(var(--beam-bloom-blur, ${S}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${L};`,_=Fe(Oe,c,e),M=Fe(Oe,c,e),U=Pe(Va,c,1-y*.5),P=l>0?`${_},
    ${z}`:_;return`
${Te(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ke(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ke(e,"beam-fade-out",.5)}
}
${l>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${z};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${P};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${T}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${M};
  transform: scale(${N}, ${H});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${W} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${B}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${U};
  transform: scale(${N}, ${H});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${g} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${E}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${pe(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function tr(o){const{id:e,borderRadius:a,borderWidth:t,duration:s,strokeOpacity:i,innerOpacity:d,bloomOpacity:c,innerShadow:f,colorVariant:m,staticColors:u,brightness:n,saturation:x,hueRange:l,theme:w}=o,j=Math.max(0,a-t),k=w==="dark",W=i,g=d,v=c,h=u?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,z=u?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,y=u?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l+10}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  50% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${l+10}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
  100% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${l+10}deg)) brightness(${n.toFixed(2)}) saturate(${x.toFixed(2)}); }
}`,N=k?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,H=qa(m,k,e),Y=La(m,e),S=Ta(m,k,e),X=m==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  padding: ${t}px;
  clip-path: inset(0 round ${a}px);
  background: ${N}, ${H};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${W.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${h}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${Y};
  box-shadow: inset 0 0 9px 1px ${f};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${g.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${h}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${j}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${S};
  ${X}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${v.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${z}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${y}
${pe(e)}
`}const je=new Set;let se=null,Xe=0;const or=1e3/30-2,sr=Math.PI*2;function Re(o){return(1-Math.cos(sr*o))/2}function Ue(o){if(se=requestAnimationFrame(Ue),o-Xe<or)return;Xe=o;const e=o/1e3;je.forEach(({el:a,config:t})=>{for(const s of t.oscillators){const i=(e-s.delay)/s.period,d=s.a+(s.b-s.a)*Re(i);a.style.setProperty(s.prop,s.unit==="px"?`${d.toFixed(2)}px`:d.toFixed(4))}if(t.hue){const{prop:s,range:i,period:d,continuous:c}=t.hue,f=c?e/d%1*i:-i+2*i*Re(e/d);a.style.setProperty(s,`${f.toFixed(2)}deg`)}})}function ir(){se==null&&(Xe=0,se=requestAnimationFrame(Ue))}function nr(){je.size===0&&se!=null&&(cancelAnimationFrame(se),se=null)}function lr(o,e){const a={el:o,config:e};return je.add(a),ir(),()=>{je.delete(a),nr()}}function cr(){const[o,e]=b.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return b.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),t=s=>{e(s.matches?"dark":"light")};return a.addEventListener("change",t),()=>a.removeEventListener("change",t)},[]),o}function dr(o,e){return o==="auto"?e:o}const Se=b.forwardRef(function({children:o,size:e="md",colorVariant:a="colorful",theme:t="dark",staticColors:s=!1,duration:i,active:d=!0,borderRadius:c,brightness:f,saturation:m,hueRange:u=30,strength:n=1,className:x,style:l,onActivate:w,onDeactivate:j,onAnimationEnd:k,...W},g){const v=b.useId().replace(/:/g,"-"),h=cr(),z=b.useRef(null),[y,N]=b.useState(d),[H,Y]=b.useState(!1),[S,X]=b.useState(!0),[q,T]=b.useState(null),[L,B]=b.useState({x:1,y:1});b.useEffect(()=>{if(c!=null)return;const C=z.current;if(!C)return;const R=()=>{const I=C.firstElementChild;if(!I)return;const le=getComputedStyle(I),G=parseFloat(le.borderTopLeftRadius);!isNaN(G)&&G>0&&T(G)};R();const V=new MutationObserver(R);return V.observe(C,{childList:!0,subtree:!1}),()=>V.disconnect()},[c,o]),b.useEffect(()=>{d&&!y&&!H?N(!0):!d&&y&&!H&&Y(!0)},[d,y,H]),b.useEffect(()=>{const C=z.current;if(!C||typeof IntersectionObserver>"u")return;const R=new IntersectionObserver(V=>{for(const I of V)X(I.isIntersecting)},{rootMargin:"256px"});return R.observe(C),()=>R.disconnect()},[]),b.useEffect(()=>{if(e!=="pulse-outside"){B({x:1,y:1});return}const C=z.current;if(!C)return;const R=350,V=140,I=.35,le=4,G=K=>Math.max(I,Math.min(le,K)),ue=()=>{const K=C.firstElementChild;if(!K)return;const te=K.getBoundingClientRect();if(!te.width||!te.height)return;const fe=+G(te.width/R).toFixed(3),xe=+G(te.height/V).toFixed(3);B(oe=>oe.x===fe&&oe.y===xe?oe:{x:fe,y:xe})};if(ue(),typeof ResizeObserver>"u")return;const ge=C.firstElementChild;if(!ge)return;const me=new ResizeObserver(ue);return me.observe(ge),()=>me.disconnect()},[e,o]);const E=b.useCallback(C=>{const R=C.animationName;R.includes("fade-out")?(N(!1),Y(!1),j?.()):R.includes("fade-in")&&w?.(),k?.(C)},[w,j,k]),_=dr(t,h),M=Ya[e][_],U=Sa[e],P=e==="pulse-inner"||e==="pulse-outside",ae=c??q??U.borderRadius,A=i??(e==="line"?3.1:P?2.3:1.96),re=m??M.saturation,F=f??M.brightness??1.3,J=e==="line"?Math.min(u,13):u,D=a==="mono"?!0:s,be=b.useMemo(()=>Qa({id:v,borderRadius:ae,borderWidth:U.borderWidth,duration:A,strokeOpacity:M.strokeOpacity,innerOpacity:M.innerOpacity,bloomOpacity:M.bloomOpacity,innerShadow:M.innerShadow,size:e,colorVariant:a,staticColors:D,brightness:F,saturation:re,hueRange:J,theme:_,hairlineOpacity:M.hairlineOpacity}),[v,ae,U.borderWidth,A,M.strokeOpacity,M.innerOpacity,M.bloomOpacity,M.innerShadow,M.hairlineOpacity,e,a,D,F,re,J,_]),ie=b.useMemo(()=>P?Ka(e,_,A,J,D,v):null,[P,e,_,A,J,D,v]);b.useEffect(()=>{var C;if(!ie||!(y||H)||!S)return;const R=z.current;if(R&&!(typeof window<"u"&&(C=window.matchMedia)!=null&&C.call(window,"(prefers-reduced-motion: reduce)").matches))return lr(R,ie)},[ie,y,H,S]);const Ne=b.useCallback(C=>{z.current=C,typeof g=="function"?g(C):g&&(g.current=C)},[g]),ne={...l??{},"--beam-strength":Math.max(0,Math.min(1,n)),...e==="pulse-outside"?{"--pulse-glow-sx":L.x,"--pulse-glow-sy":L.y}:{}};return r.jsxs(r.Fragment,{children:[r.jsx("style",{children:be}),r.jsxs("div",{...W,ref:Ne,"data-beam":v,"data-active":y&&!H?"":void 0,"data-fading":H?"":void 0,"data-paused":y&&!H&&!S?"":void 0,className:x,style:ne,onAnimationEnd:E,children:[o,r.jsx("div",{"data-beam-bloom":!0})]})]})});function pr({className:o,...e}){return r.jsxs("svg",{viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",className:o,...e,children:[r.jsx("path",{d:"M7 4H4.75A1.75 1.75 0 0 0 3 5.75v8.5A1.75 1.75 0 0 0 4.75 16H7"}),r.jsx("path",{d:"M8.5 6.5h5M8.5 10h7M8.5 13.5h3.5"}),r.jsx("path",{d:"m13.5 4 2-1m0 14 2-1"})]})}function br({closedTabs:o,onExpire:e}){return r.jsxs("div",{className:"closed-toast relative mt-2 overflow-hidden rounded-md border border-border bg-muted/20",children:[r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"max-h-36 space-y-1.5 overflow-y-auto p-2 pb-2.5",children:o.map((a,t)=>r.jsxs("li",{className:"flex min-w-0 items-center gap-2",children:[r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:a.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:a.url})]}),a.keptTabId!==void 0&&r.jsx("button",{type:"button",onClick:()=>chrome.runtime.sendMessage({type:"focusTab",tabId:a.keptTabId}),className:"shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"View existing"})]},`${a.url}-${t}`))}),r.jsx("div",{"data-testid":"closed-toast-timer",className:"closed-toast-timer absolute inset-x-0 bottom-0 h-0.5 origin-left bg-primary/60",onAnimationEnd:e})]})}function ur({windowId:o,disabled:e,acknowledged:a,onAcknowledge:t,onRunningChange:s,onMutation:i,onQuotaExhausted:d}){const[c,f]=b.useState(""),[m,u]=b.useState(!1),[n,x]=b.useState(!1),[l,w]=b.useState(null),j=Ve(Ie),k=b.useRef(!1),W=b.useRef(s);W.current=s,b.useEffect(()=>()=>{k.current&&W.current(!1)},[]);const g=async()=>{const h=c.trim();if(!(!h||k.current||e)){if(!a&&!n){x(!0),w(null);return}n&&(x(!1),await t()),k.current=!0,u(!0),s(!0),w(null);try{let z=await chrome.permissions.contains({origins:["<all_urls>"]});if(!z)try{z=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{z=!1}const y=await chrome.runtime.sendMessage({type:"command",query:h,windowId:o,hasContentPermission:z});if(y?.quota&&y.error){d?.(y.error),w(null);return}w(y??{error:"Something went wrong."}),["create_group","add_to_group","update_group","ungroup","remove_duplicates","merge_groups"].includes(y?.action||"")&&!y.error&&(f(""),await i?.().catch(()=>{}))}catch{w({error:"Command was interrupted. Try again."})}finally{k.current=!1,u(!1),s(!1)}}},v=async h=>{await chrome.runtime.sendMessage({type:"focusTab",tabId:h})};return r.jsxs("section",{className:"mt-4","aria-label":"Command bar",children:[r.jsx(Se,{size:"line",colorVariant:"ocean",theme:"dark",strength:.35,active:m,className:"w-full focus-within:ring-2 focus-within:ring-ring/30","data-testid":"command-beam",children:r.jsxs("div",{className:"flex items-center gap-2 rounded-lg border border-border bg-muted/20 px-2.5 focus-within:border-ring",children:[r.jsx("input",{value:c,onChange:h=>f(h.target.value),onKeyDown:h=>{h.key==="Enter"&&g()},disabled:e||m,placeholder:j,"aria-label":"Command",className:"h-9 min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground disabled:opacity-50"}),m?r.jsx(de,{className:"size-3.5 shrink-0 animate-spin text-muted-foreground"}):r.jsx("button",{type:"button",onClick:g,disabled:e||!c.trim(),title:"Send","aria-label":"Send",className:"flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&:not(:disabled)]:text-primary",children:r.jsx(ha,{className:"size-3.5"})})]})}),n&&r.jsx("p",{className:"mt-2 text-xs leading-snug text-muted-foreground","aria-live":"polite",children:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Press Enter again to continue."}),l&&r.jsxs("div",{className:`mt-2 flex items-start gap-2 text-xs ${l.error?"text-destructive":"text-muted-foreground"}`,"aria-live":"polite",children:[r.jsx("p",{className:"min-w-0 flex-1 leading-snug",children:l.error?l.error:l.action==="open_tab"?`Jumped to “${l.tabTitle}”`:l.action==="create_group"?`Created “${l.groupName}” with ${l.tabCount} tab${l.tabCount===1?"":"s"}`:l.action==="add_to_group"?`Moved ${l.tabCount} tab${l.tabCount===1?"":"s"} into “${l.groupName}”`:l.action==="update_group"?l.previousName&&l.previousName!==l.groupName?`Renamed “${l.previousName}” to “${l.groupName}”`:`Updated “${l.groupName}”`:l.action==="ungroup"?`Ungrouped ${l.tabCount} tab${l.tabCount===1?"":"s"} from ${l.groupCount} group${l.groupCount===1?"":"s"}`:l.action==="remove_duplicates"?l.closedCount?`Closed ${l.closedCount} duplicate tab${l.closedCount===1?"":"s"}`:"No duplicate tabs found":l.action==="merge_groups"?`Merged ${l.groupCount} groups into “${l.groupName}” · ${l.tabCount} tabs`:l.reply}),l.action==="answer"&&typeof l.tabId=="number"&&r.jsxs("button",{onClick:()=>v(l.tabId),className:"flex shrink-0 items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px] text-foreground transition-colors hover:bg-muted",children:["Go to tab ",r.jsx(ta,{className:"size-3"})]})]}),l?.action==="remove_duplicates"&&l.closedTabs&&l.closedTabs.length>0&&r.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"mt-2 max-h-32 space-y-1.5 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 text-xs",children:l.closedTabs.map((h,z)=>r.jsxs("li",{className:"min-w-0",children:[r.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:h.title||"Untitled tab"}),r.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:h.url})]},`${h.url}-${z}`))})]})}const _e={collecting:{label:"Reading titles",progress:18},classifying:{label:"Finding themes",progress:48},reading:{label:"Reading ambiguous pages",progress:68},applying:{label:"Creating tab groups",progress:88}};function gr({job:o}){const e=_e[o?.stage||"collecting"]??_e.collecting,a=o?.tabCount||0;return r.jsxs("section",{className:"mt-6","aria-live":"polite","aria-label":`${e.label}. Organizing tabs.`,children:[r.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:a?`Organizing ${a} tabs`:"Organizing tabs"}),r.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.label}),r.jsxs("div",{className:"tab-rail mt-6","aria-hidden":"true",children:[r.jsx("div",{className:"tab-rail-line"}),[0,1,2,3].map(t=>r.jsx("span",{className:"tab-rail-item",style:{animationDelay:`${t*-.58}s`},children:r.jsx("span",{className:"tab-rail-notch"})},t)),r.jsx("span",{className:"tab-rail-arrow",children:"→"}),r.jsxs("span",{className:"tab-rail-groups",children:[r.jsx("span",{}),r.jsx("span",{})]})]}),r.jsxs("div",{className:"mt-5 flex items-center justify-between gap-3 text-xs",children:[r.jsx("span",{className:"text-muted-foreground",children:e.label}),r.jsxs("span",{className:"tabular-nums text-foreground",children:[e.progress,"%"]})]}),r.jsx("div",{className:"mt-2 h-0.5 overflow-hidden rounded-full bg-muted",children:r.jsx("div",{className:"organize-progress h-full origin-left bg-primary transition-transform duration-500 [transition-timing-function:var(--ease-out-strong)]",style:{transform:`scaleX(${e.progress/100})`}})}),r.jsxs("div",{className:"mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground",children:[r.jsx(za,{className:"size-4 text-primary"}),r.jsx("span",{children:"Safe to close — progress continues"})]})]})}function mr({onDismiss:o}){return r.jsx("section",{className:"mt-4 rounded-lg border border-primary/35 bg-primary/10 p-3","aria-live":"polite",children:r.jsxs("div",{className:"flex items-start gap-2.5",children:[r.jsx(ga,{className:"mt-0.5 size-4 shrink-0 text-primary"}),r.jsxs("div",{className:"min-w-0 flex-1",children:[r.jsx("p",{className:"text-sm font-medium leading-snug",children:"Pin Shelve to your toolbar"}),r.jsxs("p",{className:"mt-1 text-xs leading-snug text-muted-foreground",children:["Click the ",r.jsx(fa,{className:"inline size-3.5 align-[-2px]","aria-label":"puzzle-piece"})," icon next to the address bar, then hit the pin beside Shelve so it’s always one click away."]}),r.jsx("div",{className:"mt-2",children:r.jsx(He,{onClick:o,variant:"ghost",size:"sm",children:"Got it"})})]})]})})}function ze({label:o,title:e,icon:a,onClick:t,disabled:s}){return r.jsxs("button",{title:e??o,"aria-label":e??o,onClick:t,disabled:s,className:"flex h-11 flex-col items-center justify-center gap-0.5 rounded-lg border border-border bg-transparent text-[10px] text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:bg-muted hover:text-foreground active:scale-[0.97] focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:[a,r.jsx("span",{className:"px-1 text-center leading-tight",children:o})]})}function fr({groups:o,selected:e,applying:a,onSelectedChange:t,onApply:s,onDiscard:i}){return r.jsxs("section",{className:"mt-5",children:[r.jsxs("div",{className:"mb-3",children:[r.jsx("h1",{className:"text-base font-semibold tracking-tight",children:"Review groups"}),r.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"Choose which suggestions to create."})]}),r.jsx("div",{className:"flex max-h-72 flex-col gap-1 overflow-y-auto",children:o.map((d,c)=>r.jsxs("label",{className:"review-item flex cursor-pointer items-start gap-2.5 rounded-md p-2 hover:bg-accent",style:{animationDelay:`${c*40}ms`},children:[r.jsx(Ge,{className:"mt-0.5",checked:e.has(c),disabled:a,onCheckedChange:f=>{const m=new Set(e);f?m.add(c):m.delete(c),t(m)}}),r.jsxs("span",{className:"min-w-0",children:[r.jsxs("span",{className:"block text-sm font-medium leading-tight",children:[d.name,r.jsx("span",{className:"ml-1.5 font-normal text-muted-foreground",children:d.tabIds.length})]}),r.jsx("span",{className:"block truncate text-xs text-muted-foreground",children:d.tabTitles.join(" · ")})]})]},`${d.existingGroupId??"new"}-${c}`))}),r.jsxs("div",{className:"mt-3 flex gap-2",children:[r.jsx(He,{onClick:i,disabled:a,variant:"outline",className:"flex-1",size:"sm",children:"Discard"}),r.jsxs(He,{onClick:s,disabled:!e.size||a,className:"flex-1",size:"sm",children:[a?r.jsx(de,{className:"size-4 animate-spin"}):null,a?"Applying…":"Apply selected"]})]})]})}const we={grey:"bg-zinc-400",blue:"bg-blue-500",red:"bg-red-500",yellow:"bg-yellow-400",green:"bg-green-500",pink:"bg-pink-500",purple:"bg-purple-500",cyan:"bg-cyan-500",orange:"bg-orange-500"};function Ae(o){const e=o.loadedCount??o.tabCount;return e>=7?{label:"high",className:"text-orange-400"}:e>=3?{label:"med",className:"text-yellow-500"}:{label:"low",className:"text-muted-foreground"}}function xr(o){const e=Math.max(0,Math.round((Date.now()-o)/6e4));if(e<1)return"just now";if(e<60)return`${e}m ago`;const a=Math.round(e/60);return a<24?`${a}h ago`:`${Math.round(a/24)}d ago`}function hr({groups:o,stashes:e,busyId:a,disabled:t,onStash:s,onResume:i,onDelete:d}){const[c,f]=b.useState(!1),[m,u]=b.useState(null);return!o.length&&!e.length?null:r.jsxs(r.Fragment,{children:[e.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Shelved projects",children:[r.jsx("h2",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:"Shelved"}),r.jsx("div",{className:"mt-1.5 flex flex-col gap-1",children:e.map(n=>{const x=n.resumeStatus==="resuming",l=t||x;return r.jsxs("div",{className:"rounded-md border border-border/70 px-2 py-1.5",children:[r.jsxs("div",{className:"flex items-center gap-2",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${we[n.color]??we.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs font-medium",children:n.name}),m===n.id?r.jsxs(r.Fragment,{children:[r.jsx("span",{className:"text-[11px] text-destructive",children:"Delete this shelved project?"}),r.jsx("button",{type:"button",onClick:()=>u(null),className:"rounded px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Cancel"}),r.jsx("button",{type:"button",disabled:l,onClick:async()=>{await d(n.id),u(null)},className:"rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] font-medium text-destructive outline-none transition-colors hover:bg-destructive/20 focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:"Delete"})]}):r.jsxs(r.Fragment,{children:[r.jsxs("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:[n.tabCount," · ",xr(n.createdAt)]}),r.jsx(Ce,{title:"Resume",disabled:l,onClick:()=>i(n.id),children:a===n.id||x?r.jsx(de,{className:"size-3.5 animate-spin"}):r.jsx(Ze,{className:"size-3.5"})}),r.jsx(Ce,{title:"Delete shelved project",disabled:l,onClick:()=>u(n.id),children:r.jsx(Wa,{className:"size-3.5"})})]})]}),x?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Resuming…"}):n.briefStatus==="pending"?r.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Writing where-you-left-off brief…"}):n.brief?r.jsx("p",{title:n.brief,className:"mt-1 line-clamp-2 pl-4 text-[11px] leading-snug text-muted-foreground",children:n.brief}):null]},n.id)})})]}),o.length>0&&r.jsxs("section",{className:"mt-4","aria-label":"Tab groups in this window",children:[r.jsxs("button",{type:"button",onClick:()=>f(n=>!n),"aria-expanded":c,"aria-controls":"groups-list",className:"flex h-7 w-full items-center justify-between rounded-md px-1.5 outline-none transition-colors hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:["Groups · ",o.length]}),r.jsx(Be,{className:`size-3.5 text-muted-foreground transition-transform duration-200 [transition-timing-function:var(--ease-out-strong)] ${c?"rotate-180":""}`})]}),c&&r.jsx("div",{id:"groups-list",className:"mt-1 flex flex-col",children:o.map(n=>r.jsxs("div",{className:"flex h-8 items-center gap-2 rounded-md px-1.5 hover:bg-muted/50",children:[r.jsx("span",{className:`size-2 shrink-0 rounded-full ${we[n.color]??we.grey}`}),r.jsx("span",{className:"min-w-0 flex-1 truncate text-xs",children:n.title}),r.jsx("span",{title:`Approximate memory use: ${n.loadedCount??n.tabCount} of ${n.tabCount} tabs loaded`,className:`text-[10px] font-medium uppercase tracking-wide ${Ae(n).className}`,children:Ae(n).label}),r.jsx("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:n.tabCount}),r.jsx(Ce,{title:`Shelve “${n.title}”`,disabled:t,onClick:()=>s(n.id),children:a===n.id?r.jsx(de,{className:"size-3.5 animate-spin"}):r.jsx(aa,{className:"size-3.5"})})]},n.id))})]})]})}function Ce({title:o,disabled:e,onClick:a,children:t}){return r.jsx("button",{title:o,"aria-label":o,disabled:e,onClick:a,className:"flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:t})}const $r=[100,250,500,1e3,2500,5e3,1e4,25e3];function yr({refreshToken:o}){const[e,a]=b.useState(null);b.useEffect(()=>{let d=!1;return chrome.runtime.sendMessage({type:"getStats"}).then(c=>{!d&&c&&!c.error&&c.totals&&a(c)}).catch(()=>{}),()=>{d=!0}},[o]);const t=e?.totals?.tabsGrouped??0;if(!e||t<1)return null;const s=$r.find(d=>d>t),i=[e.weekTabs>0?`${e.weekTabs.toLocaleString()} this week`:null,s?`${(s-t).toLocaleString()} to ${s.toLocaleString()}`:null].filter(Boolean).join(" · ");return r.jsxs("section",{"aria-label":"Your stats",className:"mt-2 rounded-md border border-border bg-muted/20 px-3 py-2",children:[r.jsxs("div",{className:"flex items-baseline justify-between gap-2 tabular-nums",children:[r.jsx(We,{value:t,label:"tabs sorted"}),(e.totals.stashes??0)>0&&r.jsx(We,{value:e.totals.stashes??0,label:"projects shelved"}),e.streak>1&&r.jsx(We,{value:e.streak,label:"day streak"})]}),i&&r.jsx("p",{className:"mt-1 text-[11px] leading-snug text-muted-foreground",children:i})]})}function We({value:o,label:e}){return r.jsxs("div",{className:"min-w-0",children:[r.jsx("span",{className:"text-sm font-semibold text-foreground",children:o.toLocaleString()}),r.jsx("span",{className:"ml-1 text-[11px] text-muted-foreground",children:e})]})}function vr({dailyLimit:o,onDismiss:e}){const[a,t]=b.useState(null);return b.useEffect(()=>{let s=!1;return chrome.runtime.sendMessage({type:"getUpgradeInfo"}).then(i=>{s||t({paymentsEnabled:i?.paymentsEnabled===!0,checkoutUrl:i?.checkoutUrl||""})}).catch(()=>{s||t({paymentsEnabled:!1,checkoutUrl:""})}),()=>{s=!0}},[]),r.jsxs("section",{className:"mt-4 flex flex-col gap-3","aria-labelledby":"upgrade-heading",children:[r.jsxs("div",{children:[r.jsxs("h2",{id:"upgrade-heading",className:"text-sm font-semibold tracking-tight",children:["You're out of free actions",o?" for today":""]}),r.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:o?"They reset tomorrow — or keep going right now:":"Keep going with one of these:"})]}),r.jsxs("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex w-full flex-col items-start gap-1 rounded-lg border border-primary/50 bg-muted/40 p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary hover:bg-muted active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[r.jsx(ca,{className:"size-4 text-primary"}),"Add your own API key — free"]}),r.jsx("span",{className:"text-xs text-muted-foreground",children:"Unlimited actions with your OpenAI, Anthropic, Gemini, or Ollama key. Shelve itself stays free."})]}),a?.paymentsEnabled&&a.checkoutUrl&&r.jsxs("a",{href:a.checkoutUrl,target:"_blank",rel:"noreferrer",className:"flex w-full flex-col items-start gap-1 rounded-lg border border-border p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted/50 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[r.jsx(Xa,{className:"size-4"}),"Shelve Hosted — $5/mo"]}),r.jsx("span",{className:"text-xs text-muted-foreground",children:"No key to manage; more actions on the hosted model."})]}),r.jsx("button",{onClick:e,className:"self-center rounded-md px-2 py-1 text-xs text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Not now"})]})}function zr({windowId:o,running:e,setRunning:a,setStatus:t,setGroups:s,setSelected:i,setReviewMinSize:d,setOrganizeClosedTabs:c,refreshUndo:f,refreshPanels:m,onQuotaExhausted:u}){const[n,x]=b.useState(null),l=b.useRef(!1),w=b.useRef(null),j=b.useCallback(async g=>{!o||!g||(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:o,jobId:g}),x(null))},[o]),k=b.useCallback(async(g,v)=>{if(v&&w.current===v)return;v&&(w.current=v),a(null),await f();const h=Array.isArray(g?.closedTabs)?g.closedTabs:[];if(!g||g.error){c([]),t({text:g?.error??"Something went wrong.",error:!0,closedTabs:h}),g?.quota&&u?.(g.error??""),await j(v);return}if(g.review&&g.groups){c(h),s(g.groups),i(new Set(g.groups.map((z,y)=>y))),d(g.minSize||1),t(null);return}c([]),t({text:`${g.groupCount} group${g.groupCount===1?"":"s"} · ${g.tabCount} tabs sorted`,closedTabs:h}),await j(v),await m()},[j,f,m,u,s,c,d,a,i,t]),W=e==="organize"||n?.status==="running";return b.useEffect(()=>{if(!o)return;let g=!1,v;const h=async()=>{let z=!1;try{const y=await chrome.runtime.sendMessage({type:"organizeStatus",windowId:o});if(g)return;const N=y?.job;N?.status==="running"?(x(N),a("organize"),t(null),z=!0):N&&!l.current&&w.current!==N.id&&(x(N),await k(N.result||{error:N.error},N.id))}catch{}!g&&z&&(v=window.setTimeout(h,450))};return h(),()=>{g=!0,v&&window.clearTimeout(v)}},[k,o,W,a,t]),{organizeJob:n,setOrganizeJob:x,consumeJob:j,handleOrganizeResult:k,ownsOrganizeRequest:l,handledJobId:w,organizeActive:W}}const wr=typeof window<"u"&&new URLSearchParams(window.location.search).has("overlay"),qe=typeof window<"u"&&window.self!==window.top;function kr(){const[o,e]=b.useState(null),[a,t]=b.useState(null),[s,i]=b.useState([]),[d,c]=b.useState(new Set),[f,m]=b.useState(1),[u,n]=b.useState(),[x,l]=b.useState(1),[w,j]=b.useState(!1),[k,W]=b.useState(!1),[g,v]=b.useState(null),[h,z]=b.useState(!1),[y,N]=b.useState(!1),[H,Y]=b.useState([]),[S,X]=b.useState([]),[q,T]=b.useState(null),[L,B]=b.useState(null),[E,_]=b.useState([]),[M,U]=b.useState(qe?null:!0),[P,ae]=b.useState(null);b.useEffect(()=>{if(!qe)return;let p=!1;return chrome.runtime.sendMessage({type:"overlayHandshake"}).then($=>{p||U($?.allowed===!0)}).catch(()=>{p||U(!1)}),()=>{p=!0}},[]);const A=b.useCallback(async(p=u)=>{if(!p)return;const $=await chrome.runtime.sendMessage({type:"hasUndo",windowId:p});j(!!$?.hasUndo)},[u]),re=b.useCallback(async()=>{const p=await chrome.runtime.sendMessage({type:"windowCount"});p?.count&&l(p.count)},[]);b.useEffect(()=>{const p=()=>{re().catch(()=>{})};return chrome.windows.onCreated?.addListener(p),chrome.windows.onRemoved.addListener(p),()=>{chrome.windows.onCreated?.removeListener(p),chrome.windows.onRemoved.removeListener(p)}},[re]);const F=b.useCallback(async()=>{if(!u)return;const[p,$]=await Promise.all([chrome.runtime.sendMessage({type:"listGroups",windowId:u}),chrome.runtime.sendMessage({type:"listStashes",windowId:u})]);p?.groups&&Y(p.groups),$?.stashes&&X($.stashes)},[u]);b.useEffect(()=>{F();const p=($,ce)=>{ce==="local"&&$.stashes&&F()};return chrome.storage.onChanged.addListener(p),()=>chrome.storage.onChanged.removeListener(p)},[F]);const J=b.useCallback(p=>{ae({dailyLimit:/reset tomorrow/i.test(p)}),t($=>$?.closedTabs?.length?{text:"",closedTabs:$.closedTabs}:null)},[]),{organizeJob:D,setOrganizeJob:be,consumeJob:ie,handleOrganizeResult:Ne,ownsOrganizeRequest:ne,handledJobId:C,organizeActive:R}=zr({windowId:u,running:o,setRunning:e,setStatus:t,setGroups:i,setSelected:c,setReviewMinSize:m,setOrganizeClosedTabs:_,refreshUndo:A,refreshPanels:F,onQuotaExhausted:J});b.useEffect(()=>{(async()=>{const p=await chrome.windows.getCurrent(),[$,ce,ye]=await Promise.all([chrome.runtime.sendMessage({type:"hasUndo",windowId:p.id}),chrome.runtime.sendMessage({type:"windowCount"}),chrome.storage.local.get({dataNoticeAck:!1,pinPromptDismissed:!1})]);try{const De=await chrome.action.getUserSettings();W(!De.isOnToolbar&&!ye.pinPromptDismissed)}catch{}n(p.id),ce?.count&&l(ce.count),j(!!$?.hasUndo),v(!!ye.dataNoticeAck)})()},[]);const V=async()=>{if(!g&&!h){z(!0),t({text:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider."});return}h&&(z(!1),v(!0),await chrome.storage.local.set({dataNoticeAck:!0})),e("organize"),t(null),ae(null),_([]),C.current=null,ne.current=!0;let p=await chrome.permissions.contains({origins:["<all_urls>"]});if(!p)try{p=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{p=!1}try{const $=await chrome.runtime.sendMessage({type:"organize",hasContentPermission:p,windowId:u});if(ne.current=!1,$?.running&&$.job){be($.job);return}await Ne($,$?.jobId)}catch{ne.current=!1,e(null),t({text:"Organizing was interrupted. Try again.",error:!0})}},I=async()=>{const p=D?.id??C.current??void 0;try{if(u&&p&&!(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:u,jobId:p}))?.cleared){t({text:"Couldn't discard the suggestions — try again.",error:!0});return}i([]),c(new Set),be(null),t({text:E.length?`Suggestions discarded · ${E.length} duplicate tab${E.length===1?"":"s"} closed`:"Suggestions discarded.",closedTabs:E}),_([])}catch{t({text:"Couldn't discard the suggestions — try again.",error:!0})}},le=async()=>{const p=s.filter((ce,ye)=>d.has(ye));if(!p.length)return;e("apply");const $=await chrome.runtime.sendMessage({type:"applyPlan",groups:p,minSize:f,windowId:u});e(null),i([]),await Promise.all([A(),F()]),await ie(D?.id??C.current??void 0),t($?.error?{text:$.error,error:!0,closedTabs:E}:{text:`${$.groupCount} group${$.groupCount===1?"":"s"} created`,closedTabs:E}),_([])},G=async()=>{e("ungroup"),t(null);const p=await chrome.runtime.sendMessage({type:"ungroupAll",windowId:u});e(null),await Promise.all([A(),F()]),t(p?.error?{text:p.error,error:!0}:{text:`${p.tabCount} tab${p.tabCount===1?"":"s"} ungrouped`})},ue=async()=>{e("duplicates"),t(null);const p=await chrome.runtime.sendMessage({type:"cleanDuplicates",windowId:u});e(null),await Promise.all([A(),F()]),t(p?.error?{text:p.error,error:!0}:{text:p.closedCount?`Closed ${p.closedCount} duplicate tab${p.closedCount===1?"":"s"}`:"No duplicate tabs found",closedTabs:Array.isArray(p.closedTabs)?p.closedTabs:[]})},ge=async()=>{e("merge"),t(null);const p=await chrome.runtime.sendMessage({type:"mergeWindows",windowId:u});if(e(null),p?.error){t({text:p.error,error:!0});return}await Promise.all([re(),F()]),t({text:`Merged ${p.windows} window${p.windows===1?"":"s"} · ${p.tabs} tabs`})},me=async()=>{e("undo"),t(null);const p=await chrome.runtime.sendMessage({type:"undo",windowId:u});if(e(null),await Promise.all([A(),F()]),p?.error){t({text:p.error,error:!0});return}t({text:p?.skippedCount?`Restored the available layout — ${p.skippedCount} tab${p.skippedCount===1?"":"s"} closed since couldn't be brought back`:"Previous tab layout restored"})},K=b.useCallback(async()=>{v(!0),await chrome.storage.local.set({dataNoticeAck:!0})},[]),te=async p=>{if(!g){if(L!==p){B(p),t({text:"Stash briefs send tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Click again to continue."});return}B(null),await K()}T(p),t(null);let $;try{$=await chrome.runtime.sendMessage({type:"stashGroup",windowId:u,groupId:p})}finally{T(null)}await F(),t($?.error?{text:$.error,error:!0}:{text:`Stashed “${$.stash?.name}” · ${$.stash?.tabCount} tabs`})},fe=async p=>{T(p),t(null);let $;try{$=await chrome.runtime.sendMessage({type:"resumeStash",stashId:p,windowId:u})}finally{T(null)}await F(),t($?.error?{text:$.error,error:!0}:{text:`Restored ${$.tabCount} tab${$.tabCount===1?"":"s"}`})},xe=async p=>{const $=await chrome.runtime.sendMessage({type:"deleteStash",stashId:p});await F(),t($?.error?{text:$.error,error:!0}:{text:"Stash deleted"})},oe=s.length>0,he=R,Q=!!o||oe||q!==null||y||g===null||u===void 0,$e=(p,$)=>o===p?r.jsx(de,{className:"size-4 animate-spin"}):$;return M===null?null:M===!1?r.jsx("main",{className:"popup-shell w-[340px] p-4",children:r.jsx("p",{className:"text-xs text-muted-foreground",children:"Open Shelve from the toolbar icon to use it here."})}):r.jsx(Se,{size:"md",colorVariant:"ocean",theme:"dark",strength:.45,borderRadius:wr?16:0,active:he||y,className:"popup-frame","data-testid":"window-beam",children:r.jsxs("main",{className:"popup-shell w-[340px] p-4",children:[r.jsxs("header",{className:"flex items-center justify-between",children:[r.jsxs("div",{className:"flex items-center gap-2.5",children:[r.jsx("span",{className:"flex size-8 items-center justify-center rounded-md border border-border bg-muted/50 text-foreground",children:r.jsx("img",{src:"icons/icon48.png",alt:"",className:"size-5 rounded-[5px]"})}),r.jsx("span",{className:"text-sm font-semibold tracking-tight",children:"Shelve"})]}),r.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex size-8 items-center justify-center rounded-md border border-transparent text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted hover:text-foreground active:scale-[0.96] focus-visible:ring-2 focus-visible:ring-ring",title:"Settings","aria-label":"Settings",children:r.jsx(ya,{className:"size-4"})})]}),P&&!he?r.jsx(vr,{dailyLimit:P.dailyLimit,onDismiss:()=>ae(null)}):he?r.jsx(gr,{job:D}):oe||o==="apply"?r.jsx(fr,{groups:s,selected:d,applying:o==="apply",onSelectedChange:c,onApply:le,onDiscard:I}):r.jsxs(r.Fragment,{children:[k&&r.jsx(mr,{onDismiss:()=>{W(!1),chrome.storage.local.set({pinPromptDismissed:!0})}}),r.jsx(ur,{windowId:u,disabled:Q&&!y,acknowledged:g===!0,onAcknowledge:K,onRunningChange:N,onMutation:async()=>{await Promise.all([A(),F()])},onQuotaExhausted:J}),r.jsx(Se,{size:"md",colorVariant:"ocean",theme:"dark",strength:.4,active:h,className:"mt-3 w-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring","data-testid":"organize-beam",children:r.jsxs("button",{onClick:V,disabled:Q,className:"flex h-20 w-full flex-col items-center justify-center gap-2 rounded-lg border border-border bg-transparent text-sm font-medium text-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40","aria-label":"Organize tabs",children:[r.jsx(ka,{className:"size-5 text-primary"}),r.jsx("span",{children:h?"Continue organizing":"Organize tabs"})]})}),r.jsxs("div",{className:"mt-3 grid grid-cols-4 gap-1.5",children:[r.jsx(ze,{label:"Ungroup",onClick:G,disabled:Q,icon:$e("ungroup",r.jsx(pr,{className:"size-[18px]"}))}),r.jsx(ze,{label:"Duplicates",title:"Close duplicates",onClick:ue,disabled:Q,icon:$e("duplicates",r.jsx(na,{className:"size-4"}))}),r.jsx(ze,{label:"Merge",title:"Merge windows",onClick:ge,disabled:Q||x<=1,icon:$e("merge",r.jsx(sa,{className:"size-4"}))}),r.jsx(ze,{label:"Undo",onClick:me,disabled:Q||!w,icon:$e("undo",r.jsx(Na,{className:"size-4"}))})]}),r.jsx(hr,{groups:H,stashes:S,busyId:q,disabled:Q,onStash:te,onResume:fe,onDelete:xe})]}),!he&&!P&&r.jsxs(r.Fragment,{children:[r.jsxs("div",{className:"mt-4 min-h-4 text-xs","aria-live":"polite",children:[r.jsx("p",{className:a?.error?"text-destructive":"text-muted-foreground",children:a?.text??""}),a?.closedTabs&&a.closedTabs.length>0&&r.jsx(br,{closedTabs:a.closedTabs,onExpire:()=>t(null)})]}),r.jsx(yr,{refreshToken:a}),r.jsxs("a",{href:"mailto:prithvi@skive.in?subject=Shelve%20feature%20request&body=Hi%20Prithvi%2C%0A%0AI%27d%20like%20to%20request%3A%0A%0A",className:"mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted/50 hover:text-foreground active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[r.jsx(ba,{className:"size-3.5"}),"Request a feature"]})]})]})})}if(new URLSearchParams(window.location.search).has("overlay")){document.documentElement.dataset.overlay="";const o=()=>window.parent.postMessage({__shelveOverlay:!0,height:document.body.scrollHeight},"*");new ResizeObserver(o).observe(document.body),window.addEventListener("keydown",e=>{e.key==="Escape"&&window.parent.postMessage({__shelveOverlay:!0,close:!0},"*")})}Je.createRoot(document.getElementById("root")).render(r.jsx(Ke.StrictMode,{children:r.jsx(kr,{})}));
