import{c as M,r as p,j as t,o as Be,v as Ge,B as He,p as Ie,C as Je,s as Ke,t as Qe}from"./rotatingPlaceholders-BSPNiPMN.js";const Ze=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h2",key:"tvwodi"}],["path",{d:"M20 8v11a2 2 0 0 1-2 2h-2",key:"1gkqxj"}],["path",{d:"m9 15 3-3 3 3",key:"1pd0qc"}],["path",{d:"M12 12v9",key:"192myk"}]],ea=M("archive-restore",Ze);const aa=[["rect",{width:"20",height:"5",x:"2",y:"3",rx:"1",key:"1wp1u1"}],["path",{d:"M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8",key:"1s80jp"}],["path",{d:"M10 12h4",key:"a56b0p"}]],ta=M("archive",aa);const ra=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],oa=M("arrow-right",ra);const sa=[["path",{d:"M10 18H5a3 3 0 0 1-3-3v-1",key:"ru65g8"}],["path",{d:"M14 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"e30een"}],["path",{d:"M20 2a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2",key:"2ahx8o"}],["path",{d:"m7 21 3-3-3-3",key:"127cv2"}],["rect",{x:"14",y:"14",width:"8",height:"8",rx:"2",key:"1b0bso"}],["rect",{x:"2",y:"2",width:"8",height:"8",rx:"2",key:"1x09vl"}]],ia=M("combine",sa);const na=[["line",{x1:"12",x2:"18",y1:"12",y2:"18",key:"1rg63v"}],["line",{x1:"12",x2:"18",y1:"18",y2:"12",key:"ebkxgr"}],["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]],la=M("copy-x",na);const ca=[["path",{d:"M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",key:"1s6t7t"}],["circle",{cx:"16.5",cy:"7.5",r:".5",fill:"currentColor",key:"w0ekpg"}]],da=M("key-round",ca);const pa=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],be=M("loader-circle",pa);const ba=[["path",{d:"M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8",key:"12jkf8"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}],["path",{d:"M19 16v6",key:"tddt3s"}],["path",{d:"M16 19h6",key:"xwg31i"}]],ua=M("mail-plus",ba);const ga=[["path",{d:"M12 17v5",key:"bb1du9"}],["path",{d:"M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",key:"1nkz8b"}]],ma=M("pin",ga);const fa=[["path",{d:"M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",key:"w46dr5"}]],xa=M("puzzle",fa);const ha=[["path",{d:"M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",key:"117uat"}],["path",{d:"M6 12h16",key:"s4cdu5"}]],$a=M("send-horizontal",ha);const ya=[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]],va=M("settings",ya);const za=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],wa=M("shield-check",za);const ka=[["path",{d:"M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",key:"4pj2yx"}],["path",{d:"M20 3v4",key:"1olli1"}],["path",{d:"M22 5h-4",key:"1gvqau"}],["path",{d:"M4 17v2",key:"vumght"}],["path",{d:"M5 18H3",key:"zchphs"}]],ja=M("sparkles",ka);const Na=[["path",{d:"M9 14 4 9l5-5",key:"102s5s"}],["path",{d:"M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",key:"f3b9sd"}]],Ca=M("undo-2",Na);const Ha=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Wa=M("x",Ha);const Xa=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],Ya=M("zap",Xa),Sa={sm:{borderRadius:32,borderWidth:1,width:70,height:36},md:{borderRadius:16,borderWidth:1},line:{borderRadius:16,borderWidth:1},"pulse-outside":{borderRadius:16,borderWidth:1},"pulse-inner":{borderRadius:16,borderWidth:1}},Ma={sm:{dark:{strokeOpacity:.46,innerOpacity:.24,bloomOpacity:.38,innerShadow:"rgba(255, 255, 255, 0.3)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.3,bloomOpacity:.16,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.8}},md:{dark:{strokeOpacity:.26,innerOpacity:.42,bloomOpacity:.24,innerShadow:"rgba(255, 255, 255, 0.27)",saturation:1.2},light:{strokeOpacity:.12,innerOpacity:.26,bloomOpacity:.34,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.5}},line:{dark:{strokeOpacity:1.14,innerOpacity:.7,bloomOpacity:.8,innerShadow:"rgba(255, 255, 255, 0.1)",saturation:1.2},light:{strokeOpacity:.16,innerOpacity:.32,bloomOpacity:.3,innerShadow:"rgba(0, 0, 0, 0.14)",saturation:1.95}},"pulse-outside":{dark:{strokeOpacity:.94,innerOpacity:.34,bloomOpacity:.3,innerShadow:"transparent",saturation:1.2,brightness:1.9,hairlineOpacity:0},light:{strokeOpacity:1.96,innerOpacity:1.04,bloomOpacity:.42,innerShadow:"transparent",saturation:.6,brightness:1.7,hairlineOpacity:0}},"pulse-inner":{dark:{strokeOpacity:1.54,innerOpacity:.44,bloomOpacity:.66,innerShadow:"transparent",saturation:1.2,brightness:.75},light:{strokeOpacity:.32,innerOpacity:.4,bloomOpacity:.8,innerShadow:"transparent",saturation:.75,brightness:1.3}}},ae={colorful:{border:[{color:"rgb(255, 50, 100)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(40, 140, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(50, 200, 80)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(30, 185, 170)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(100, 70, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(40, 140, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 120, 40)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(240, 50, 180)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(180, 40, 240)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 60, 80)",secondary:"rgba(40, 190, 180, 0.98)"},spikeLt:{primary:"rgb(200, 30, 60)",secondary:"rgb(20, 150, 140)"}},mono:{border:[{color:"rgb(180, 180, 180)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(140, 140, 140)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(160, 160, 160)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(130, 130, 130)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(170, 170, 170)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(150, 150, 150)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(190, 190, 190)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(145, 145, 145)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(165, 165, 165)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(200, 200, 200)",secondary:"rgb(170, 170, 170)"},spikeLt:{primary:"rgb(80, 80, 80)",secondary:"rgb(120, 120, 120)"}},ocean:{border:[{color:"rgb(100, 80, 220)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(60, 120, 255)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(80, 100, 200)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(50, 140, 220)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(120, 80, 255)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(70, 130, 255)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(140, 100, 240)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(90, 110, 230)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(130, 70, 255)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(100, 120, 255)",secondary:"rgba(130, 100, 220, 0.98)"},spikeLt:{primary:"rgb(60, 60, 180)",secondary:"rgb(80, 100, 200)"}},sunset:{border:[{color:"rgb(255, 80, 50)",pos:"33% -7.4%",size:"70px 40px"},{color:"rgb(255, 160, 40)",pos:"12% -5%",size:"60px 35px"},{color:"rgb(255, 120, 60)",pos:"2.1% 68.3%",size:"40px 70px"},{color:"rgb(255, 200, 50)",pos:"2.1% 68.3%",size:"20px 35px"},{color:"rgb(255, 100, 80)",pos:"74.4% 100%",size:"180px 32px"},{color:"rgb(255, 180, 60)",pos:"55% 100%",size:"85px 26px"},{color:"rgb(255, 60, 60)",pos:"93.9% 0%",size:"74px 32px"},{color:"rgb(255, 140, 50)",pos:"100% 27.1%",size:"26px 42px"},{color:"rgb(255, 90, 70)",pos:"100% 27.1%",size:"52px 48px"}],spike:{primary:"rgb(255, 140, 80)",secondary:"rgba(255, 100, 60, 0.98)"},spikeLt:{primary:"rgb(200, 80, 40)",secondary:"rgb(220, 120, 30)"}}},Le={colorful:{border:[{color:"rgb(50, 200, 80)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(30, 185, 170)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 120, 40)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(100, 70, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(240, 50, 180)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(180, 40, 240)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(40, 140, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 50, 100)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(50, 200, 80, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(30, 185, 170, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 120, 40, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(100, 70, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(240, 50, 180, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(180, 40, 240, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(40, 140, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 50, 100, 0.3)",pos:"100% 27%",size:"11px 12px"}]},mono:{border:[{color:"rgb(160, 160, 160)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(140, 140, 140)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(180, 180, 180)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(150, 150, 150)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(170, 170, 170)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(155, 155, 155)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(145, 145, 145)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(165, 165, 165)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(160, 160, 160, 0.25)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(140, 140, 140, 0.22)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(180, 180, 180, 0.17)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(150, 150, 150, 0.17)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(170, 170, 170, 0.15)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(155, 155, 155, 0.20)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(145, 145, 145, 0.15)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(165, 165, 165, 0.15)",pos:"100% 27%",size:"11px 12px"}]},ocean:{border:[{color:"rgb(60, 140, 200)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(50, 120, 180)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(100, 80, 220)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(80, 100, 255)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(120, 70, 240)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(90, 80, 220)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(70, 110, 255)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(110, 90, 230)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(60, 140, 200, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(50, 120, 180, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(100, 80, 220, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(80, 100, 255, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(120, 70, 240, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(90, 80, 220, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(70, 110, 255, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(110, 90, 230, 0.3)",pos:"100% 27%",size:"11px 12px"}]},sunset:{border:[{color:"rgb(255, 180, 50)",pos:"2% 68%",size:"9px 18px"},{color:"rgb(255, 150, 40)",pos:"2% 68%",size:"4px 8px"},{color:"rgb(255, 80, 60)",pos:"72% -3%",size:"59px 9px"},{color:"rgb(255, 100, 80)",pos:"74% 100%",size:"42px 7px"},{color:"rgb(255, 60, 80)",pos:"100% 27%",size:"10px 17px"},{color:"rgb(255, 120, 60)",pos:"100% 27%",size:"10px 18px"},{color:"rgb(255, 200, 50)",pos:"100% 27%",size:"5px 10px"},{color:"rgb(255, 90, 70)",pos:"100% 27%",size:"11px 12px"}],inner:[{color:"rgba(255, 180, 50, 0.5)",pos:"2% 68%",size:"9px 18px"},{color:"rgba(255, 150, 40, 0.45)",pos:"2% 68%",size:"4px 8px"},{color:"rgba(255, 80, 60, 0.35)",pos:"72% -3%",size:"59px 9px"},{color:"rgba(255, 100, 80, 0.35)",pos:"74% 100%",size:"42px 7px"},{color:"rgba(255, 60, 80, 0.3)",pos:"100% 27%",size:"10px 17px"},{color:"rgba(255, 120, 60, 0.4)",pos:"100% 27%",size:"10px 18px"},{color:"rgba(255, 200, 50, 0.3)",pos:"100% 27%",size:"5px 10px"},{color:"rgba(255, 90, 70, 0.3)",pos:"100% 27%",size:"11px 12px"}]}};function Oa(r){return Le[r].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Fa(r){return Le[r].inner.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function Ra(r){return ae[r].border.map(e=>`radial-gradient(ellipse ${e.size} at ${e.pos}, ${e.color}, transparent)`).join(`,
    `)}function _a(r){const e=ae[r],a=r==="mono"?.225:.45;return e.border.map(o=>{const s=o.color.replace("rgb(","rgba(").replace(")",`, ${a})`);return`radial-gradient(ellipse ${o.size.split(" ").map(i=>{const l=parseInt(i);return`${Math.round(l*.9)}px`}).join(" ")} at ${o.pos}, ${s}, transparent)`}).join(`,
    `)}function Aa(r,e){const a=ae[r];return e?a.spike:a.spikeLt}const qa={colorful:{dark:[{color:"rgb(255, 50, 100)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 180, 220)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 160, 30)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(240, 50, 180)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(30, 185, 170)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(255, 50, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(40, 140, 255)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(50, 200, 80)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(180, 40, 240)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(30, 185, 170)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 255)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(40, 140, 255)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(255, 120, 40)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(240, 50, 180)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},mono:{dark:[{color:"rgb(200, 200, 200)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(170, 170, 170)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(155, 155, 155)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(185, 185, 185)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(165, 165, 165)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(180, 180, 180)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(160, 160, 160)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(175, 175, 175)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(190, 190, 190)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(100, 100, 100)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(80, 80, 80)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(90, 90, 90)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(70, 70, 70)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(85, 85, 85)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(95, 95, 95)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(75, 75, 75)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(105, 105, 105)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(65, 65, 65)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},ocean:{dark:[{color:"rgb(100, 80, 220)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(60, 120, 255)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(80, 100, 200)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(130, 70, 255)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(70, 130, 255)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(120, 80, 255)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(90, 110, 230)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(110, 90, 240)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(140, 100, 255)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(80, 60, 200)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(50, 100, 220)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(70, 90, 190)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(110, 60, 220)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(60, 110, 230)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(100, 70, 240)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(80, 100, 210)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(90, 80, 225)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(120, 90, 245)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]},sunset:{dark:[{color:"rgb(255, 100, 60)",sizeW:36,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(255, 180, 50)",sizeW:30,sizeH:32,offsetX:39,offsetY:0},{color:"rgb(255, 140, 70)",sizeW:33,sizeH:28,offsetX:-36,offsetY:2},{color:"rgb(255, 80, 80)",sizeW:29,sizeH:34,offsetX:-54,offsetY:0},{color:"rgb(255, 200, 60)",sizeW:27,sizeH:30,offsetX:51,offsetY:-1},{color:"rgb(255, 120, 50)",sizeW:36,sizeH:24,offsetX:21,offsetY:1},{color:"rgb(255, 160, 80)",sizeW:30,sizeH:22,offsetX:-21,offsetY:0},{color:"rgb(255, 90, 60)",sizeW:25,sizeH:28,offsetX:66,offsetY:1},{color:"rgb(255, 70, 70)",sizeW:23,sizeH:30,offsetX:-66,offsetY:-1}],light:[{color:"rgb(220, 80, 40)",sizeW:45,sizeH:36,offsetX:0,offsetY:2},{color:"rgb(230, 150, 30)",sizeW:35,sizeH:32,offsetX:65,offsetY:0},{color:"rgb(210, 110, 50)",sizeW:40,sizeH:28,offsetX:-60,offsetY:2},{color:"rgb(200, 60, 60)",sizeW:35,sizeH:34,offsetX:-90,offsetY:0},{color:"rgb(220, 170, 40)",sizeW:38,sizeH:30,offsetX:85,offsetY:-1},{color:"rgb(210, 100, 30)",sizeW:50,sizeH:24,offsetX:35,offsetY:1},{color:"rgb(230, 130, 60)",sizeW:40,sizeH:22,offsetX:-35,offsetY:0},{color:"rgb(190, 70, 50)",sizeW:35,sizeH:28,offsetX:110,offsetY:1},{color:"rgb(180, 50, 50)",sizeW:30,sizeH:30,offsetX:-110,offsetY:-1}]}};function Ea(r,e,a){return qa[r][e?"dark":"light"].map(o=>{const s=o.offsetX===0?"":o.offsetX>0?` + ${o.offsetX}px`:` - ${Math.abs(o.offsetX)}px`,i=o.offsetY===0?"":o.offsetY>0?` + ${o.offsetY}px`:` - ${Math.abs(o.offsetY)}px`;return`radial-gradient(ellipse calc(${o.sizeW}px * var(--beam-w-${a})) calc(${o.sizeH}px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%${s}) calc(100%${i}), ${o.color}, transparent)`}).join(`,
       `)}const La={colorful:[{color:"rgba(255, 50, 100, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(40, 180, 220, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(50, 200, 80, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(180, 40, 240, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 160, 30, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(100, 70, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(40, 140, 255, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(240, 50, 180, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(30, 185, 170, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],mono:[{color:"rgba(200, 200, 200, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(170, 170, 170, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(155, 155, 155, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(185, 185, 185, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(165, 165, 165, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(180, 180, 180, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(160, 160, 160, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(175, 175, 175, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(190, 190, 190, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],ocean:[{color:"rgba(100, 80, 220, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(60, 120, 255, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(80, 100, 200, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(130, 70, 255, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(70, 130, 255, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(120, 80, 255, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(90, 110, 230, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(110, 90, 240, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(140, 100, 255, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}],sunset:[{color:"rgba(255, 100, 60, 0.48)",sizeW:33,sizeH:30,offsetX:0,offsetY:0},{color:"rgba(255, 180, 50, 0.42)",sizeW:24,sizeH:26,offsetX:39,offsetY:-3},{color:"rgba(255, 140, 70, 0.48)",sizeW:27,sizeH:24,offsetX:-36,offsetY:0},{color:"rgba(255, 80, 80, 0.42)",sizeW:23,sizeH:28,offsetX:-54,offsetY:-2},{color:"rgba(255, 200, 60, 0.50)",sizeW:24,sizeH:24,offsetX:51,offsetY:-1},{color:"rgba(255, 120, 50, 0.45)",sizeW:30,sizeH:20,offsetX:21,offsetY:0},{color:"rgba(255, 160, 80, 0.40)",sizeW:25,sizeH:18,offsetX:-21,offsetY:-2},{color:"rgba(255, 90, 60, 0.45)",sizeW:21,sizeH:24,offsetX:66,offsetY:0},{color:"rgba(255, 70, 70, 0.52)",sizeW:18,sizeH:26,offsetX:-66,offsetY:-1}]};function Ta(r,e){return La[r].map(a=>{const o=a.offsetX===0?"":a.offsetX>0?` + ${a.offsetX}px`:` - ${Math.abs(a.offsetX)}px`,s=a.offsetY===0?"":` - ${Math.abs(a.offsetY)}px`;return`radial-gradient(ellipse calc(${a.sizeW}px * var(--beam-w-${e})) calc(${a.sizeH}px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%${o}) calc(100%${s}), ${a.color}, transparent)`}).join(`,
    `)}const Pa={colorful:{dark:{spikes:[{color1:"rgb(100, 70, 255)",color2:"rgba(100, 70, 255, 1)"},{color1:"rgba(255, 170, 40, 0.59)",color2:"rgba(255, 170, 40, 0.29)"},{color1:"rgb(50, 200, 100)",color2:"rgba(50, 200, 100, 1)"},{color1:"rgba(200, 50, 240, 0.91)",color2:"rgba(200, 50, 240, 0.45)"},{color1:"rgb(40, 140, 255)",color2:"rgba(40, 140, 255, 1)"}]},light:{spikes:[{color1:"rgb(80, 50, 200)",color2:"rgba(80, 50, 200, 0.8)"},{color1:"rgba(210, 130, 0, 0.7)",color2:"rgba(210, 130, 0, 0.46)"},{color1:"rgb(30, 160, 70)",color2:"rgba(30, 160, 70, 0.82)"},{color1:"rgb(160, 30, 190)",color2:"rgba(160, 30, 190, 0.7)"},{color1:"rgb(30, 100, 200)",color2:"rgba(30, 100, 200, 0.78)"}]}},mono:{dark:{spikes:[{color1:"rgb(200, 200, 200)",color2:"rgba(200, 200, 200, 1)"},{color1:"rgba(180, 180, 180, 0.59)",color2:"rgba(180, 180, 180, 0.29)"},{color1:"rgb(190, 190, 190)",color2:"rgba(190, 190, 190, 1)"},{color1:"rgba(170, 170, 170, 0.91)",color2:"rgba(170, 170, 170, 0.45)"},{color1:"rgb(185, 185, 185)",color2:"rgba(185, 185, 185, 1)"}]},light:{spikes:[{color1:"rgb(80, 80, 80)",color2:"rgba(80, 80, 80, 0.8)"},{color1:"rgba(100, 100, 100, 0.7)",color2:"rgba(100, 100, 100, 0.46)"},{color1:"rgb(70, 70, 70)",color2:"rgba(70, 70, 70, 0.82)"},{color1:"rgb(90, 90, 90)",color2:"rgba(90, 90, 90, 0.7)"},{color1:"rgb(85, 85, 85)",color2:"rgba(85, 85, 85, 0.78)"}]}},ocean:{dark:{spikes:[{color1:"rgb(100, 80, 255)",color2:"rgb(100, 80, 255)"},{color1:"rgba(80, 130, 220, 0.59)",color2:"rgba(80, 130, 220, 0.29)"},{color1:"rgb(60, 100, 255)",color2:"rgb(60, 100, 255)"},{color1:"rgba(90, 120, 200, 0.91)",color2:"rgba(90, 120, 200, 0.45)"},{color1:"rgb(120, 90, 255)",color2:"rgb(120, 90, 255)"}]},light:{spikes:[{color1:"rgb(50, 40, 180)",color2:"rgba(50, 40, 180, 0.8)"},{color1:"rgba(40, 80, 200, 0.7)",color2:"rgba(40, 80, 200, 0.46)"},{color1:"rgb(30, 50, 190)",color2:"rgba(30, 50, 190, 0.82)"},{color1:"rgb(60, 90, 180)",color2:"rgba(60, 90, 180, 0.7)"},{color1:"rgb(70, 60, 200)",color2:"rgba(70, 60, 200, 0.78)"}]}},sunset:{dark:{spikes:[{color1:"rgb(255, 100, 80)",color2:"rgb(255, 100, 80)"},{color1:"rgba(255, 150, 80, 0.59)",color2:"rgba(255, 150, 80, 0.29)"},{color1:"rgb(255, 80, 60)",color2:"rgb(255, 80, 60)"},{color1:"rgba(255, 120, 50, 0.91)",color2:"rgba(255, 120, 50, 0.45)"},{color1:"rgb(255, 140, 70)",color2:"rgb(255, 140, 70)"}]},light:{spikes:[{color1:"rgb(200, 60, 30)",color2:"rgba(200, 60, 30, 0.8)"},{color1:"rgba(220, 100, 20, 0.7)",color2:"rgba(220, 100, 20, 0.46)"},{color1:"rgb(180, 40, 20)",color2:"rgba(180, 40, 20, 0.82)"},{color1:"rgb(210, 80, 10)",color2:"rgba(210, 80, 10, 0.7)"},{color1:"rgb(190, 70, 30)",color2:"rgba(190, 70, 30, 0.78)"}]}}};function ve(r,e){const a=r.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*[\d.]+\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${e})`;const o=r.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return o?`rgba(${o[1]}, ${o[2]}, ${o[3]}, ${e})`:r}function ee(r,e){const a=r.match(/^rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);if(a)return`rgba(${a[1]}, ${a[2]}, ${a[3]}, ${(parseFloat(a[4])*e).toFixed(2)})`;const o=r.match(/^rgb\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)$/);return o?`rgba(${o[1]}, ${o[2]}, ${o[3]}, ${e.toFixed(2)})`:r}function Da(r,e,a){const o=Aa(r,e),s=Pa[r][e?"dark":"light"],i=r==="mono",l=i?.14:1,c=i?ee(o.primary,.14):o.primary,m=i?ee(o.primary,.09):o.primary,x=i?ee(o.secondary,.12):o.secondary,d=i?ve(o.secondary,.06):ve(o.secondary,.49),n=s.spikes.map(X=>i?{color1:ee(X.color1,l),color2:ee(X.color2,l*.7)}:X),g=i?"12px":"0.8px",u=i?"14px":"2px",b=i?"12px":"1.2px",v=i?"10px":"0.6px",k=i?"42px":"92px",H=i?"38px":"72px",f=i?"40px":"85px",y=i?"32px":"60px",w=i?"12px":"1px",N=i?"rgba(255, 255, 255, 0.5)":"rgba(255, 255, 255, 1)",h=i?"rgba(255, 255, 255, 0.45)":"rgba(255, 255, 255, 0.9)",z=i?"rgba(255, 255, 255, 0.25)":"rgba(255, 255, 255, 0.5)",j=i?"rgba(255, 255, 255, 0.15)":"rgba(255, 255, 255, 0.3)",S=i?"rgba(255, 255, 255, 0.06)":"rgba(255, 255, 255, 0.12)",W=i?"rgba(255, 255, 255, 0.015)":"rgba(255, 255, 255, 0.03)";if(e)return`radial-gradient(ellipse calc(${g} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${m} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${x}, ${d} 50%, transparent 95%),
       radial-gradient(ellipse calc(${u} * (2 - var(--beam-spike-${a}))) calc(${H} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${n[0].color1}, ${n[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${n[1].color1}, ${n[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${b} * (2 - var(--beam-spike2-${a}))) calc(${f} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${n[2].color1}, ${n[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${n[3].color1}, ${n[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${v} * (2 - var(--beam-spike-${a}))) calc(${y} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${n[4].color1}, ${n[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(21px * var(--beam-spike-${a})) calc(15px * var(--beam-spike2-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100% + 1px), ${N} 0%, ${h} 20%, ${z} 50%, transparent 100%),
       radial-gradient(ellipse calc(42px * var(--beam-w-${a})) calc(40px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) 100%, ${j} 0%, ${S} 25%, ${W} 55%, transparent 80%)`;{const X=i?ee(o.primary,.11):ve(o.primary,.85),q=i?ee(o.secondary,.09):ve(o.secondary,.7);return`radial-gradient(ellipse calc(${g} * var(--beam-spike-${a})) calc(${k} * var(--beam-h-${a})) at 8% calc(100% - 2px), ${c}, ${X} 30%, transparent 88%),
       radial-gradient(ellipse calc(10px * var(--beam-spike2-${a})) calc(35px * var(--beam-h-${a})) at 22% calc(100% - 4px), ${x}, ${q} 50%, transparent 95%),
       radial-gradient(ellipse calc(${u} * (2 - var(--beam-spike-${a}))) calc(${H} * var(--beam-h-${a})) at 36% calc(100% - 3px), ${n[0].color1}, ${n[0].color2} 40%, transparent 90%),
       radial-gradient(ellipse calc(14px * var(--beam-spike2-${a})) calc(28px * var(--beam-h-${a})) at 50% calc(100% - 2px), ${n[1].color1}, ${n[1].color2} 55%, transparent 96%),
       radial-gradient(ellipse calc(${b} * (2 - var(--beam-spike2-${a}))) calc(${f} * var(--beam-h-${a})) at 64% calc(100% - 4px), ${n[2].color1}, ${n[2].color2} 35%, transparent 89%),
       radial-gradient(ellipse calc(7px * var(--beam-spike-${a})) calc(45px * var(--beam-h-${a})) at 78% calc(100% - 2px), ${n[3].color1}, ${n[3].color2} 48%, transparent 94%),
       radial-gradient(ellipse calc(${w} * (2 - var(--beam-spike-${a}))) calc(${y} * var(--beam-h-${a})) at 92% calc(100% - 3px), ${n[4].color1}, ${n[4].color2} 42%, transparent 91%),
       radial-gradient(ellipse calc(50px * var(--beam-w-${a})) calc(32px * var(--beam-h-${a})) at calc(var(--beam-x-${a}) * 100%) calc(100%), rgba(0, 0, 0, 0.5) 0%, rgba(0, 0, 0, 0.18) 30%, rgba(0, 0, 0, 0.03) 60%, transparent 85%)`}}const Te=[{region:1,quad:"tl"},{region:2,quad:"tl"},{region:3,quad:"bl"},{region:1,quad:"bl"},{region:2,quad:"br"},{region:3,quad:"br"},{region:1,quad:"tr"},{region:2,quad:"tr"},{region:3,quad:"tr"}],Ua=[[65,35],[55,30],[35,65],[15,30],[173,28],[80,22],[69,28],[22,38],[47,44]],Va=[{ci:0,region:1,quad:"tl",w:84,h:48},{ci:1,region:2,quad:"tl",w:72,h:42},{ci:2,region:3,quad:"bl",w:48,h:84},{ci:4,region:2,quad:"br",w:216,h:38},{ci:5,region:3,quad:"br",w:102,h:31},{ci:6,region:1,quad:"tr",w:89,h:38},{ci:8,region:3,quad:"tr",w:62,h:58}],Oe=[{ci:0,region:1,quad:"tl",w:80,h:19,x:"27%",y:"0%"},{ci:6,region:2,quad:"tr",w:74,h:11,x:"73%",y:"-1%"},{ci:7,region:3,quad:"tr",w:15,h:44,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:19,h:38,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:84,h:13,x:"67%",y:"100%"},{ci:1,region:3,quad:"bl",w:60,h:21,x:"24%",y:"101%"},{ci:2,region:1,quad:"bl",w:17,h:40,x:"0%",y:"60%"},{ci:3,region:2,quad:"tl",w:13,h:32,x:"-1%",y:"28%"}],Ba=[{ci:0,region:1,quad:"tl",w:110,h:30,x:"27%",y:"3%"},{ci:6,region:2,quad:"tr",w:100,h:20,x:"73%",y:"1%"},{ci:7,region:3,quad:"tr",w:26,h:62,x:"100%",y:"33%"},{ci:8,region:1,quad:"br",w:30,h:56,x:"101%",y:"72%"},{ci:4,region:2,quad:"br",w:120,h:22,x:"67%",y:"99%"},{ci:1,region:3,quad:"bl",w:88,h:32,x:"24%",y:"99%"},{ci:2,region:1,quad:"bl",w:28,h:58,x:"0%",y:"60%"}];function Ga(r,e,a){const o=r.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/);return`rgba(${o?`${o[1]}, ${o[2]}, ${o[3]}`:"255, 255, 255"}, var(--bop-${e}-${a}))`}function Ye(r,e,a,o,s,i,l,c){return`radial-gradient(ellipse calc(${e}px * var(--bw${o}-${c}) * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${a}px * var(--bh${o}-${c}) * var(--bgh-${c}) * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at calc(${i} + var(--bx${o}-${c})) calc(${l} + var(--by${o}-${c})), ${Ga(r,s,c)}, transparent)`}function Ia(r,e){return ae[r].border.map((a,o)=>{const{region:s,quad:i}=Te[o],[l,c]=a.pos.split(" "),[m,x]=a.size.split(" ").map(parseFloat);return Ye(a.color,m,x,s,i,l,c,e)}).join(`,
    `)}function Ja(r,e,a){const o=ae[r].border.map((c,m)=>{const{region:x,quad:d}=Te[m],[n,g]=c.pos.split(" "),[u,b]=Ua[m];return Ye(c.color,u,b,x,d,n,g,e)}),s=a?"255, 255, 255":"0, 0, 0",i=a?.18:.08,l=[["0%","0%","tl"],["100%","0%","tr"],["0%","100%","bl"],["100%","100%","br"]].map(([c,m,x])=>`radial-gradient(ellipse 60px 60px at ${c} ${m}, rgba(${s}, calc(${i} * var(--bop-${x}-${e}))), transparent 70%)`);return[...o,...l].join(`,
    `)}function Fe(r,e,a){const o=ae[e].border;return r.map(s=>{const i=o[s.ci],[l,c]=i.pos.split(" ");return Ye(i.color,s.w,s.h,s.region,s.quad,s.x??l,s.y??c,a)}).join(`,
    `)}function Pe(r,e,a){const o=ae[e].border,s=+a.toFixed(3);return r.map(i=>{const l=o[i.ci],[c,m]=l.pos.split(" "),x=i.x??c,d=i.y??m,n=l.color.match(/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/),g=n?`${n[1]}, ${n[2]}, ${n[3]}`:"255, 255, 255";return`radial-gradient(ellipse calc(${i.w}px * var(--pulse-glow-sx, 1) * var(--pulse-glow-boost, 1)) calc(${i.h}px * var(--pulse-glow-sy, 1) * var(--pulse-glow-boost, 1)) at ${x} ${d}, rgba(${g}, ${s}), transparent)`}).join(`,
    `)}function ue(r){return`
[data-beam="${r}"][data-paused],
[data-beam="${r}"][data-paused]::after,
[data-beam="${r}"][data-paused]::before,
[data-beam="${r}"][data-paused] [data-beam-bloom] {
  animation-play-state: paused !important;
}`}function De(r){const e=["bw1","bh1","bw2","bh2","bw3","bh3","bgh","bop-tl","bop-tr","bop-bl","bop-br"],a=["bx1","by1","bx2","by2","bx3","by3"],o=e.map(i=>`@property --${i}-${r} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}`).join(`

`),s=a.map(i=>`@property --${i}-${r} {
  syntax: "<length>";
  initial-value: 0px;
  inherits: true;
}`).join(`

`);return`${o}

${s}

@property --beam-opacity-${r} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-hue-${r} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}`}function Se(r,e,a){const o=e==="dark",s=a/2.3;return r==="pulse-inner"?{sp:.28,dr:o?33:40,op:o?.48:.45,gh:o?.34:.22,bs:(o?1.9:2.6)*s,ss:(o?2.6:4.6)*s,ghs:(o?2.4:5.5)*s,huePeriod:16}:{sp:o?.28:.36,dr:o?14:19,op:o?.46:0,gh:o?.16:.58,bs:(o?2.3:3.7)*s,ss:(o?6.4:4.6)*s,ghs:(o?2.4:3.8)*s,huePeriod:14}}function Ka(r,e){const{sp:a,dr:o,op:s,gh:i,bs:l,ss:c,ghs:m}=e;return[{prop:`--bw1-${r}`,a:1-a,b:1+a*1.1,period:c*.9,delay:0,unit:""},{prop:`--bh1-${r}`,a:1+a*.9,b:1-a*.85,period:c*1.26,delay:0,unit:""},{prop:`--bx1-${r}`,a:-o,b:o*.9,period:l*1.6,delay:0,unit:"px"},{prop:`--by1-${r}`,a:o*.55,b:-o*.7,period:l*1.6,delay:0,unit:"px"},{prop:`--bw2-${r}`,a:1+a,b:1-a*.85,period:c*1.1,delay:0,unit:""},{prop:`--bh2-${r}`,a:1-a*.8,b:1+a*1.05,period:c*.81,delay:0,unit:""},{prop:`--bx2-${r}`,a:o*.8,b:-o*.9,period:l*1.88,delay:0,unit:"px"},{prop:`--by2-${r}`,a:-o,b:o*.65,period:l*1.88,delay:0,unit:"px"},{prop:`--bw3-${r}`,a:1-a*.6,b:1+a*1.15,period:c*.98,delay:0,unit:""},{prop:`--bh3-${r}`,a:1+a*.75,b:1-a,period:c*1.4,delay:0,unit:""},{prop:`--bx3-${r}`,a:-o*.6,b:o,period:l*1.45,delay:0,unit:"px"},{prop:`--by3-${r}`,a:-o*.85,b:o*.45,period:l*1.45,delay:0,unit:"px"},{prop:`--bgh-${r}`,a:1-i,b:1+i,period:m,delay:0,unit:""},{prop:`--bop-tl-${r}`,a:1-s,b:1,period:l,delay:0,unit:""},{prop:`--bop-tr-${r}`,a:1-s,b:1,period:l*1.32,delay:l*.28,unit:""},{prop:`--bop-bl-${r}`,a:1-s,b:1,period:l*.84,delay:l*.55,unit:""},{prop:`--bop-br-${r}`,a:1-s,b:1,period:l*1.58,delay:l*.83,unit:""}]}function Qa(r,e,a,o,s,i){if(r!=="pulse-inner"&&r!=="pulse-outside")return null;const l=Se(r,e,a);return{oscillators:Ka(i,l),hue:s?null:{prop:`--beam-hue-${i}`,range:360,period:l.huePeriod,continuous:!0}}}function ke(r,e,a){return`  animation: ${e}-${r} ${a}s ease forwards;`}function Za(r){const{size:e}=r;return e==="line"?ot(r):e==="sm"?et(r):e==="pulse-inner"?tt(r):e==="pulse-outside"?rt(r):at(r)}function et(r){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:i,innerOpacity:l,bloomOpacity:c,innerShadow:m,colorVariant:x,staticColors:d,brightness:n,saturation:g,hueRange:u,theme:b}=r,v=Math.max(0,a-o),k=x==="mono"?.5:1,H=i*k,f=l*k,y=c*k,w=d?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,N=d?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
}`,h=b==="dark",z=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,j=Oa(x),S=Fa(x),W=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`,X=`conic-gradient(
    from var(--beam-angle-${e}),
    transparent 0%, transparent 22%,
    rgba(255, 255, 255, 0.12) 28%, rgba(255, 255, 255, 0.4) 36%,
    white 46%, white 82%,
    rgba(255, 255, 255, 0.4) 88%, rgba(255, 255, 255, 0.12) 94%,
    transparent 97%, transparent 100%
  )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${z},${j};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${w}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  box-shadow: inset 0 0 5px 1px ${m};
  -webkit-mask-image: ${X};
  -webkit-mask-composite: source-over;
  mask-image: ${X};
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${f.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${w}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  clip-path: inset(0 round ${a}px);
  background: ${W};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  filter: blur(8px) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${N}
${ue(e)}
`}function at(r){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:i,innerOpacity:l,bloomOpacity:c,innerShadow:m,colorVariant:x,staticColors:d,brightness:n,saturation:g,hueRange:u,theme:b}=r,v=Math.max(0,a-o),k=x==="mono"?.5:1,H=i*k,f=l*k,y=c*k,w=d?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,N=d?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
}`,h=b==="dark",z=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(255, 255, 255, 0.1) 57%,
        rgba(255, 255, 255, 0.3) 60%,
        rgba(255, 255, 255, 0.6) 63%,
        rgba(255, 255, 255, 0.75) 66%,
        rgba(255, 255, 255, 0.6) 69%,
        rgba(255, 255, 255, 0.3) 72%,
        rgba(255, 255, 255, 0.1) 75%,
        transparent 78%, transparent 100%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 54%,
        rgba(0, 0, 0, 0.08) 57%,
        rgba(0, 0, 0, 0.2) 60%,
        rgba(0, 0, 0, 0.4) 63%,
        rgba(0, 0, 0, 0.55) 66%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.2) 72%,
        rgba(0, 0, 0, 0.08) 75%,
        transparent 78%, transparent 100%
      )`,j=Ra(x),S=_a(x),W=h?`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(255, 255, 255, 0.03) 62%,
        rgba(255, 255, 255, 0.08) 65%,
        rgba(255, 255, 255, 0.2) 67%,
        rgba(255, 255, 255, 0.45) 69%,
        rgba(255, 255, 255, 0.85) 70%,
        rgba(255, 255, 255, 0.85) 70.5%,
        rgba(255, 255, 255, 0.45) 71.5%,
        rgba(255, 255, 255, 0.2) 73%,
        rgba(255, 255, 255, 0.08) 75%,
        rgba(255, 255, 255, 0.03) 78%,
        transparent 82%
      )`:`conic-gradient(
        from var(--beam-angle-${e}),
        transparent 0%, transparent 58%,
        rgba(0, 0, 0, 0.02) 62%,
        rgba(0, 0, 0, 0.08) 65%,
        rgba(0, 0, 0, 0.2) 67%,
        rgba(0, 0, 0, 0.4) 69%,
        rgba(0, 0, 0, 0.6) 70%,
        rgba(0, 0, 0, 0.6) 70.5%,
        rgba(0, 0, 0, 0.4) 71.5%,
        rgba(0, 0, 0, 0.2) 73%,
        rgba(0, 0, 0, 0.08) 75%,
        rgba(0, 0, 0, 0.02) 78%,
        transparent 82%
      )`;return`
@property --beam-angle-${e} {
  syntax: "<angle>";
  initial-value: 0deg;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-spin-${e} ${s}s linear infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${z},${j};
  -webkit-mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${w}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${S};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    conic-gradient(
      from var(--beam-angle-${e}),
      transparent 0%, transparent 30%,
      rgba(255, 255, 255, 0.1) 36%, rgba(255, 255, 255, 0.35) 44%,
      white 52%, white 80%,
      rgba(255, 255, 255, 0.35) 86%, rgba(255, 255, 255, 0.1) 92%,
      transparent 95%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * ${f.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${w}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  clip-path: inset(0 round ${a}px);
  background: ${W};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  filter: blur(8px) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)});
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
}

@keyframes beam-spin-${e} {
  to { --beam-angle-${e}: 360deg; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${N}
${ue(e)}
`}function tt(r){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:i,innerOpacity:l,bloomOpacity:c,colorVariant:m,staticColors:x,brightness:d,saturation:n,hueRange:g,theme:u}=r,b=u==="dark",v=m==="mono"?.5:1,k=(i*v).toFixed(2),H=(l*v).toFixed(2),f=(c*v).toFixed(2),{op:y}=Se("pulse-inner",u,s),w=8,N=d.toFixed(2),h=n.toFixed(2),z=x?`filter: brightness(${N}) saturate(${h});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${N}) saturate(${h});`,j=x?`filter: blur(${w}px) brightness(${N}) saturate(${h});`:`filter: blur(${w}px) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${N}) saturate(${h});`,S=Ia(m,e),W=Ja(m,e,b),X=Pe(Va,m,1-y*.5);return`
${De(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ke(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ke(e,"beam-fade-out",.5)}
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${S};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${z}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${W};
  -webkit-mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-over;
  mask-image:
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: add;
  pointer-events: none;
  z-index: 1;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${H} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${z}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  clip-path: inset(0 round ${a}px);
  background: ${X};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  padding: ${o}px;
  pointer-events: none;
  z-index: 3;
  will-change: opacity;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${f} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${j}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ue(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function rt(r){const{id:e,borderRadius:a,duration:o,strokeOpacity:s,innerOpacity:i,bloomOpacity:l,colorVariant:c,staticColors:m,brightness:x,saturation:d,hueRange:n,theme:g,hairlineOpacity:u=0}=r,b=g==="dark",v=c==="mono"?.5:1,k=(s*v).toFixed(2),H=(i*v).toFixed(2),f=(l*v).toFixed(2),y=b?"70, 70, 70":"0, 0, 0",w=u.toFixed(2),N=`linear-gradient(rgba(${y}, ${w}), rgba(${y}, ${w}))`,{op:h}=Se("pulse-outside",g,o),z=.95,j=.9,S=b?3:6,W=b?22.5:15,X=x.toFixed(2),q=d.toFixed(2),te=m?`filter: brightness(${X}) saturate(${q});`:`filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) brightness(${X}) saturate(${q});`,R=`brightness(var(--beam-glow-brightness, ${X})) saturate(var(--beam-glow-saturate, ${q}))`,L=m?`filter: blur(var(--beam-core-blur, ${S}px)) ${R};`:`filter: blur(var(--beam-core-blur, ${S}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${R};`,ne=m?`filter: blur(var(--beam-bloom-blur, ${W}px)) ${R};`:`filter: blur(var(--beam-bloom-blur, ${W}px)) hue-rotate(calc(var(--beam-hue-base, 0deg) + var(--beam-hue-${e}))) ${R};`,E=Fe(Oe,c,e),O=Fe(Oe,c,e),G=Pe(Ba,c,1-h*.5),I=u>0?`${E},
    ${N}`:E;return`
${De(e)}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: visible;
  isolation: isolate;
}

[data-beam="${e}"][data-active] {
${ke(e,"beam-fade-in",.6)}
}

[data-beam="${e}"][data-fading] {
${ke(e,"beam-fade-out",.5)}
}
${u>0?`
/* Idle hairline — painted above the (opaque) child in the inner 1px edge ring so
   it overlaps a standard inset component border exactly. */
[data-beam="${e}"]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${N};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
}
`:""}
[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  padding: 1px;
  clip-path: inset(0 round ${a}px);
  background: ${I};
  -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite: exclude;
  pointer-events: none;
  z-index: 2;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${k} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${te}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: -10px;
  z-index: -1;
  border-radius: ${a+10}px;
  background: ${O};
  transform: scale(${z}, ${j});
  pointer-events: none;
  will-change: opacity, filter;
  opacity: calc(var(--beam-opacity-${e}) * ${H} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  ${L}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: -30px;
  z-index: -1;
  border-radius: ${a+30}px;
  background: ${G};
  transform: scale(${z}, ${j});
  pointer-events: none;
  will-change: transform;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * ${f} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${ne}
}

@keyframes beam-fade-in-${e} { to { --beam-opacity-${e}: 1; } }
@keyframes beam-fade-out-${e} { from { --beam-opacity-${e}: 1; } to { --beam-opacity-${e}: 0; } }
${ue(e)}

@media (prefers-reduced-motion: reduce) {
  [data-beam="${e}"][data-active],
  [data-beam="${e}"][data-fading],
  [data-beam="${e}"][data-active]::after,
  [data-beam="${e}"][data-fading]::after,
  [data-beam="${e}"][data-active]::before,
  [data-beam="${e}"][data-fading]::before,
  [data-beam="${e}"][data-active] [data-beam-bloom],
  [data-beam="${e}"][data-fading] [data-beam-bloom] {
    animation: none !important;
  }
}
`}function ot(r){const{id:e,borderRadius:a,borderWidth:o,duration:s,strokeOpacity:i,innerOpacity:l,bloomOpacity:c,innerShadow:m,colorVariant:x,staticColors:d,brightness:n,saturation:g,hueRange:u,theme:b}=r,v=Math.max(0,a-o),k=b==="dark",H=i,f=l,y=c,w=d?"":`animation: beam-hue-shift-${e} 12s ease-in-out infinite;`,N=d?"":`animation: beam-hue-shift-bloom-${e} 8s ease-in-out infinite;`,h=d?"":`
@keyframes beam-hue-shift-${e} {
  0% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  50% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) + ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  100% { filter: hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
}

@keyframes beam-hue-shift-bloom-${e} {
  0% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u+10}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  50% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) + ${u+10}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
  100% { filter: blur(8px) hue-rotate(calc(var(--beam-hue-base, 0deg) - ${u+10}deg)) brightness(${n.toFixed(2)}) saturate(${g.toFixed(2)}); }
}`,z=k?`radial-gradient(
        ellipse calc(24px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(255, 255, 255, 0.38) 0%,
        rgba(255, 255, 255, 0.12) 30%,
        transparent 65%
      )`:`radial-gradient(
        ellipse calc(35px * var(--beam-w-${e})) calc(28px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) calc(100% + 2px),
        rgba(0, 0, 0, 0.6) 0%,
        rgba(0, 0, 0, 0.25) 35%,
        transparent 70%
      )`,j=Ea(x,k,e),S=Ta(x,e),W=Da(x,k,e),X=x==="mono"?"filter: blur(6px);":"";return`
@property --beam-x-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

@property --beam-w-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-h-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-spike2-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-edge-${e} {
  syntax: "<number>";
  initial-value: 1;
  inherits: true;
}

@property --beam-opacity-${e} {
  syntax: "<number>";
  initial-value: 0;
  inherits: true;
}

[data-beam="${e}"] {
  position: relative;
  border-radius: ${a}px;
  overflow: hidden;
}

[data-beam="${e}"][data-active] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-in-${e} 0.6s ease forwards;
}

[data-beam="${e}"][data-fading] {
  animation:
    beam-travel-${e} ${s}s linear infinite,
    beam-edge-fade-${e} ${s}s linear infinite,
    beam-breathe-${e} ${(s*1.3).toFixed(1)}s ease-in-out infinite,
    beam-spike-${e} ${(s*1.33).toFixed(1)}s ease-in-out infinite,
    beam-spike2-${e} ${(s*1.7).toFixed(1)}s ease-in-out infinite,
    beam-fade-out-${e} 0.5s ease forwards;
}

[data-beam="${e}"][data-active]::after,
[data-beam="${e}"][data-fading]::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  padding: ${o}px;
  clip-path: inset(0 round ${a}px);
  background: ${z}, ${j};
  -webkit-mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: source-in, xor;
  mask:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: intersect, exclude;
  pointer-events: none;
  z-index: 2;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${H.toFixed(2)} * var(--beam-stroke-opacity, 1) * var(--beam-strength, 1));
  ${w}
}

[data-beam="${e}"][data-active]::before,
[data-beam="${e}"][data-fading]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: ${a}px;
  background: ${S};
  box-shadow: inset 0 0 9px 1px ${m};
  -webkit-mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  -webkit-mask-composite: source-in, source-over;
  mask-image:
    radial-gradient(
      ellipse calc(78px * var(--beam-w-${e})) calc(60px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
      white 0%, rgba(255, 255, 255, 0.5) 45%, transparent 100%
    ),
    linear-gradient(white, transparent 28px, transparent calc(100% - 28px), white),
    linear-gradient(to right, white, transparent 28px, transparent calc(100% - 28px), white);
  mask-composite: intersect, add;
  pointer-events: none;
  z-index: 1;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${f.toFixed(2)} * var(--beam-inner-opacity, 1) * var(--beam-strength, 1));
  clip-path: inset(0 round ${a}px);
  ${w}
}

[data-beam="${e}"] [data-beam-bloom] {
  display: none;
  position: absolute;
  inset: 0;
  border-radius: ${v}px;
  clip-path: inset(0 round ${a}px);
  padding: 0;
  -webkit-mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  -webkit-mask-composite: source-over;
  mask: radial-gradient(
    ellipse calc(84px * var(--beam-w-${e})) calc(110px * var(--beam-h-${e})) at calc(var(--beam-x-${e}) * 100%) 100%,
    white 0%, rgba(255, 255, 255, 0.5) 35%, transparent 100%
  );
  mask-composite: add;
  background: ${W};
  ${X}
  pointer-events: none;
  z-index: 3;
  opacity: 0;
}

[data-beam="${e}"][data-active] [data-beam-bloom],
[data-beam="${e}"][data-fading] [data-beam-bloom] {
  display: block;
  opacity: calc(var(--beam-opacity-${e}) * var(--beam-edge-${e}) * ${y.toFixed(2)} * var(--beam-bloom-opacity, 1) * var(--beam-strength, 1));
  ${N}
}

@keyframes beam-travel-${e} {
  0%   { --beam-x-${e}: 0.06;  --beam-w-${e}: 0.5; }
  10%  { --beam-x-${e}: 0.15;  --beam-w-${e}: 0.8; }
  20%  { --beam-x-${e}: 0.25;  --beam-w-${e}: 1.1; }
  30%  { --beam-x-${e}: 0.35;  --beam-w-${e}: 1.3; }
  40%  { --beam-x-${e}: 0.44;  --beam-w-${e}: 1.45; }
  50%  { --beam-x-${e}: 0.5;   --beam-w-${e}: 1.5; }
  60%  { --beam-x-${e}: 0.56;  --beam-w-${e}: 1.45; }
  70%  { --beam-x-${e}: 0.65;  --beam-w-${e}: 1.3; }
  80%  { --beam-x-${e}: 0.75;  --beam-w-${e}: 1.1; }
  90%  { --beam-x-${e}: 0.85;  --beam-w-${e}: 0.8; }
  100% { --beam-x-${e}: 0.94;  --beam-w-${e}: 0.5; }
}

@keyframes beam-edge-fade-${e} {
  0%    { --beam-edge-${e}: 0; }
  12.5% { --beam-edge-${e}: 0; }
  32.5% { --beam-edge-${e}: 1; }
  67.5% { --beam-edge-${e}: 1; }
  87.5% { --beam-edge-${e}: 0; }
  100%  { --beam-edge-${e}: 0; }
}

@keyframes beam-breathe-${e} {
  0%, 100% { --beam-h-${e}: 0.8; }
  25%      { --beam-h-${e}: 1.25; }
  55%      { --beam-h-${e}: 0.85; }
  80%      { --beam-h-${e}: 1.3; }
}

@keyframes beam-spike-${e} {
  0%   { --beam-spike-${e}: 0.8; }
  25%  { --beam-spike-${e}: 1.3; }
  50%  { --beam-spike-${e}: 0.9; }
  75%  { --beam-spike-${e}: 1.4; }
  100% { --beam-spike-${e}: 0.8; }
}

@keyframes beam-spike2-${e} {
  0%   { --beam-spike2-${e}: 1.2; }
  25%  { --beam-spike2-${e}: 0.7; }
  50%  { --beam-spike2-${e}: 1.4; }
  75%  { --beam-spike2-${e}: 0.8; }
  100% { --beam-spike2-${e}: 1.2; }
}

@keyframes beam-fade-in-${e} {
  to { --beam-opacity-${e}: 1; }
}

@keyframes beam-fade-out-${e} {
  from { --beam-opacity-${e}: 1; }
  to { --beam-opacity-${e}: 0; }
}
${h}
${ue(e)}
`}const je=new Set;let ie=null,We=0;const st=1e3/30-2,it=Math.PI*2;function Re(r){return(1-Math.cos(it*r))/2}function Ue(r){if(ie=requestAnimationFrame(Ue),r-We<st)return;We=r;const e=r/1e3;je.forEach(({el:a,config:o})=>{for(const s of o.oscillators){const i=(e-s.delay)/s.period,l=s.a+(s.b-s.a)*Re(i);a.style.setProperty(s.prop,s.unit==="px"?`${l.toFixed(2)}px`:l.toFixed(4))}if(o.hue){const{prop:s,range:i,period:l,continuous:c}=o.hue,m=c?e/l%1*i:-i+2*i*Re(e/l);a.style.setProperty(s,`${m.toFixed(2)}deg`)}})}function nt(){ie==null&&(We=0,ie=requestAnimationFrame(Ue))}function lt(){je.size===0&&ie!=null&&(cancelAnimationFrame(ie),ie=null)}function ct(r,e){const a={el:r,config:e};return je.add(a),nt(),()=>{je.delete(a),lt()}}function dt(){const[r,e]=p.useState(()=>typeof window>"u"||window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");return p.useEffect(()=>{if(typeof window>"u")return;const a=window.matchMedia("(prefers-color-scheme: dark)"),o=s=>{e(s.matches?"dark":"light")};return a.addEventListener("change",o),()=>a.removeEventListener("change",o)},[]),r}function pt(r,e){return r==="auto"?e:r}const Xe=p.forwardRef(function({children:r,size:e="md",colorVariant:a="colorful",theme:o="dark",staticColors:s=!1,duration:i,active:l=!0,borderRadius:c,brightness:m,saturation:x,hueRange:d=30,strength:n=1,className:g,style:u,onActivate:b,onDeactivate:v,onAnimationEnd:k,...H},f){const y=p.useId().replace(/:/g,"-"),w=dt(),N=p.useRef(null),[h,z]=p.useState(l),[j,S]=p.useState(!1),[W,X]=p.useState(!0),[q,te]=p.useState(null),[R,L]=p.useState({x:1,y:1});p.useEffect(()=>{if(c!=null)return;const Y=N.current;if(!Y)return;const F=()=>{const U=Y.firstElementChild;if(!U)return;const re=getComputedStyle(U),V=parseFloat(re.borderTopLeftRadius);!isNaN(V)&&V>0&&te(V)};F();const D=new MutationObserver(F);return D.observe(Y,{childList:!0,subtree:!1}),()=>D.disconnect()},[c,r]),p.useEffect(()=>{l&&!h&&!j?z(!0):!l&&h&&!j&&S(!0)},[l,h,j]),p.useEffect(()=>{const Y=N.current;if(!Y||typeof IntersectionObserver>"u")return;const F=new IntersectionObserver(D=>{for(const U of D)X(U.isIntersecting)},{rootMargin:"256px"});return F.observe(Y),()=>F.disconnect()},[]),p.useEffect(()=>{if(e!=="pulse-outside"){L({x:1,y:1});return}const Y=N.current;if(!Y)return;const F=350,D=140,U=.35,re=4,V=B=>Math.max(U,Math.min(re,B)),ge=()=>{const B=Y.firstElementChild;if(!B)return;const oe=B.getBoundingClientRect();if(!oe.width||!oe.height)return;const xe=+V(oe.width/F).toFixed(3),he=+V(oe.height/D).toFixed(3);L(Q=>Q.x===xe&&Q.y===he?Q:{x:xe,y:he})};if(ge(),typeof ResizeObserver>"u")return;const me=Y.firstElementChild;if(!me)return;const fe=new ResizeObserver(ge);return fe.observe(me),()=>fe.disconnect()},[e,r]);const ne=p.useCallback(Y=>{const F=Y.animationName;F.includes("fade-out")?(z(!1),S(!1),v?.()):F.includes("fade-in")&&b?.(),k?.(Y)},[b,v,k]),E=pt(o,w),O=Ma[e][E],G=Sa[e],I=e==="pulse-inner"||e==="pulse-outside",J=c??q??G.borderRadius,T=i??(e==="line"?3.1:I?2.3:1.96),_=x??O.saturation,le=m??O.brightness??1.3,P=e==="line"?Math.min(d,13):d,K=a==="mono"?!0:s,Ne=p.useMemo(()=>Za({id:y,borderRadius:J,borderWidth:G.borderWidth,duration:T,strokeOpacity:O.strokeOpacity,innerOpacity:O.innerOpacity,bloomOpacity:O.bloomOpacity,innerShadow:O.innerShadow,size:e,colorVariant:a,staticColors:K,brightness:le,saturation:_,hueRange:P,theme:E,hairlineOpacity:O.hairlineOpacity}),[y,J,G.borderWidth,T,O.strokeOpacity,O.innerOpacity,O.bloomOpacity,O.innerShadow,O.hairlineOpacity,e,a,K,le,_,P,E]),ce=p.useMemo(()=>I?Qa(e,E,T,P,K,y):null,[I,e,E,T,P,K,y]);p.useEffect(()=>{var Y;if(!ce||!(h||j)||!W)return;const F=N.current;if(F&&!(typeof window<"u"&&(Y=window.matchMedia)!=null&&Y.call(window,"(prefers-reduced-motion: reduce)").matches))return ct(F,ce)},[ce,h,j,W]);const de=p.useCallback(Y=>{N.current=Y,typeof f=="function"?f(Y):f&&(f.current=Y)},[f]),pe={...u??{},"--beam-strength":Math.max(0,Math.min(1,n)),...e==="pulse-outside"?{"--pulse-glow-sx":R.x,"--pulse-glow-sy":R.y}:{}};return t.jsxs(t.Fragment,{children:[t.jsx("style",{children:Ne}),t.jsxs("div",{...H,ref:de,"data-beam":y,"data-active":h&&!j?"":void 0,"data-fading":j?"":void 0,"data-paused":h&&!j&&!W?"":void 0,className:g,style:pe,onAnimationEnd:ne,children:[r,t.jsx("div",{"data-beam-bloom":!0})]})]})});function bt({className:r,...e}){return t.jsxs("svg",{viewBox:"0 0 20 20",fill:"none",stroke:"currentColor",strokeWidth:"1.7",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",className:r,...e,children:[t.jsx("path",{d:"M7 4H4.75A1.75 1.75 0 0 0 3 5.75v8.5A1.75 1.75 0 0 0 4.75 16H7"}),t.jsx("path",{d:"M8.5 6.5h5M8.5 10h7M8.5 13.5h3.5"}),t.jsx("path",{d:"m13.5 4 2-1m0 14 2-1"})]})}function ut({closedTabs:r,onExpire:e}){return t.jsxs("div",{className:"closed-toast relative mt-2 overflow-hidden rounded-md border border-border bg-muted/20",children:[t.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"max-h-36 space-y-1.5 overflow-y-auto p-2 pb-2.5",children:r.map((a,o)=>t.jsxs("li",{className:"flex min-w-0 items-center gap-2",children:[t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:a.title||"Untitled tab"}),t.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:a.url})]}),a.keptTabId!==void 0&&t.jsx("button",{type:"button",onClick:()=>chrome.runtime.sendMessage({type:"focusTab",tabId:a.keptTabId}),className:"shrink-0 rounded border border-border px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"View existing"})]},`${a.url}-${o}`))}),t.jsx("div",{"data-testid":"closed-toast-timer",className:"closed-toast-timer absolute inset-x-0 bottom-0 h-0.5 origin-left bg-primary/60",onAnimationEnd:e})]})}function gt({windowId:r,disabled:e,acknowledged:a,onAcknowledge:o,onRunningChange:s,onDraftChange:i,onMutation:l,onQuotaExhausted:c}){const[m,x]=p.useState(""),[d,n]=p.useState(!1),[g,u]=p.useState(!1),[b,v]=p.useState(null),k=Be(Ge),H=p.useRef(!1),f=p.useRef(s);f.current=s;const y=p.useRef(i);y.current=i,p.useEffect(()=>{y.current?.(!!m.trim())},[m]),p.useEffect(()=>()=>y.current?.(!1),[]),p.useEffect(()=>()=>{H.current&&f.current(!1)},[]);const w=async()=>{const h=m.trim();if(!(!h||H.current||e)){if(!a&&!g){u(!0),v(null);return}g&&(u(!1),await o()),H.current=!0,n(!0),s(!0),v(null);try{let z=await chrome.permissions.contains({origins:["<all_urls>"]});if(!z)try{z=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{z=!1}const j=await chrome.runtime.sendMessage({type:"command",query:h,windowId:r,hasContentPermission:z});if(j?.quota&&j.error){c?.(j.error),v(null);return}v(j??{error:"Something went wrong."}),["create_group","add_to_group","update_group","ungroup","remove_duplicates","merge_groups"].includes(j?.action||"")&&!j.error&&(x(""),await l?.().catch(()=>{}))}catch{v({error:"Command was interrupted. Try again."})}finally{H.current=!1,n(!1),s(!1)}}},N=async h=>{await chrome.runtime.sendMessage({type:"focusTab",tabId:h})};return t.jsxs("section",{className:"mt-4","aria-label":"Command bar",children:[t.jsx(Xe,{size:"line",colorVariant:"ocean",theme:"dark",strength:.35,active:d,className:"w-full focus-within:ring-2 focus-within:ring-ring/30","data-testid":"command-beam",children:t.jsxs("div",{className:"flex items-center gap-2 rounded-lg border border-border bg-muted/20 px-2.5 focus-within:border-ring",children:[t.jsx("input",{value:m,onChange:h=>x(h.target.value),onKeyDown:h=>{h.key==="Enter"&&w()},disabled:e||d,placeholder:k,"aria-label":"Command",className:"h-9 min-w-0 flex-1 bg-transparent text-xs outline-none placeholder:text-muted-foreground disabled:opacity-50"}),d?t.jsx(be,{className:"size-3.5 shrink-0 animate-spin text-muted-foreground"}):t.jsx("button",{type:"button",onClick:w,disabled:e||!m.trim(),title:"Send","aria-label":"Send",className:"flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&:not(:disabled)]:text-primary",children:t.jsx($a,{className:"size-3.5"})})]})}),g&&t.jsx("p",{className:"mt-2 text-xs leading-snug text-muted-foreground","aria-live":"polite",children:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Press Enter again to continue."}),b&&t.jsxs("div",{className:`mt-2 flex items-start gap-2 text-xs ${b.error?"text-destructive":"text-muted-foreground"}`,"aria-live":"polite",children:[t.jsx("p",{className:"min-w-0 flex-1 leading-snug",children:b.error?b.error:b.action==="open_tab"?`Jumped to “${b.tabTitle}”`:b.action==="create_group"?`Created “${b.groupName}” with ${b.tabCount} tab${b.tabCount===1?"":"s"}`:b.action==="add_to_group"?`Moved ${b.tabCount} tab${b.tabCount===1?"":"s"} into “${b.groupName}”`:b.action==="update_group"?b.previousName&&b.previousName!==b.groupName?`Renamed “${b.previousName}” to “${b.groupName}”`:`Updated “${b.groupName}”`:b.action==="ungroup"?`Ungrouped ${b.tabCount} tab${b.tabCount===1?"":"s"} from ${b.groupCount} group${b.groupCount===1?"":"s"}`:b.action==="remove_duplicates"?b.closedCount?`Closed ${b.closedCount} duplicate tab${b.closedCount===1?"":"s"}`:"No duplicate tabs found":b.action==="merge_groups"?`Merged ${b.groupCount} groups into “${b.groupName}” · ${b.tabCount} tabs`:b.reply}),b.action==="answer"&&typeof b.tabId=="number"&&t.jsxs("button",{onClick:()=>N(b.tabId),className:"flex shrink-0 items-center gap-1 rounded border border-border px-1.5 py-0.5 text-[11px] text-foreground transition-colors hover:bg-muted",children:["Go to tab ",t.jsx(oa,{className:"size-3"})]})]}),b?.action==="remove_duplicates"&&b.closedTabs&&b.closedTabs.length>0&&t.jsx("ul",{"aria-label":"Closed duplicate tabs",className:"mt-2 max-h-32 space-y-1.5 overflow-y-auto rounded-md border border-border bg-muted/20 p-2 text-xs",children:b.closedTabs.map((h,z)=>t.jsxs("li",{className:"min-w-0",children:[t.jsx("p",{className:"break-words font-medium leading-snug text-foreground",children:h.title||"Untitled tab"}),t.jsx("p",{className:"break-all leading-snug text-muted-foreground",children:h.url})]},`${h.url}-${z}`))})]})}const _e={collecting:{label:"Reading titles",progress:18},classifying:{label:"Finding themes",progress:48},reading:{label:"Reading ambiguous pages",progress:68},applying:{label:"Creating tab groups",progress:88}};function mt({job:r}){const e=_e[r?.stage||"collecting"]??_e.collecting,a=r?.tabCount||0;return t.jsxs("section",{className:"mt-6","aria-live":"polite","aria-label":`${e.label}. Organizing tabs.`,children:[t.jsx("h1",{className:"text-xl font-semibold tracking-tight",children:a?`Organizing ${a} tabs`:"Organizing tabs"}),t.jsx("p",{className:"mt-1 text-sm text-muted-foreground",children:e.label}),t.jsxs("div",{className:"tab-rail mt-6","aria-hidden":"true",children:[t.jsx("div",{className:"tab-rail-line"}),[0,1,2,3].map(o=>t.jsx("span",{className:"tab-rail-item",style:{animationDelay:`${o*-.58}s`},children:t.jsx("span",{className:"tab-rail-notch"})},o)),t.jsx("span",{className:"tab-rail-arrow",children:"→"}),t.jsxs("span",{className:"tab-rail-groups",children:[t.jsx("span",{}),t.jsx("span",{})]})]}),t.jsxs("div",{className:"mt-5 flex items-center justify-between gap-3 text-xs",children:[t.jsx("span",{className:"text-muted-foreground",children:e.label}),t.jsxs("span",{className:"tabular-nums text-foreground",children:[e.progress,"%"]})]}),t.jsx("div",{className:"mt-2 h-0.5 overflow-hidden rounded-full bg-muted",children:t.jsx("div",{className:"organize-progress h-full origin-left bg-primary transition-transform duration-500 [transition-timing-function:var(--ease-out-strong)]",style:{transform:`scaleX(${e.progress/100})`}})}),t.jsxs("div",{className:"mt-6 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground",children:[t.jsx(wa,{className:"size-4 text-primary"}),t.jsx("span",{children:"Safe to close — progress continues"})]})]})}function ft({onDismiss:r}){return t.jsx("section",{className:"mt-4 rounded-lg border border-primary/35 bg-primary/10 p-3","aria-live":"polite",children:t.jsxs("div",{className:"flex items-start gap-2.5",children:[t.jsx(ma,{className:"mt-0.5 size-4 shrink-0 text-primary"}),t.jsxs("div",{className:"min-w-0 flex-1",children:[t.jsx("p",{className:"text-sm font-medium leading-snug",children:"Pin Shelve to your toolbar"}),t.jsxs("p",{className:"mt-1 text-xs leading-snug text-muted-foreground",children:["Click the ",t.jsx(xa,{className:"inline size-3.5 align-[-2px]","aria-label":"puzzle-piece"})," icon next to the address bar, then hit the pin beside Shelve so it’s always one click away."]}),t.jsx("div",{className:"mt-2",children:t.jsx(He,{onClick:r,variant:"ghost",size:"sm",children:"Got it"})})]})]})})}function ze({label:r,title:e,icon:a,onClick:o,disabled:s}){return t.jsxs("button",{title:e??r,"aria-label":e??r,onClick:o,disabled:s,className:"flex h-11 flex-col items-center justify-center gap-0.5 rounded-lg border border-border bg-transparent text-[10px] text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:bg-muted hover:text-foreground active:scale-[0.97] focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:[a,t.jsx("span",{className:"px-1 text-center leading-tight",children:r})]})}function xt({groups:r,selected:e,applying:a,onSelectedChange:o,onApply:s,onDiscard:i}){return t.jsxs("section",{className:"mt-5",children:[t.jsxs("div",{className:"mb-3",children:[t.jsx("h1",{className:"text-base font-semibold tracking-tight",children:"Review groups"}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:"Choose which suggestions to create."})]}),t.jsx("div",{className:"flex max-h-72 flex-col gap-1 overflow-y-auto",children:r.map((l,c)=>t.jsxs("label",{className:"review-item flex cursor-pointer items-start gap-2.5 rounded-md p-2 hover:bg-accent",style:{animationDelay:`${c*40}ms`},children:[t.jsx(Ie,{className:"mt-0.5",checked:e.has(c),disabled:a,onCheckedChange:m=>{const x=new Set(e);m?x.add(c):x.delete(c),o(x)}}),t.jsxs("span",{className:"min-w-0",children:[t.jsxs("span",{className:"block text-sm font-medium leading-tight",children:[l.name,t.jsx("span",{className:"ml-1.5 font-normal text-muted-foreground",children:l.tabIds.length})]}),t.jsx("span",{className:"block truncate text-xs text-muted-foreground",children:l.tabTitles.join(" · ")})]})]},`${l.existingGroupId??"new"}-${c}`))}),t.jsxs("div",{className:"mt-3 flex gap-2",children:[t.jsx(He,{onClick:i,disabled:a,variant:"outline",className:"flex-1",size:"sm",children:"Discard"}),t.jsxs(He,{onClick:s,disabled:!e.size||a,className:"flex-1",size:"sm",children:[a?t.jsx(be,{className:"size-4 animate-spin"}):null,a?"Applying…":"Apply selected"]})]})]})}const we={grey:"bg-zinc-400",blue:"bg-blue-500",red:"bg-red-500",yellow:"bg-yellow-400",green:"bg-green-500",pink:"bg-pink-500",purple:"bg-purple-500",cyan:"bg-cyan-500",orange:"bg-orange-500"};function Ae(r){const e=r.loadedCount??r.tabCount;return e>=7?{label:"high",className:"text-orange-400"}:e>=3?{label:"med",className:"text-yellow-500"}:{label:"low",className:"text-muted-foreground"}}function ht(r){const e=Math.max(0,Math.round((Date.now()-r)/6e4));if(e<1)return"just now";if(e<60)return`${e}m ago`;const a=Math.round(e/60);return a<24?`${a}h ago`:`${Math.round(a/24)}d ago`}function $t({groups:r,stashes:e,busyId:a,disabled:o,onStash:s,onResume:i,onDelete:l}){const[c,m]=p.useState(!1),[x,d]=p.useState(null);return!r.length&&!e.length?null:t.jsxs(t.Fragment,{children:[e.length>0&&t.jsxs("section",{className:"mt-4","aria-label":"Shelved projects",children:[t.jsx("h2",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:"Shelved"}),t.jsx("div",{className:"mt-1.5 flex flex-col gap-1",children:e.map(n=>{const g=n.resumeStatus==="resuming",u=o||g;return t.jsxs("div",{className:"rounded-md border border-border/70 px-2 py-1.5",children:[t.jsxs("div",{className:"flex items-center gap-2",children:[t.jsx("span",{className:`size-2 shrink-0 rounded-full ${we[n.color]??we.grey}`}),t.jsx("span",{className:"min-w-0 flex-1 truncate text-xs font-medium",children:n.name}),x===n.id?t.jsxs(t.Fragment,{children:[t.jsx("span",{className:"text-[11px] text-destructive",children:"Delete this shelved project?"}),t.jsx("button",{type:"button",onClick:()=>d(null),className:"rounded px-1.5 py-0.5 text-[11px] text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Cancel"}),t.jsx("button",{type:"button",disabled:u,onClick:async()=>{await l(n.id),d(null)},className:"rounded bg-destructive/10 px-1.5 py-0.5 text-[11px] font-medium text-destructive outline-none transition-colors hover:bg-destructive/20 focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:"Delete"})]}):t.jsxs(t.Fragment,{children:[t.jsxs("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:[n.tabCount," · ",ht(n.createdAt)]}),t.jsx(Ce,{title:"Resume",disabled:u,onClick:()=>i(n.id),children:a===n.id||g?t.jsx(be,{className:"size-3.5 animate-spin"}):t.jsx(ea,{className:"size-3.5"})}),t.jsx(Ce,{title:"Delete shelved project",disabled:u,onClick:()=>d(n.id),children:t.jsx(Wa,{className:"size-3.5"})})]})]}),g?t.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Resuming…"}):n.briefStatus==="pending"?t.jsx("p",{className:"mt-1 pl-4 text-[11px] italic text-muted-foreground",children:"Writing where-you-left-off brief…"}):n.brief?t.jsx("p",{title:n.brief,className:"mt-1 line-clamp-2 pl-4 text-[11px] leading-snug text-muted-foreground",children:n.brief}):null]},n.id)})})]}),r.length>0&&t.jsxs("section",{className:"mt-4","aria-label":"Tab groups in this window",children:[t.jsxs("button",{type:"button",onClick:()=>m(n=>!n),"aria-expanded":c,"aria-controls":"groups-list",className:"flex h-7 w-full items-center justify-between rounded-md px-1.5 outline-none transition-colors hover:bg-muted/50 focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"text-[11px] font-medium uppercase tracking-wide text-muted-foreground",children:["Groups · ",r.length]}),t.jsx(Je,{className:`size-3.5 text-muted-foreground transition-transform duration-200 [transition-timing-function:var(--ease-out-strong)] ${c?"rotate-180":""}`})]}),c&&t.jsx("div",{id:"groups-list",className:"mt-1 flex flex-col",children:r.map(n=>t.jsxs("div",{className:"flex h-8 items-center gap-2 rounded-md px-1.5 hover:bg-muted/50",children:[t.jsx("span",{className:`size-2 shrink-0 rounded-full ${we[n.color]??we.grey}`}),t.jsx("span",{className:"min-w-0 flex-1 truncate text-xs",children:n.title}),t.jsx("span",{title:`Approximate memory use: ${n.loadedCount??n.tabCount} of ${n.tabCount} tabs loaded`,className:`text-[10px] font-medium uppercase tracking-wide ${Ae(n).className}`,children:Ae(n).label}),t.jsx("span",{className:"text-[11px] tabular-nums text-muted-foreground",children:n.tabCount}),t.jsx(Ce,{title:`Shelve “${n.title}”`,disabled:o,onClick:()=>s(n.id),children:a===n.id?t.jsx(be,{className:"size-3.5 animate-spin"}):t.jsx(ta,{className:"size-3.5"})})]},n.id))})]})]})}function Ce({title:r,disabled:e,onClick:a,children:o}){return t.jsx("button",{title:r,"aria-label":r,disabled:e,onClick:a,className:"flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground outline-none transition-colors hover:bg-muted hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",children:o})}const yt=[100,250,500,1e3,2500,5e3,1e4,25e3];function vt({refreshToken:r}){const[e,a]=p.useState(null);p.useEffect(()=>{let l=!1;return chrome.runtime.sendMessage({type:"getStats"}).then(c=>{!l&&c&&!c.error&&c.totals&&a(c)}).catch(()=>{}),()=>{l=!0}},[r]);const o=e?.totals?.tabsGrouped??0;if(!e||o<1)return null;const s=yt.find(l=>l>o),i=[`${o.toLocaleString()} tabs sorted`,(e.totals.stashes??0)>0?`${(e.totals.stashes??0).toLocaleString()} shelved`:null,e.streak>1?`${e.streak}-day streak`:null,e.weekTabs>0?`${e.weekTabs.toLocaleString()} this week`:null].filter(Boolean).join(" · ");return t.jsx("p",{"aria-label":"Your stats",title:s?`${(s-o).toLocaleString()} tabs to ${s.toLocaleString()}`:void 0,className:"mt-2 text-[11px] leading-snug text-muted-foreground tabular-nums",children:i})}function zt({dailyLimit:r,onDismiss:e}){const[a,o]=p.useState(null);return p.useEffect(()=>{let s=!1;return chrome.runtime.sendMessage({type:"getUpgradeInfo"}).then(i=>{s||o({paymentsEnabled:i?.paymentsEnabled===!0,checkoutUrl:i?.checkoutUrl||""})}).catch(()=>{s||o({paymentsEnabled:!1,checkoutUrl:""})}),()=>{s=!0}},[]),t.jsxs("section",{className:"mt-4 flex flex-col gap-3","aria-labelledby":"upgrade-heading",children:[t.jsxs("div",{children:[t.jsxs("h2",{id:"upgrade-heading",className:"text-sm font-semibold tracking-tight",children:["You're out of free actions",r?" for today":""]}),t.jsx("p",{className:"mt-1 text-xs text-muted-foreground",children:r?"They reset tomorrow — or keep going right now:":"Keep going with one of these:"})]}),t.jsxs("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex w-full flex-col items-start gap-1 rounded-lg border border-primary/50 bg-muted/40 p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary hover:bg-muted active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[t.jsx(da,{className:"size-4 text-primary"}),"Add your own API key — free"]}),t.jsx("span",{className:"text-xs text-muted-foreground",children:"Unlimited actions with your OpenAI, Anthropic, Gemini, or Ollama key. Shelve itself stays free."})]}),a?.paymentsEnabled&&a.checkoutUrl&&t.jsxs("a",{href:a.checkoutUrl,target:"_blank",rel:"noreferrer",className:"flex w-full flex-col items-start gap-1 rounded-lg border border-border p-3 text-left outline-none transition-[border-color,background-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted/50 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsxs("span",{className:"flex items-center gap-1.5 text-sm font-medium text-foreground",children:[t.jsx(Ya,{className:"size-4"}),"Shelve Hosted — $5/mo"]}),t.jsx("span",{className:"text-xs text-muted-foreground",children:"No key to manage; more actions on the hosted model."})]}),t.jsx("button",{onClick:e,className:"self-center rounded-md px-2 py-1 text-xs text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring",children:"Not now"})]})}function wt({windowId:r,running:e,setRunning:a,setStatus:o,setGroups:s,setSelected:i,setReviewMinSize:l,setOrganizeClosedTabs:c,refreshUndo:m,refreshPanels:x,onQuotaExhausted:d}){const[n,g]=p.useState(null),u=p.useRef(!1),b=p.useRef(null),v=p.useCallback(async f=>{!r||!f||(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:r,jobId:f}),g(null))},[r]),k=p.useCallback(async(f,y)=>{if(y&&b.current===y)return;y&&(b.current=y),a(null),await m();const w=Array.isArray(f?.closedTabs)?f.closedTabs:[];if(!f||f.error){c([]),o({text:f?.error??"Something went wrong.",error:!0,closedTabs:w}),f?.quota&&d?.(f.error??""),await v(y);return}if(f.review&&f.groups){c(w),s(f.groups),i(new Set(f.groups.map((N,h)=>h))),l(f.minSize||1),o(null);return}c([]),o({text:`${f.groupCount} group${f.groupCount===1?"":"s"} · ${f.tabCount} tabs sorted`,closedTabs:w}),await v(y),await x()},[v,m,x,d,s,c,l,a,i,o]),H=e==="organize"||n?.status==="running";return p.useEffect(()=>{if(!r)return;let f=!1,y;const w=async()=>{let N=!1;try{const h=await chrome.runtime.sendMessage({type:"organizeStatus",windowId:r});if(f)return;const z=h?.job;z?.status==="running"?(g(z),a("organize"),o(null),N=!0):z&&!u.current&&b.current!==z.id&&(g(z),await k(z.result||{error:z.error},z.id))}catch{}!f&&N&&(y=window.setTimeout(w,450))};return w(),()=>{f=!0,y&&window.clearTimeout(y)}},[k,r,H,a,o]),{organizeJob:n,setOrganizeJob:g,consumeJob:v,handleOrganizeResult:k,ownsOrganizeRequest:u,handledJobId:b,organizeActive:H}}function kt({windowId:r,setRunning:e,setStatus:a,refreshUndo:o,refreshPanels:s,refreshWindowCount:i}){return{ungroup:async()=>{e("ungroup"),a(null);const d=await chrome.runtime.sendMessage({type:"ungroupAll",windowId:r});e(null),await Promise.all([o(),s()]),a(d?.error?{text:d.error,error:!0}:{text:`${d.tabCount} tab${d.tabCount===1?"":"s"} ungrouped`})},cleanDuplicates:async()=>{e("duplicates"),a(null);const d=await chrome.runtime.sendMessage({type:"cleanDuplicates",windowId:r});e(null),await Promise.all([o(),s()]),a(d?.error?{text:d.error,error:!0}:{text:d.closedCount?`Closed ${d.closedCount} duplicate tab${d.closedCount===1?"":"s"}`:"No duplicate tabs found",closedTabs:Array.isArray(d.closedTabs)?d.closedTabs:[]})},merge:async()=>{e("merge"),a(null);const d=await chrome.runtime.sendMessage({type:"mergeWindows",windowId:r});if(e(null),d?.error){a({text:d.error,error:!0});return}await Promise.all([i(),s()]),a({text:`Merged ${d.windows} window${d.windows===1?"":"s"} · ${d.tabs} tabs`})},undo:async()=>{e("undo"),a(null);const d=await chrome.runtime.sendMessage({type:"undo",windowId:r});if(e(null),await Promise.all([o(),s()]),d?.error){a({text:d.error,error:!0});return}a({text:d?.skippedCount?`Restored the available layout — ${d.skippedCount} tab${d.skippedCount===1?"":"s"} closed since couldn't be brought back`:"Previous tab layout restored"})}}}function jt({windowId:r,acknowledged:e,acknowledgeNotice:a,setStatus:o,refreshPanels:s}){const[i,l]=p.useState(null),[c,m]=p.useState(null);return{stashBusy:i,stashGroup:async g=>{if(!e){if(c!==g){m(g),o({text:"Stash briefs send tab titles & URLs (and, if allowed, page snippets) to your configured AI provider. Click again to continue."});return}m(null),await a()}l(g),o(null);let u;try{u=await chrome.runtime.sendMessage({type:"stashGroup",windowId:r,groupId:g})}finally{l(null)}await s(),o(u?.error?{text:u.error,error:!0}:{text:`Stashed “${u.stash?.name}” · ${u.stash?.tabCount} tabs`})},resumeStash:async g=>{l(g),o(null);let u;try{u=await chrome.runtime.sendMessage({type:"resumeStash",stashId:g,windowId:r})}finally{l(null)}await s(),o(u?.error?{text:u.error,error:!0}:{text:`Restored ${u.tabCount} tab${u.tabCount===1?"":"s"}`})},deleteStash:async g=>{const u=await chrome.runtime.sendMessage({type:"deleteStash",stashId:g});await s(),o(u?.error?{text:u.error,error:!0}:{text:"Stash deleted"})}}}const qe=typeof window<"u"&&new URLSearchParams(window.location.search).has("overlay"),Ee=typeof window<"u"&&window.self!==window.top;function Nt(){const[r,e]=p.useState(null),[a,o]=p.useState(null),[s,i]=p.useState([]),[l,c]=p.useState(new Set),[m,x]=p.useState(1),[d,n]=p.useState(),[g,u]=p.useState(1),[b,v]=p.useState(!1),[k,H]=p.useState(!1),[f,y]=p.useState(null),[w,N]=p.useState(!1),[h,z]=p.useState([]),[j,S]=p.useState([]),[W,X]=p.useState([]),[q,te]=p.useState(Ee?null:!0),[R,L]=p.useState(null),[ne,E]=p.useState(!1),[O,G]=p.useState(!1),[I]=p.useState(()=>({animationDuration:`${(7+Math.random()*4).toFixed(2)}s`,animationDelay:`-${(Math.random()*6).toFixed(2)}s`}));p.useEffect(()=>{if(!Ee)return;let $=!1;return chrome.runtime.sendMessage({type:"overlayHandshake"}).then(C=>{$||te(C?.allowed===!0)}).catch(()=>{$||te(!1)}),()=>{$=!0}},[]);const J=p.useCallback(async($=d)=>{if(!$)return;const C=await chrome.runtime.sendMessage({type:"hasUndo",windowId:$});v(!!C?.hasUndo)},[d]),T=p.useCallback(async()=>{const $=await chrome.runtime.sendMessage({type:"windowCount"});$?.count&&u($.count)},[]);p.useEffect(()=>{const $=()=>{T().catch(()=>{})};return chrome.windows.onCreated?.addListener($),chrome.windows.onRemoved.addListener($),()=>{chrome.windows.onCreated?.removeListener($),chrome.windows.onRemoved.removeListener($)}},[T]);const _=p.useCallback(async()=>{if(!d)return;const[$,C]=await Promise.all([chrome.runtime.sendMessage({type:"listGroups",windowId:d}),chrome.runtime.sendMessage({type:"listStashes",windowId:d})]);$?.groups&&z($.groups),C?.stashes&&S(C.stashes)},[d]);p.useEffect(()=>{_();const $=(C,A)=>{A==="local"&&C.stashes&&_()};return chrome.storage.onChanged.addListener($),()=>chrome.storage.onChanged.removeListener($)},[_]);const le=p.useCallback($=>{L({dailyLimit:/reset tomorrow/i.test($)}),o(C=>C?.closedTabs?.length?{text:"",closedTabs:C.closedTabs}:null)},[]),{organizeJob:P,setOrganizeJob:K,consumeJob:Ne,handleOrganizeResult:ce,ownsOrganizeRequest:de,handledJobId:pe,organizeActive:Y}=wt({windowId:d,running:r,setRunning:e,setStatus:o,setGroups:i,setSelected:c,setReviewMinSize:x,setOrganizeClosedTabs:X,refreshUndo:J,refreshPanels:_,onQuotaExhausted:le});p.useEffect(()=>{(async()=>{const $=await chrome.windows.getCurrent(),[C,A,ye]=await Promise.all([chrome.runtime.sendMessage({type:"hasUndo",windowId:$.id}),chrome.runtime.sendMessage({type:"windowCount"}),chrome.storage.local.get({dataNoticeAck:!1,pinPromptDismissed:!1})]);try{const Ve=await chrome.action.getUserSettings();H(!Ve.isOnToolbar&&!ye.pinPromptDismissed)}catch{}n($.id),A?.count&&u(A.count),v(!!C?.hasUndo),y(!!ye.dataNoticeAck)})()},[]);const F=async()=>{const $=!f;$&&(y(!0),await chrome.storage.local.set({dataNoticeAck:!0})),e("organize"),o($?{text:"Sends tab titles & URLs (and, if allowed, page snippets) to your configured AI provider."}:null),L(null),X([]),pe.current=null,de.current=!0;let C=await chrome.permissions.contains({origins:["<all_urls>"]});if(!C)try{C=await chrome.permissions.request({permissions:["scripting"],origins:["<all_urls>"]})}catch{C=!1}try{const A=await chrome.runtime.sendMessage({type:"organize",hasContentPermission:C,windowId:d});if(de.current=!1,A?.running&&A.job){K(A.job);return}await ce(A,A?.jobId)}catch{de.current=!1,e(null),o({text:"Organizing was interrupted. Try again.",error:!0})}},D=async()=>{const $=P?.id??pe.current??void 0;try{if(d&&$&&!(await chrome.runtime.sendMessage({type:"consumeOrganizeResult",windowId:d,jobId:$}))?.cleared){o({text:"Couldn't discard the suggestions — try again.",error:!0});return}i([]),c(new Set),K(null),o({text:W.length?`Suggestions discarded · ${W.length} duplicate tab${W.length===1?"":"s"} closed`:"Suggestions discarded.",closedTabs:W}),X([])}catch{o({text:"Couldn't discard the suggestions — try again.",error:!0})}},U=async()=>{const $=s.filter((A,ye)=>l.has(ye));if(!$.length)return;e("apply");const C=await chrome.runtime.sendMessage({type:"applyPlan",groups:$,minSize:m,windowId:d});e(null),i([]),await Promise.all([J(),_()]),await Ne(P?.id??pe.current??void 0),o(C?.error?{text:C.error,error:!0,closedTabs:W}:{text:`${C.groupCount} group${C.groupCount===1?"":"s"} created`,closedTabs:W}),X([])},re=p.useCallback(async()=>{y(!0),await chrome.storage.local.set({dataNoticeAck:!0})},[]),{ungroup:V,cleanDuplicates:ge,merge:me,undo:fe}=kt({windowId:d,setRunning:e,setStatus:o,refreshUndo:J,refreshPanels:_,refreshWindowCount:T}),{stashBusy:B,stashGroup:oe,resumeStash:xe,deleteStash:he}=jt({windowId:d,acknowledged:f,acknowledgeNotice:re,setStatus:o,refreshPanels:_}),Q=s.length>0,se=Y,Z=!!r||Q||B!==null||w||f===null||d===void 0,$e=($,C)=>r===$?t.jsx(be,{className:"size-4 animate-spin"}):C,Me=O||!!r||se||w||Q||B!==null;return p.useEffect(()=>{if(!qe)return;const $=()=>{document.visibilityState!=="hidden"||Me||window.parent.postMessage({__shelveOverlay:!0,close:!0},"*")};return document.addEventListener("visibilitychange",$),()=>document.removeEventListener("visibilitychange",$)},[Me]),q===null?null:q===!1?t.jsx("main",{className:"popup-shell w-[340px] p-4",children:t.jsx("p",{className:"text-xs text-muted-foreground",children:"Open Shelve from the toolbar icon to use it here."})}):t.jsx(Xe,{size:"md",colorVariant:"ocean",theme:"dark",strength:.45,borderRadius:qe?16:0,active:se||w,className:"popup-frame","data-testid":"window-beam",children:t.jsxs("main",{className:"popup-shell w-[340px] p-4",children:[t.jsxs("header",{className:"flex items-center justify-between",children:[t.jsxs("div",{className:"flex items-center gap-2.5",children:[t.jsxs("button",{type:"button",onClick:()=>E($=>!$),className:"relative size-9 shrink-0 cursor-pointer outline-none",tabIndex:-1,"aria-hidden":"true",children:[t.jsx("img",{src:"icons/logo.svg",alt:"",className:"logo-glow absolute inset-0 size-9 blur-md saturate-150",style:I}),t.jsx("img",{src:"icons/logo.svg",alt:"",className:"relative size-9 transition-transform duration-500",style:{transform:ne?"rotateY(180deg)":"none"}})]}),t.jsxs("span",{className:"flex items-baseline gap-1.5",children:[t.jsx("span",{className:"text-base font-semibold tracking-tight",children:"Shelve"}),t.jsxs("span",{className:"text-[9px] font-normal tracking-wide text-muted-foreground/50",children:["beta ",chrome.runtime.getManifest?.().version??"","b"]})]})]}),t.jsx("button",{onClick:()=>chrome.runtime.openOptionsPage(),className:"flex size-8 items-center justify-center rounded-md border border-transparent text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted hover:text-foreground active:scale-[0.96] focus-visible:ring-2 focus-visible:ring-ring",title:"Settings","aria-label":"Settings",children:t.jsx(va,{className:"size-4"})})]}),R&&!se?t.jsx(zt,{dailyLimit:R.dailyLimit,onDismiss:()=>L(null)}):se?t.jsx(mt,{job:P}):Q||r==="apply"?t.jsx(xt,{groups:s,selected:l,applying:r==="apply",onSelectedChange:c,onApply:U,onDiscard:D}):t.jsxs(t.Fragment,{children:[k&&t.jsx(ft,{onDismiss:()=>{H(!1),chrome.storage.local.set({pinPromptDismissed:!0})}}),t.jsx(gt,{windowId:d,disabled:Z&&!w,acknowledged:f===!0,onAcknowledge:re,onRunningChange:N,onDraftChange:G,onMutation:async()=>{await Promise.all([J(),_()])},onQuotaExhausted:le}),t.jsx(Xe,{size:"md",colorVariant:"ocean",theme:"dark",strength:.4,active:f===!1||r==="organize"&&!se,className:"mt-3 w-full has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring","data-testid":"organize-beam",children:t.jsxs("button",{onClick:F,disabled:Z,className:"flex h-20 w-full flex-col items-center justify-center gap-2 rounded-lg border border-border bg-transparent text-sm font-medium text-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-primary/50 hover:bg-muted active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40","aria-label":"Organize tabs",children:[t.jsx(ja,{className:"size-5 text-primary"}),t.jsx("span",{children:"Organize tabs"})]})}),t.jsxs("div",{className:"mt-3 grid grid-cols-4 gap-1.5",children:[t.jsx(ze,{label:"Ungroup",onClick:V,disabled:Z,icon:$e("ungroup",t.jsx(bt,{className:"size-[18px]"}))}),t.jsx(ze,{label:"Duplicates",title:"Close duplicates",onClick:ge,disabled:Z,icon:$e("duplicates",t.jsx(la,{className:"size-4"}))}),t.jsx(ze,{label:"Merge",title:"Merge windows",onClick:me,disabled:Z||g<=1,icon:$e("merge",t.jsx(ia,{className:"size-4"}))}),t.jsx(ze,{label:"Undo",onClick:fe,disabled:Z||!b,icon:$e("undo",t.jsx(Ca,{className:"size-4"}))})]}),t.jsx($t,{groups:h,stashes:j,busyId:B,disabled:Z,onStash:oe,onResume:xe,onDelete:he})]}),!se&&!R&&t.jsxs(t.Fragment,{children:[t.jsxs("div",{className:"mt-4 min-h-4 text-xs","aria-live":"polite",children:[t.jsx("p",{className:a?.error?"text-destructive":"text-muted-foreground",children:a?.text??""}),a?.closedTabs&&a.closedTabs.length>0&&t.jsx(ut,{closedTabs:a.closedTabs,onExpire:()=>o(null)})]}),t.jsx(vt,{refreshToken:a}),t.jsxs("a",{href:"mailto:prithvi@skive.in?subject=Shelve%20feature%20request&body=Hi%20Prithvi%2C%0A%0AI%27d%20like%20to%20request%3A%0A%0A",className:"mt-2 flex h-8 w-full items-center justify-center gap-1.5 rounded-md border border-transparent text-xs text-muted-foreground outline-none transition-[color,background-color,border-color,transform] duration-150 [transition-timing-function:var(--ease-out-strong)] hover:border-border hover:bg-muted/50 hover:text-foreground active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-ring",children:[t.jsx(ua,{className:"size-3.5"}),"Request a feature"]})]})]})})}if(new URLSearchParams(window.location.search).has("overlay")){document.documentElement.dataset.overlay="";const r=()=>window.parent.postMessage({__shelveOverlay:!0,height:document.body.scrollHeight},"*");new ResizeObserver(r).observe(document.body),window.addEventListener("keydown",e=>{e.key==="Escape"&&window.parent.postMessage({__shelveOverlay:!0,close:!0},"*")})}Ke.createRoot(document.getElementById("root")).render(t.jsx(Qe.StrictMode,{children:t.jsx(Nt,{})}));
